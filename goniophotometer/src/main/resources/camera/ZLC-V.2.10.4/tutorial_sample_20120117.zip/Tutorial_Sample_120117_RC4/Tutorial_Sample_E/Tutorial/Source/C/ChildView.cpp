// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "Tutorial.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
#ifdef ZCL_TUTORIAL_VIEW
	m_pImage = NULL;
#endif
}

CChildView::~CChildView()
{
#ifdef ZCL_TUTORIAL_VIEW
	if( m_pImage )
	{
		delete m_pImage;
		m_pImage = NULL;
	}
#endif
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
END_MESSAGE_MAP()



// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
#ifdef ZCL_TUTORIAL_VIEW
	RECT		rect;
	CDC			dcBitmap;
	HBITMAP		hBitmapOld;
	CBitmap		BitmapImage;


	GetClientRect( &rect );
	BitmapImage.CreateBitmap( m_BitInfo.bmiHeader.biWidth,
						m_BitInfo.bmiHeader.biHeight,
						m_BitInfo.bmiHeader.biPlanes,
						m_BitInfo.bmiHeader.biBitCount,
						m_pImage );

	dcBitmap.CreateCompatibleDC( &dc );
	hBitmapOld = (HBITMAP)dcBitmap.SelectObject( BitmapImage );
	dc.BitBlt( rect.left,
				rect.top,
				m_BitInfo.bmiHeader.biWidth,
				m_BitInfo.bmiHeader.biHeight,
				&dcBitmap,
				0,
				0,
				SRCCOPY);
	dcBitmap.SelectObject( hBitmapOld );
	dcBitmap.DeleteDC();
#endif
	// Do not call CWnd::OnPaint() for painting messages
}

#ifdef ZCL_TUTORIAL_VIEW
void CChildView::OnExec()
{
	Invalidate(FALSE);
}
#endif
