using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
/// <summary>
/// Start of camera use
/// </summary>
using System.Runtime.InteropServices;

/// <summary>
/// Receive Thread
/// </summary>
using System.Drawing.Imaging;
using System.Threading;

/// <summary>
/// BMP Save
/// </summary>
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Tutorial
{
    public partial class Form1 : Form
    {
        /// <summary>
        /// Start of camera use
        /// </summary>
        private IntPtr hCamera;
        private ZCL_COLORMODE ColorMode = new ZCL_COLORMODE();
        private IntPtr hTbl;
        private IntPtr RGBImage;
        private ZCL_SHIFTID ShiftID;
        private Boolean Sony_CR = false;
        private ZCL_GETIMAGEINFO GetImage = new ZCL_GETIMAGEINFO();
        private ZCL_BITMAPINFO BmpInfo = new ZCL_BITMAPINFO();
        private Graphics Gra;

        /// <summary>
        /// Receive Thread
        /// </summary>
        private Thread Rcv_Thread = new Thread(new ParameterizedThreadStart(Rcv_ThreadDoWork));
        private ManualResetEvent Thread_End = new ManualResetEvent(false);

        public Form1()
        {
            /// <summary>
            /// Start of camera use
            /// </summary>
            ZCL_CAMERAINFO CameraInfo = new ZCL_CAMERAINFO();
            ZCL_CAMERATYPE CameraType;
            IntPtr CameraMode;
            ZCL_CAMERAMODEEXT CameraExtMode = new ZCL_CAMERAMODEEXT();
            UInt32 Data;

            InitializeComponent();

            ZCL.SetStructVersion(ZCL.ZCL_LIBRARY_STRUCT_VERSION);
            ZCL.Open(ulong.MaxValue, out hCamera);
            ZCL.CameraInfo(hCamera, CameraInfo, IntPtr.Zero);
            ZCL.CameraBusInfo(hCamera, IntPtr.Zero, out CameraType);
            ZCL.GetImageInfo(hCamera, GetImage);

            if (CameraInfo.VendorName.Equals("Sony", StringComparison.OrdinalIgnoreCase)
                && CameraType == ZCL_CAMERATYPE.ZCL_CAMERA1394
                && CameraInfo.ModelName.Contains("CR"))
                Sony_CR = true;

            /// <summary>
            /// Set Feature
            /// </summary>
            ZCL_SETFEATUREVALUE SetFeatureValue = new ZCL_SETFEATUREVALUE();
            SetFeatureValue.FeatureID = ZCL_FEATUREID.ZCL_GAIN;
            SetFeatureValue.ReqID = ZCL_SETREQID.ZCL_AUTO;
            ZCL.SetFeatureValue(hCamera, SetFeatureValue);

            /// <summary>
            /// Set Mode
            /// </summary>
            CameraExtMode.StdMode_Flag = false;
            CameraExtMode.ExtMode = ZCL_EXTMODE.ZCL_Mode_0;
//          CameraExtMode.ColorID = ZCL_COLORID.ZCL_MONO;
            CameraExtMode.ColorID = ZCL_COLORID.ZCL_RAW;
            CameraExtMode.FilterID = ZCL_CFILTERMODE.ZCL_FRGGB;
            ZCL.SetCameraMode(hCamera, CameraExtMode);

            ZCL_SETIMAGEINFO SetImage = new ZCL_SETIMAGEINFO();

            ZCL.GetImageInfo(hCamera, GetImage);

            SetImage.PosX = 0;
            SetImage.PosY = 0;
            SetImage.Width = GetImage.Width;
            SetImage.Height = GetImage.Height;
            SetImage.MaxSize_Flag = true;
            ZCL.SetImageInfo(hCamera, SetImage);

            CameraMode = Marshal.AllocCoTaskMem(Marshal.SizeOf(CameraExtMode));
            ZCL.NowCameraMode(hCamera, CameraMode);
            Marshal.PtrToStructure(CameraMode, CameraExtMode);
            Marshal.FreeCoTaskMem(CameraMode);


            ColorMode.ColorID = GetImage.ColorID;
            if (!CameraExtMode.StdMode_Flag &&
                (GetImage.ColorID == ZCL_COLORID.ZCL_RAW
                || GetImage.ColorID == ZCL_COLORID.ZCL_RAW10
                || GetImage.ColorID == ZCL_COLORID.ZCL_RAW12
                || GetImage.ColorID == ZCL_COLORID.ZCL_RAW16))
                ColorMode.CFilter = CameraExtMode.FilterID;
            else if (Sony_CR)
            {
                ZCL_GETFEATUREVALUE GetFeature = new ZCL_GETFEATUREVALUE();

                GetFeature.FeatureID = ZCL_FEATUREID.ZCL_OPTICAL_FILTER;
                ZCL.GetFeatureValue(hCamera, GetFeature);
                switch ((ZCL_CFILTERMODE_SONY)GetFeature.Value)
                {
                    case ZCL_CFILTERMODE_SONY.ZCL_SONYGBRG:
                        ColorMode.CFilter = ZCL_CFILTERMODE.ZCL_FGBRG;
                        break;

                    case ZCL_CFILTERMODE_SONY.ZCL_SONYBGGR:
                        ColorMode.CFilter = ZCL_CFILTERMODE.ZCL_FBGGR;
                        break;

                    case ZCL_CFILTERMODE_SONY.ZCL_SONYRGGB:
                        ColorMode.CFilter = ZCL_CFILTERMODE.ZCL_FRGGB;
                        break;

                    case ZCL_CFILTERMODE_SONY.ZCL_SONYGRBG:
                        ColorMode.CFilter = ZCL_CFILTERMODE.ZCL_FGRBG;
                        break;
                }
            }
            else
                ColorMode.CFilter = ZCL_CFILTERMODE.ZCL_FRGGB;

            ColorMode.StoreMode = ZCL_STOREMODE.ZCL_MEMmode;
            ColorMode.EndianMode = CameraType == ZCL_CAMERATYPE.ZCL_CAMERA1394 ? ZCL_ENDIAN.ZCL_BIGENDIAN : ZCL_ENDIAN.ZCL_LITTLEENDIAN;
            ColorMode.Parallel_Flag = true;

            CameraMode = Marshal.AllocCoTaskMem(Marshal.SizeOf(CameraExtMode));
            ZCL.NowCameraMode(hCamera, CameraMode);
            Marshal.PtrToStructure(CameraMode, CameraExtMode);
            Marshal.FreeCoTaskMem(CameraMode);

            ShiftID = ZCL_SHIFTID.ZCL_SFT0;
            switch (ColorMode.ColorID)
            {
                case ZCL_COLORID.ZCL_RAW:
                    ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW8G, ShiftID, IntPtr.Zero);
                    break;

                case ZCL_COLORID.ZCL_RAW10:
                    ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW10G, ShiftID, IntPtr.Zero);
                    break;

                case ZCL_COLORID.ZCL_RAW12:
                    ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW12G, ShiftID, IntPtr.Zero);
                    break;

                case ZCL_COLORID.ZCL_RAW16:
                    ZCL.GetDataDepth(hCamera, out Data);
                    if (Data == 0)
                        Data = 8;
                    ShiftID = (ZCL_SHIFTID)(Data - 8);
                    ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW16G, ShiftID, IntPtr.Zero);
                    break;

                case ZCL_COLORID.ZCL_RGB16:
                case ZCL_COLORID.ZCL_SMONO16:
                case ZCL_COLORID.ZCL_SRGB16:
                case ZCL_COLORID.ZCL_BGR16:
                    ZCL.GetDataDepth(hCamera, out Data);
                    if (Data == 0)
                        Data = 8;
                    ShiftID = (ZCL_SHIFTID)(Data - 8);
                    ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_C32bit, ShiftID, IntPtr.Zero);
                    break;

                case ZCL_COLORID.ZCL_MONO16:
                    ZCL.GetDataDepth(hCamera, out Data);
                    if (Data == 0)
                        Data = 8;
                    ShiftID = (ZCL_SHIFTID)(Data - 8);
                    if (Sony_CR)
                        ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW16G, ShiftID, IntPtr.Zero);
                    else
                        ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_C32bit, ShiftID, IntPtr.Zero);
                    break;

                case ZCL_COLORID.ZCL_MONO:
                    if (Sony_CR)
                        ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW8G, ShiftID, IntPtr.Zero);
                    else
                        ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_C32bit, ShiftID, IntPtr.Zero);
                    break;

                default:
                    ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_C32bit, ShiftID, IntPtr.Zero);
                    break;
            }
            ZCL.ColorConvSetBMPINFO(hTbl, GetImage.Width, GetImage.Height, BmpInfo);

            RGBImage = Marshal.AllocCoTaskMem((int)BmpInfo.biSizeImage);


			this.ClientSize = new System.Drawing.Size(GetImage.Width, GetImage.Height + 2);
			Gra = this.CreateGraphics();

            ZCL.IsoAlloc(hCamera);

            /// <summary>
            /// Receive Thread
            /// </summary>
            Rcv_Thread.Start(this);

            ZCL.IsoStart(hCamera, 0);
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            /// <summary>
            /// Stop of camera use
            /// </summary>
            if (!hCamera.Equals(IntPtr.Zero))
            {

                ZCL.IsoStop(hCamera);

                /// <summary>
                /// Receive Thread
                /// </summary>
                Thread_End.Set();

                ZCL.AbortImageReqAll(hCamera);

                /// <summary>
                /// Receive Thread
                /// </summary>
                Rcv_Thread.Join();

                ZCL.IsoRelease(hCamera);
                ZCL.Close(hCamera);

                if (!hTbl.Equals(IntPtr.Zero))
                    ZCL.CloseConvHandle(hTbl);

                Marshal.FreeCoTaskMem(RGBImage);
                Gra.Dispose();
            }
        }

        /// <summary>
        /// Receive Thread
        /// </summary>
        private static void Rcv_ThreadDoWork(object Context)
        {
            const int Max_Buffer = 5;
            Form1 FormRef = (Form1)Context;
            IntPtr[] pBuf = new IntPtr[Max_Buffer];
            int idx;

            /// <summary>
            /// BMP Save
            /// </summary>
            Byte[] Buf = new byte[FormRef.BmpInfo.biSizeImage];
            Byte[] Info = new byte[Marshal.SizeOf(FormRef.BmpInfo)];
            ZCL_COLORMODE FileColorMode = new ZCL_COLORMODE();
            int FileSaveIdx = 0;
            FileColorMode.ColorID = FormRef.ColorMode.ColorID;
            FileColorMode.CFilter = FormRef.ColorMode.CFilter;
            FileColorMode.StoreMode = ZCL_STOREMODE.ZCL_BMPmode;
            FileColorMode.EndianMode = FormRef.ColorMode.EndianMode;
            FileColorMode.Parallel_Flag = FormRef.ColorMode.Parallel_Flag;

            for (idx = 0; idx < Max_Buffer; idx++)
                pBuf[idx] = Marshal.AllocCoTaskMem((int)FormRef.GetImage.Buffer);
            for (idx = 0; idx < Max_Buffer; idx++)
                ZCL.ImageReq(FormRef.hCamera, pBuf[idx], FormRef.GetImage.Buffer);
            idx = 0;
            while (true)
            {
                ZCL.ImageComplete(FormRef.hCamera, pBuf[idx], IntPtr.Zero, IntPtr.Zero, IntPtr.Zero);
                if (FormRef.Thread_End.WaitOne(0))
                    break;
                ZCL.ColorConvExec(FormRef.hTbl,
                                    (UInt32)FormRef.BmpInfo.biWidth,
                                    (UInt32)FormRef.BmpInfo.biHeight,
                                    FormRef.ColorMode,
                                    pBuf[idx],
                                    FormRef.RGBImage);
                Bitmap RGB = new Bitmap(FormRef.BmpInfo.biWidth, FormRef.BmpInfo.biHeight, (int)FormRef.BmpInfo.biWidth * 4, PixelFormat.Format32bppRgb, FormRef.RGBImage);
                FormRef.Gra.DrawImage(RGB, 0, 0);
                RGB.Dispose();


                /// <summary>
                /// BMP Save
                /// </summary>
                if (FileSaveIdx-- == 0)
                {
                    FileSaveIdx = 100;
                    MessageBox.Show("BMP Save");
                    GCHandle gch = GCHandle.Alloc(Info, GCHandleType.Pinned);

                    ZCL.ColorConvExec(FormRef.hTbl,
                                        (UInt32)FormRef.BmpInfo.biWidth,
                                        (UInt32)FormRef.BmpInfo.biHeight,
                                        FileColorMode,
                                        pBuf[idx],
                                        FormRef.RGBImage);

                    FileStream fs = new FileStream("Tutorial.bmp", FileMode.Create);
                    BinaryWriter w = new BinaryWriter(fs);
                    BinaryFormatter Format = new BinaryFormatter();
                    w.Write((UInt16)19778);
                    w.Write((UInt32)(14 + Marshal.SizeOf(FormRef.BmpInfo) + FormRef.BmpInfo.biSizeImage));
                    w.Write((UInt16)0);
                    w.Write((UInt16)0);
                    w.Write((UInt32)(14 + Marshal.SizeOf(FormRef.BmpInfo)));
                    Marshal.StructureToPtr(FormRef.BmpInfo, gch.AddrOfPinnedObject(), false);
                    w.Write(Info);
                    Marshal.Copy(FormRef.RGBImage, Buf, 0, (int)FormRef.BmpInfo.biSizeImage);
                    w.Write(Buf);
                    w.Close();
                    fs.Close();
                    gch.Free();
                }

                ZCL.ImageReq(FormRef.hCamera, pBuf[idx], FormRef.GetImage.Buffer);
                idx++;
                if (idx >= Max_Buffer)
                    idx = 0;
            }
            ZCL.AbortImageReqAll(FormRef.hCamera);
            for (idx = 0; idx < Max_Buffer; idx++)
                Marshal.FreeCoTaskMem(pBuf[idx]);
        }
    }
}