// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Sample1.h"
#include "CtlWnd.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


UINT	RcvThread( LPVOID );
//---------------------------------------------------------------------------
// System Call back
// When bus reset occurred, when the numbers of camera that I can open changed
// on a bus, when system abnormality occurred, it is called.
extern "C"
VOID
CALLBACK
SystemFunc( STATUS_SYSTEMCODE Status, PVOID Countext )
{
	CMainFrame	*p = (CMainFrame*)Countext;

	switch( Status )
	{
	case STATUSZCL_BUSRESET:				// Processing of bus reset
		AfxMessageBox( "BusReset Event" );
		break;

	case STATUSZCL_POWERUP:					// Processing of PowerUP
		AfxMessageBox( "PowerUP Event" );
		break;
	}
}

// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
	ON_WM_SETFOCUS()
	ON_WM_DESTROY()
	ON_COMMAND(ID_CONTROL, OnControl)
	ON_UPDATE_COMMAND_UI(ID_BIT0, OnUpdateBit0)
	ON_UPDATE_COMMAND_UI(ID_BIT1, OnUpdateBit1)
	ON_UPDATE_COMMAND_UI(ID_BIT2, OnUpdateBit2)
	ON_UPDATE_COMMAND_UI(ID_BIT3, OnUpdateBit3)
	ON_UPDATE_COMMAND_UI(ID_BIT4, OnUpdateBit4)
	ON_UPDATE_COMMAND_UI(ID_BIT5, OnUpdateBit5)
	ON_UPDATE_COMMAND_UI(ID_BIT6, OnUpdateBit6)
	ON_UPDATE_COMMAND_UI(ID_BIT7, OnUpdateBit7)
	ON_UPDATE_COMMAND_UI(ID_BIT8, OnUpdateBit8)
	ON_COMMAND(ID_BIT0, OnBit0)
	ON_COMMAND(ID_BIT1, OnBit1)
	ON_COMMAND(ID_BIT2, OnBit2)
	ON_COMMAND(ID_BIT3, OnBit3)
	ON_COMMAND(ID_BIT4, OnBit4)
	ON_COMMAND(ID_BIT5, OnBit5)
	ON_COMMAND(ID_BIT6, OnBit6)
	ON_COMMAND(ID_BIT7, OnBit7)
	ON_COMMAND(ID_BIT8, OnBit8)
END_MESSAGE_MAP()


// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	m_pApp = (CSample1App*)AfxGetApp();
	m_hIcon = m_pApp->LoadIcon(IDR_MAINFRAME);
	m_hTbl = NULL;
	m_BufLen = 0;
	m_SonyCR = false;
}

CMainFrame::~CMainFrame()
{
}


int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	// create a view to occupy the client area of the frame
	if (!m_wndView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW,
		CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST, NULL))
	{
		TRACE0("Failed to create view window\n");
		return -1;
	}

	SetIcon( m_hIcon, true );
	SetIcon( m_hIcon, false );

	m_EndEvent = ::CreateEvent( NULL, true, false, NULL );
	m_RcvTermEvent = ::CreateEvent( NULL, true, false, NULL );

	ZCLSetStructVersion( ZCL_LIBRARY_STRUCT_VERSION );

	ZCLSetCallBack( this, SystemFunc );

	if( !ZCLOpen( -1, &m_pApp->hCamera ) )
	{
		AfxMessageBox( "Camera Not found" );
		::CloseHandle( m_EndEvent );
		::CloseHandle( m_RcvTermEvent );
		return -1;
	}

	// Get the camera model name
	ZCL_CAMERAINFO		cinfo;
	if( !ZCLCameraInfo( m_pApp->hCamera, &cinfo, 0 ) )
	{
		AfxMessageBox( "Get Camera Info Error" );
		ZCLClose( m_pApp->hCamera );
		m_pApp->hCamera = 0;
		::CloseHandle( m_EndEvent );
		::CloseHandle( m_RcvTermEvent );
		return -1;
	}
	CString		string;

	string.Format( "Free Run Sample   Model=%s %s 0x%016I64X", cinfo.VendorName, cinfo.ModelName, cinfo.UID );
	SetWindowText( string );

	ZCL_CAMERATYPE		CameraType;;
	if( !ZCLCameraBusInfo( m_pApp->hCamera, NULL, &CameraType ) )
	{
		AfxMessageBox( "Get Camera Bus Info Error" );
		ZCLClose( m_pApp->hCamera );
		m_pApp->hCamera = 0;
		::CloseHandle( m_EndEvent );
		::CloseHandle( m_RcvTermEvent );
		return -1;
	}

	if( !_stricmp( (char*)cinfo.VendorName, "Sony" )
		&& CameraType == ZCL_CAMERA1394
		&& strstr( (char*)cinfo.ModelName, (char*)"CR" ) )
		m_SonyCR = true;

	ZCL_GETIMAGEINFO	GetImage;
	ZCL_CAMERAMODE		cmode;

#if 0
	// When change Camera Mode
#if 0
	// Standard mode
	cmode.StdMode_Flag = true;
	cmode.u.Std.Mode = ZCL_QVGA;
	cmode.u.Std.FrameRate = ZCL_Fps_30;
	if( !ZCLSetCameraMode( m_pApp->hCamera, &cmode ) )
	{
		AfxMessageBox( "Camera Mode Set Error" );
		ZCLClose( m_pApp->hCamera );
		m_pApp->hCamera = 0;
		::CloseHandle( m_EndEvent );
		::CloseHandle( m_RcvTermEvent );
		return -1;
	}
#else
	// Extended mode
	cmode.StdMode_Flag = false;
	cmode.u.Ext.Mode = ZCL_Mode_0;
	cmode.u.Ext.ColorID = ZCL_MONO;
	if( !ZCLSetCameraMode( m_pApp->hCamera, &cmode ) )
	{
		AfxMessageBox( "Camera Mode Set Error" );
		ZCLClose( m_pApp->hCamera );
		m_pApp->hCamera = 0;
		::CloseHandle( m_EndEvent );
		::CloseHandle( m_RcvTermEvent );
		return -1;
	}

	ZCL_SETIMAGEINFO	SetImage;

	ZCLGetImageInfo( m_pApp->hCamera, &GetImage );

	SetImage.PosX = 0;
	SetImage.PosY = 0;
	SetImage.Width = GetImage.Image.Width;
	SetImage.Height = GetImage.Image.Height;
	SetImage.MaxSize_Flag = true;
	if( !ZCLSetImageInfo( m_pApp->hCamera, &SetImage ) )
	{
		AfxMessageBox( "Camera ImageSize Set Error" );
		ZCLClose( m_pApp->hCamera );
		m_pApp->hCamera = 0;
		::CloseHandle( m_EndEvent );
		::CloseHandle( m_RcvTermEvent );
		return -1;
	}
#endif
#endif

	if( !ZCLNowCameraMode( m_pApp->hCamera, &cmode ) )
	{
		AfxMessageBox( "Camera Mode Get Error" );
		ZCLClose( m_pApp->hCamera );
		m_pApp->hCamera = 0;
		::CloseHandle( m_EndEvent );
		::CloseHandle( m_RcvTermEvent );
		return -1;
	}

	if( !ZCLGetImageInfo( m_pApp->hCamera, &GetImage ) )
	{
		AfxMessageBox( "Camera ImageSize Get Error" );
		ZCLClose( m_pApp->hCamera );
		m_pApp->hCamera = 0;
		::CloseHandle( m_EndEvent );
		::CloseHandle( m_RcvTermEvent );
		return -1;
	}

	m_ColorMode.ColorID = GetImage.Image.ColorID;
	if( !cmode.StdMode_Flag &&
		( m_ColorMode.ColorID == ZCL_RAW
		|| m_ColorMode.ColorID == ZCL_RAW10
		|| m_ColorMode.ColorID == ZCL_RAW12
		|| m_ColorMode.ColorID == ZCL_RAW16 ) )
		m_ColorMode.CFilter = cmode.u.Ext.FilterID;
	else if( m_SonyCR )
	{
		ZCL_GETFEATUREVALUE	GetFeature;
	
		GetFeature.Version = ZCLGetLibraryRevision();

		GetFeature.FeatureID = ZCL_OPTICAL_FILTER;
		ZCLGetFeatureValue( m_pApp->hCamera, &GetFeature );
		switch( GetFeature.u.Std.Value )
		{
		case ZCL_SONYGBRG:
			m_ColorMode.CFilter = ZCL_FGBRG;
			break;

		case ZCL_SONYBGGR:
			m_ColorMode.CFilter = ZCL_FBGGR;
			break;

		case ZCL_SONYRGGB:
			m_ColorMode.CFilter = ZCL_FRGGB;
			break;

		case ZCL_SONYGRBG:
			m_ColorMode.CFilter = ZCL_FGRBG;
			break;
		}
	}
	else
		m_ColorMode.CFilter = ZCL_FRGGB;

	m_ColorMode.StoreMode = ZCL_MEMmode;
	m_ColorMode.EndianMode = CameraType == ZCL_CAMERA1394 ? ZCL_BIGENDIAN : ZCL_LITTLEENDIAN;
	m_ColorMode.Parallel_Flag = TRUE;

	m_BufLen = GetImage.Image.Buffer;

	// Create a color conversion table
	m_Shift = 0;
	ULONG	DataDepth;
	switch( m_ColorMode.ColorID )
	{
	case ZCL_RAW:
		ZCLCreateConvHandle( &m_hTbl, ZCL_CFilterRAW8G, (ZCL_SHIFTID)m_Shift, NULL );
		break;

	case ZCL_RAW10:
		ZCLCreateConvHandle( &m_hTbl, ZCL_CFilterRAW10G, (ZCL_SHIFTID)m_Shift, NULL );
		break;

	case ZCL_RAW12:
		ZCLCreateConvHandle( &m_hTbl, ZCL_CFilterRAW12G, (ZCL_SHIFTID)m_Shift, NULL );
		break;

	case ZCL_RAW16:
		ZCLCreateConvHandle( &m_hTbl, ZCL_CFilterRAW16G, (ZCL_SHIFTID)m_Shift, NULL );
		break;

	case ZCL_RGB16:
	case ZCL_SMONO16:
	case ZCL_SRGB16:
	case ZCL_BGR16:
		ZCLGetDataDepth( m_pApp->hCamera, &DataDepth );
		if( DataDepth == 0 )
			DataDepth = 8;
		m_Shift = DataDepth - 8;
		ZCLCreateConvHandle( &m_hTbl, ZCL_C32bit, (ZCL_SHIFTID)m_Shift, NULL );
		break;

	case ZCL_MONO16:
		ZCLGetDataDepth( m_pApp->hCamera, &DataDepth );
		if( DataDepth == 0 )
			DataDepth = 8;
		m_Shift = DataDepth - 8;
		if( m_SonyCR )
			ZCLCreateConvHandle( &m_hTbl, ZCL_CFilterRAW16G, (ZCL_SHIFTID)m_Shift, NULL );
		else
			ZCLCreateConvHandle( &m_hTbl, ZCL_C32bit, (ZCL_SHIFTID)m_Shift, NULL );
		break;

	case ZCL_MONO:
		if( m_SonyCR )
			ZCLCreateConvHandle( &m_hTbl, ZCL_CFilterRAW8G, (ZCL_SHIFTID)m_Shift, NULL );
		else
			ZCLCreateConvHandle( &m_hTbl, ZCL_C32bit, (ZCL_SHIFTID)m_Shift, NULL );
		break;

	default:
		ZCLCreateConvHandle( &m_hTbl, ZCL_C32bit, (ZCL_SHIFTID)m_Shift, NULL );
		break;
	}
	ZCLColorConvSetBMPINFO( m_hTbl, GetImage.Image.Width, GetImage.Image.Height, &m_wndView.m_BitInfo );

	// Memory allocation for data after the color conversion
	m_wndView.m_pImage = new BYTE[ m_wndView.m_BitInfo.bmiHeader.biSizeImage ];
	if( !m_wndView.m_pImage )
	{
		AfxMessageBox( "Memory Alloc Error" );
		ZCLCloseConvHandle( m_hTbl );
		ZCLClose( m_pApp->hCamera );
		m_pApp->hCamera = 0;
		::CloseHandle( m_EndEvent );
		::CloseHandle( m_RcvTermEvent );
		return -1;
	}

	// Camera transmission preparations
	if( !ZCLIsoAlloc( m_pApp->hCamera ) )
	{
		AfxMessageBox( "Isoc Alloc Error" );
		ZCLCloseConvHandle( m_hTbl );
		ZCLClose( m_pApp->hCamera );
		m_pApp->hCamera = 0;
		delete m_wndView.m_pImage;
		::CloseHandle( m_EndEvent );
		::CloseHandle( m_RcvTermEvent );
		return -1;
	}

	// Setting of the size of the window
#ifdef	FPS_DISP
	m_wndView.gotime = 0;

	CClientDC 	dc(this);
	TEXTMETRIC	textinfo;
	dc.GetTextMetrics( &textinfo );

	SetWindowPos( &wndTop,
				0,
				0,
				GetImage.Image.Width + GetSystemMetrics( SM_CXFIXEDFRAME ) * 2 + GetSystemMetrics( SM_CXEDGE ) * 2,
				GetImage.Image.Height + GetSystemMetrics( SM_CYFIXEDFRAME ) * 2 + GetSystemMetrics( SM_CYEDGE ) * 2 + GetSystemMetrics( SM_CYMENU ) * 2 + textinfo.tmHeight,
				SWP_NOMOVE );
#else
	SetWindowPos( &wndTop,
				0,
				0,
				GetImage.Image.Width + GetSystemMetrics( SM_CXFIXEDFRAME ) * 2 + GetSystemMetrics( SM_CXEDGE ) * 2,
				GetImage.Image.Height + GetSystemMetrics( SM_CYFIXEDFRAME ) * 2 + GetSystemMetrics( SM_CYEDGE ) * 2 + GetSystemMetrics( SM_CYMENU ) * 2,
				SWP_NOMOVE );
#endif


	// Start Data Receives Thread
	AfxBeginThread( RcvThread, this );

	// Start isochronous transfer
	if( !ZCLIsoStart( m_pApp->hCamera, 0 ) )
	{
		AfxMessageBox( "Iso Start Error" );
		::SetEvent( m_EndEvent );
		ZCLAbortImageReqAll( m_pApp->hCamera );
		::WaitForSingleObject( m_RcvTermEvent, INFINITE );
		ZCLCloseConvHandle( m_hTbl );
		ZCLClose( m_pApp->hCamera );
		m_pApp->hCamera = 0;
		delete m_wndView.m_pImage;
		::CloseHandle( m_EndEvent );
		::CloseHandle( m_RcvTermEvent );
		return -1;
	}

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return false;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	cs.style = WS_OVERLAPPED | WS_CAPTION | FWS_ADDTOTITLE
		 | WS_SYSMENU;

	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(0);
	return true;
}


// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG


// CMainFrame message handlers

void CMainFrame::OnSetFocus(CWnd* /*pOldWnd*/)
{
	// forward focus to the view window
	m_wndView.SetFocus();
}

BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{
	// let the view have first crack at the command
	if (m_wndView.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return true;

	// otherwise, do default handling
	return CFrameWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

void CMainFrame::OnDestroy()
{
	CFrameWnd::OnDestroy();

	if( m_pApp->hCamera )
	{
		if( !ZCLIsoStop( m_pApp->hCamera ) )
			AfxMessageBox( "Iso Stop Error" );

		::SetEvent( m_EndEvent );
		ZCLAbortImageReqAll( m_pApp->hCamera );
		::WaitForSingleObject( m_RcvTermEvent, INFINITE );

		// Release of transmission resources
		if( !ZCLIsoRelease( m_pApp->hCamera ) )
			AfxMessageBox( "Iso Release Error" );

		// Stop of camera use
		if( !ZCLClose( m_pApp->hCamera ) )
			AfxMessageBox( "Camera Close Error" );

		// Close of color convert table
		if( m_hTbl )
			ZCLCloseConvHandle( m_hTbl );

		delete m_wndView.m_pImage;

		m_pApp->hCamera = 0;

		::CloseHandle( m_EndEvent );
		::CloseHandle( m_RcvTermEvent );
	}
}

void CMainFrame::OnControl()
{
	CCtlWnd	*Dlg;
	Dlg = new CCtlWnd( this );

	Dlg->DoModal();

	delete Dlg;
}

#define Max_Buffer	5
#define	FRATE_MAX	15

// Data Receives Thread
UINT RcvThread( LPVOID Countext )
{
	CMainFrame*		pMp = (CMainFrame*)Countext;
	CSample1App*	pApp = (CSample1App*)AfxGetApp();
	PUCHAR			pBuf[ Max_Buffer ];
	ULONG			idx;
#ifdef	FPS_DISP
	ULONG			nowtime;
	ULONG			oldtime = 0;
	ULONG			m_Count = FRATE_MAX;
#endif


	for( idx = 0; idx < Max_Buffer; idx++ )
		pBuf[ idx ] = new BYTE[ pMp->m_BufLen ];

	for( idx = 0; idx < Max_Buffer; idx++ )
		ZCLImageReq( pApp->hCamera, pBuf[ idx ], pMp->m_BufLen );
	idx = 0;
	while( 1 )
	{
		ZCLImageCompleteWait( pApp->hCamera, pBuf[ idx ], NULL, NULL, NULL );
		if( ::WaitForSingleObject( pMp->m_EndEvent, 0 ) == WAIT_OBJECT_0 )
			break;
		ZCLColorConvExec( pMp->m_hTbl,
							pMp->m_wndView.m_BitInfo.bmiHeader.biWidth,
							pMp->m_wndView.m_BitInfo.bmiHeader.biHeight,
							&pMp->m_ColorMode,
							pBuf[ idx ],
							pMp->m_wndView.m_pImage );
#ifdef	FPS_DISP
		// The frame rate calculation
		m_Count++;
		if( m_Count >= FRATE_MAX )
		{
			nowtime = GetTickCount();
			if( oldtime )
			{
				if( nowtime > oldtime )
				{
					pMp->m_wndView.gotime = nowtime - oldtime;
					pMp->m_wndView.gotime /= FRATE_MAX;
					pMp->m_wndView.gotime = 1000 / pMp->m_wndView.gotime;
				}
			}
			m_Count = 0;
			oldtime = nowtime;
		}
#endif
		// Redraw
		pMp->m_wndView.OnExec();
		ZCLImageReq( pApp->hCamera, pBuf[ idx ], pMp->m_BufLen );
		idx++;
		if( idx >= Max_Buffer )
			idx = 0;
	}
	ZCLAbortImageReqAll( pApp->hCamera );
	for( idx = 0; idx < Max_Buffer; idx++ )
		delete pBuf[ idx ];
	SetEvent( pMp->m_RcvTermEvent );
	return 0;
}

void CMainFrame::OnUpdateBitmenu(ULONG No, CCmdUI* pCmdUI)
{
	switch( m_ColorMode.ColorID )
	{
	case ZCL_MONO16:
	case ZCL_RGB16:
	case ZCL_SMONO16:
	case ZCL_SRGB16:
	case ZCL_RAW16:
	case ZCL_BGR16:
		pCmdUI->Enable( true );
		break;

	default:
		pCmdUI->Enable( false );
		break;
	}
	pCmdUI->SetCheck( No == m_Shift ? true : false );
}

void CMainFrame::OnUpdateBit0(CCmdUI* pCmdUI)
{
	OnUpdateBitmenu( 0, pCmdUI );
}

void CMainFrame::OnUpdateBit1(CCmdUI* pCmdUI)
{
	OnUpdateBitmenu( 1, pCmdUI );
}

void CMainFrame::OnUpdateBit2(CCmdUI* pCmdUI)
{
	OnUpdateBitmenu( 2, pCmdUI );
}

void CMainFrame::OnUpdateBit3(CCmdUI* pCmdUI)
{
	OnUpdateBitmenu( 3, pCmdUI );
}

void CMainFrame::OnUpdateBit4(CCmdUI* pCmdUI)
{
	OnUpdateBitmenu( 4, pCmdUI );
}

void CMainFrame::OnUpdateBit5(CCmdUI* pCmdUI)
{
	OnUpdateBitmenu( 5, pCmdUI );
}

void CMainFrame::OnUpdateBit6(CCmdUI* pCmdUI)
{
	OnUpdateBitmenu( 6, pCmdUI );
}

void CMainFrame::OnUpdateBit7(CCmdUI* pCmdUI)
{
	OnUpdateBitmenu( 7, pCmdUI );
}

void CMainFrame::OnUpdateBit8(CCmdUI* pCmdUI)
{
	OnUpdateBitmenu( 8, pCmdUI );
}

void CMainFrame::OnConv( ULONG No )
{
	m_Shift = No;
	ZCLIsoStop( m_pApp->hCamera );
	Sleep( 500 );
	ZCLCloseConvHandle( m_hTbl );
	m_hTbl = NULL;
	switch( m_ColorMode.ColorID )
	{
	case ZCL_RAW16:
		ZCLCreateConvHandle( &m_hTbl, ZCL_CFilterRAW16G, (ZCL_SHIFTID)m_Shift, NULL );
		break;

	case ZCL_RGB16:
	case ZCL_SMONO16:
	case ZCL_SRGB16:
	case ZCL_BGR16:
		ZCLCreateConvHandle( &m_hTbl, ZCL_C32bit, (ZCL_SHIFTID)m_Shift, NULL );
		break;

	case ZCL_MONO16:
		if( m_SonyCR )
			ZCLCreateConvHandle( &m_hTbl, ZCL_CFilterRAW16G, (ZCL_SHIFTID)m_Shift, NULL );
		else
			ZCLCreateConvHandle( &m_hTbl, ZCL_C32bit, (ZCL_SHIFTID)m_Shift, NULL );
		break;
	}
	ZCLIsoStart( m_pApp->hCamera, 0 );
}

void CMainFrame::OnBit0()
{
	OnConv( 0 );
}

void CMainFrame::OnBit1()
{
	OnConv( 1 );
}

void CMainFrame::OnBit2()
{
	OnConv( 2 );
}

void CMainFrame::OnBit3()
{
	OnConv( 3 );
}

void CMainFrame::OnBit4()
{
	OnConv( 4 );
}

void CMainFrame::OnBit5()
{
	OnConv( 5 );
}

void CMainFrame::OnBit6()
{
	OnConv( 6 );
}

void CMainFrame::OnBit7()
{
	OnConv( 7 );
}

void CMainFrame::OnBit8()
{
	OnConv( 8 );
}

