// Sample4.h : main header file for the Sample4 application
//
#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"       // main symbols


// CSample4App:
// See Sample4.cpp for the implementation of this class
//

class CSample4App : public CWinApp
{
public:
	CSample4App();

	HCAMERA		hCamera;

// Overrides
public:
	virtual BOOL InitInstance();

// Implementation

public:
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CSample4App theApp;