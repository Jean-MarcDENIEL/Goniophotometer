// MainFrm.h : interface of the CMainFrame class
//


#pragma once

#include "ChildView.h"

class CMainFrame : public CFrameWnd
{

public:
	CMainFrame();
protected:
	DECLARE_DYNAMIC(CMainFrame)

	void	OnUpdateBitmenu(ULONG No, CCmdUI* pCmdUI);
	void	OnConv(ULONG No);

	CSample4App		*m_pApp;
	HICON			m_hIcon;

	ULONG			m_Shift;

// Attributes
public:
	HANDLE			m_EndEvent;
	HANDLE			m_RcvTermEvent;
	HANDLE			m_SyncTermEvent;

	HCTBL			m_hTbl;
	ZCL_COLORMODE	m_ColorMode;
	ULONG			m_BufLen;
	BOOL			m_SonyCR;

// Operations
public:

// Overrides
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CChildView    m_wndView;

// Generated message map functions
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSetFocus(CWnd *pOldWnd);
	afx_msg void OnDestroy();
	afx_msg void OnControl();
	afx_msg void OnUpdateBit0(CCmdUI* pCmdUI);
	afx_msg void OnUpdateBit1(CCmdUI* pCmdUI);
	afx_msg void OnUpdateBit2(CCmdUI* pCmdUI);
	afx_msg void OnUpdateBit3(CCmdUI* pCmdUI);
	afx_msg void OnUpdateBit4(CCmdUI* pCmdUI);
	afx_msg void OnUpdateBit5(CCmdUI* pCmdUI);
	afx_msg void OnUpdateBit6(CCmdUI* pCmdUI);
	afx_msg void OnUpdateBit7(CCmdUI* pCmdUI);
	afx_msg void OnUpdateBit8(CCmdUI* pCmdUI);
	afx_msg void OnBit0();
	afx_msg void OnBit1();
	afx_msg void OnBit2();
	afx_msg void OnBit3();
	afx_msg void OnBit4();
	afx_msg void OnBit5();
	afx_msg void OnBit6();
	afx_msg void OnBit7();
	afx_msg void OnBit8();
	DECLARE_MESSAGE_MAP()
};


