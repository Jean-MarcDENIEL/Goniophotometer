<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
		Me.Menu1 = New System.Windows.Forms.MenuStrip
		Me.ShiftMenu = New System.Windows.Forms.ToolStripMenuItem
		Me.Bit0 = New System.Windows.Forms.ToolStripMenuItem
		Me.Bit1 = New System.Windows.Forms.ToolStripMenuItem
		Me.Bit2 = New System.Windows.Forms.ToolStripMenuItem
		Me.Bit3 = New System.Windows.Forms.ToolStripMenuItem
		Me.Bit4 = New System.Windows.Forms.ToolStripMenuItem
		Me.Bit5 = New System.Windows.Forms.ToolStripMenuItem
		Me.Bit6 = New System.Windows.Forms.ToolStripMenuItem
		Me.Bit7 = New System.Windows.Forms.ToolStripMenuItem
		Me.Bit8 = New System.Windows.Forms.ToolStripMenuItem
		Me.Menu1.SuspendLayout()
		Me.SuspendLayout()
		'
		'Menu1
		'
		Me.Menu1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShiftMenu})
		Me.Menu1.Location = New System.Drawing.Point(0, 0)
		Me.Menu1.Name = "Menu1"
		Me.Menu1.Size = New System.Drawing.Size(292, 24)
		Me.Menu1.TabIndex = 0
		Me.Menu1.Text = "Menu1"
		'
		'ShiftMenu
		'
		Me.ShiftMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Bit0, Me.Bit1, Me.Bit2, Me.Bit3, Me.Bit4, Me.Bit5, Me.Bit6, Me.Bit7, Me.Bit8})
		Me.ShiftMenu.Name = "ShiftMenu"
		Me.ShiftMenu.Size = New System.Drawing.Size(44, 20)
		Me.ShiftMenu.Text = "16Bit"
		'
		'Bit0
		'
		Me.Bit0.Checked = True
		Me.Bit0.CheckState = System.Windows.Forms.CheckState.Checked
		Me.Bit0.Name = "Bit0"
		Me.Bit0.Size = New System.Drawing.Size(107, 22)
		Me.Bit0.Text = "7-0bit"
		'
		'Bit1
		'
		Me.Bit1.Name = "Bit1"
		Me.Bit1.Size = New System.Drawing.Size(107, 22)
		Me.Bit1.Text = "8-1bit"
		'
		'Bit2
		'
		Me.Bit2.Name = "Bit2"
		Me.Bit2.Size = New System.Drawing.Size(107, 22)
		Me.Bit2.Text = "9-2bit"
		'
		'Bit3
		'
		Me.Bit3.Name = "Bit3"
		Me.Bit3.Size = New System.Drawing.Size(107, 22)
		Me.Bit3.Text = "10-3bit"
		'
		'Bit4
		'
		Me.Bit4.Name = "Bit4"
		Me.Bit4.Size = New System.Drawing.Size(107, 22)
		Me.Bit4.Text = "11-4bit"
		'
		'Bit5
		'
		Me.Bit5.Name = "Bit5"
		Me.Bit5.Size = New System.Drawing.Size(107, 22)
		Me.Bit5.Text = "12-5bit"
		'
		'Bit6
		'
		Me.Bit6.Name = "Bit6"
		Me.Bit6.Size = New System.Drawing.Size(107, 22)
		Me.Bit6.Text = "13-6bit"
		'
		'Bit7
		'
		Me.Bit7.Name = "Bit7"
		Me.Bit7.Size = New System.Drawing.Size(107, 22)
		Me.Bit7.Text = "14-7bit"
		'
		'Bit8
		'
		Me.Bit8.Name = "Bit8"
		Me.Bit8.Size = New System.Drawing.Size(107, 22)
		Me.Bit8.Text = "15-8bit"
		'
		'Form1
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(292, 273)
		Me.Controls.Add(Me.Menu1)
		Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
		Me.MainMenuStrip = Me.Menu1
		Me.MaximizeBox = False
		Me.Name = "Form1"
		Me.Text = "Form1"
		Me.Menu1.ResumeLayout(False)
		Me.Menu1.PerformLayout()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub
	Friend WithEvents Menu1 As System.Windows.Forms.MenuStrip
	Friend WithEvents ShiftMenu As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents Bit0 As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents Bit1 As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents Bit2 As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents Bit3 As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents Bit4 As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents Bit5 As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents Bit6 As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents Bit7 As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents Bit8 As System.Windows.Forms.ToolStripMenuItem

End Class
