﻿namespace Sample8
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
			this.Menu1 = new System.Windows.Forms.MenuStrip();
			this.ShiftMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.Bit0 = new System.Windows.Forms.ToolStripMenuItem();
			this.Bit1 = new System.Windows.Forms.ToolStripMenuItem();
			this.Bit2 = new System.Windows.Forms.ToolStripMenuItem();
			this.Bit3 = new System.Windows.Forms.ToolStripMenuItem();
			this.Bit4 = new System.Windows.Forms.ToolStripMenuItem();
			this.Bit5 = new System.Windows.Forms.ToolStripMenuItem();
			this.Bit6 = new System.Windows.Forms.ToolStripMenuItem();
			this.Bit7 = new System.Windows.Forms.ToolStripMenuItem();
			this.Bit8 = new System.Windows.Forms.ToolStripMenuItem();
			this.Menu1.SuspendLayout();
			this.SuspendLayout();
			// 
			// Menu1
			// 
			this.Menu1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ShiftMenu});
			this.Menu1.Location = new System.Drawing.Point(0, 0);
			this.Menu1.Name = "Menu1";
			this.Menu1.Size = new System.Drawing.Size(292, 24);
			this.Menu1.TabIndex = 0;
			this.Menu1.Text = "Menu1";
			// 
			// ShiftMenu
			// 
			this.ShiftMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Bit0,
            this.Bit1,
            this.Bit2,
            this.Bit3,
            this.Bit4,
            this.Bit5,
            this.Bit6,
            this.Bit7,
            this.Bit8});
			this.ShiftMenu.Name = "ShiftMenu";
			this.ShiftMenu.Size = new System.Drawing.Size(44, 20);
			this.ShiftMenu.Text = "16Bit";
			// 
			// Bit0
			// 
			this.Bit0.Checked = true;
			this.Bit0.CheckState = System.Windows.Forms.CheckState.Checked;
			this.Bit0.Name = "Bit0";
			this.Bit0.Size = new System.Drawing.Size(107, 22);
			this.Bit0.Text = "7-0bit";
			this.Bit0.Click += new System.EventHandler(this.OnBit);
			// 
			// Bit1
			// 
			this.Bit1.Name = "Bit1";
			this.Bit1.Size = new System.Drawing.Size(107, 22);
			this.Bit1.Text = "8-1bit";
			this.Bit1.Click += new System.EventHandler(this.OnBit);
			// 
			// Bit2
			// 
			this.Bit2.Name = "Bit2";
			this.Bit2.Size = new System.Drawing.Size(107, 22);
			this.Bit2.Text = "9-2bit";
			this.Bit2.Click += new System.EventHandler(this.OnBit);
			// 
			// Bit3
			// 
			this.Bit3.Name = "Bit3";
			this.Bit3.Size = new System.Drawing.Size(107, 22);
			this.Bit3.Text = "10-3bit";
			this.Bit3.Click += new System.EventHandler(this.OnBit);
			// 
			// Bit4
			// 
			this.Bit4.Name = "Bit4";
			this.Bit4.Size = new System.Drawing.Size(107, 22);
			this.Bit4.Text = "11-4bit";
			this.Bit4.Click += new System.EventHandler(this.OnBit);
			// 
			// Bit5
			// 
			this.Bit5.Name = "Bit5";
			this.Bit5.Size = new System.Drawing.Size(107, 22);
			this.Bit5.Text = "12-5bit";
			this.Bit5.Click += new System.EventHandler(this.OnBit);
			// 
			// Bit6
			// 
			this.Bit6.Name = "Bit6";
			this.Bit6.Size = new System.Drawing.Size(107, 22);
			this.Bit6.Text = "13-6bit";
			this.Bit6.Click += new System.EventHandler(this.OnBit);
			// 
			// Bit7
			// 
			this.Bit7.Name = "Bit7";
			this.Bit7.Size = new System.Drawing.Size(107, 22);
			this.Bit7.Text = "14-7bit";
			this.Bit7.Click += new System.EventHandler(this.OnBit);
			// 
			// Bit8
			// 
			this.Bit8.Name = "Bit8";
			this.Bit8.Size = new System.Drawing.Size(107, 22);
			this.Bit8.Text = "15-8bit";
			this.Bit8.Click += new System.EventHandler(this.OnBit);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(292, 273);
			this.Controls.Add(this.Menu1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MainMenuStrip = this.Menu1;
			this.MaximizeBox = false;
			this.Name = "Form1";
			this.Text = "Form1";
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
			this.Menu1.ResumeLayout(false);
			this.Menu1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.MenuStrip Menu1;
		private System.Windows.Forms.ToolStripMenuItem ShiftMenu;
		private System.Windows.Forms.ToolStripMenuItem Bit0;
		private System.Windows.Forms.ToolStripMenuItem Bit1;
		private System.Windows.Forms.ToolStripMenuItem Bit2;
		private System.Windows.Forms.ToolStripMenuItem Bit3;
		private System.Windows.Forms.ToolStripMenuItem Bit4;
		private System.Windows.Forms.ToolStripMenuItem Bit5;
		private System.Windows.Forms.ToolStripMenuItem Bit6;
		private System.Windows.Forms.ToolStripMenuItem Bit7;
		private System.Windows.Forms.ToolStripMenuItem Bit8;
	}
}

