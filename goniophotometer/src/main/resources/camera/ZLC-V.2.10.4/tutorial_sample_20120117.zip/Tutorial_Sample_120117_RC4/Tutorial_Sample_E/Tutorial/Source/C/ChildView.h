// ChildView.h : interface of the CChildView class
//


#pragma once


// CChildView window

class CChildView : public CWnd
{
// Construction
public:
	CChildView();

// Attributes
public:
#ifdef ZCL_TUTORIAL_VIEW
	PUCHAR			m_pImage;
	BITMAPINFO		m_BitInfo;
#endif

// Operations
public:
#ifdef ZCL_TUTORIAL_VIEW
	void			OnExec();
#endif

// Overrides
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// Implementation
public:
	virtual ~CChildView();

	// Generated message map functions
protected:
	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
};

