Public Class Form1
	Private hCamera As IntPtr
	Private ParamCB As GCHandle
	Private SystemCB As New ZCL.SystemFunc(AddressOf Me.SystemCallback)
	Private ColorMode As New ZCL_COLORMODE
	Private hTbl As IntPtr
	Private RGBImage As IntPtr
	Private ImageCB As New ZCL.ImageFunc(AddressOf Me.ImageCallback)
	Private ShiftID As ZCL_SHIFTID
	Private Sony_CR As Boolean = False
	Private Gra As Graphics

	Public Sub New()
		Dim CameraInfo As New ZCL_CAMERAINFO
		Dim CameraType As ZCL_CAMERATYPE
		Dim GetImage As New ZCL_GETIMAGEINFO
		Dim CameraMode As IntPtr
		Dim CameraExtMode As New ZCL_CAMERAMODEEXT
		Dim Data As UInteger
		Dim BmpInfo As New ZCL_BITMAPINFO

		'Required by the Windows Form Designer
		InitializeComponent()

		ZCL.SetStructVersion(ZCL.ZCL_LIBRARY_STRUCT_VERSION)

		ParamCB = GCHandle.Alloc(Me)
		ZCL.SetCallBack(GCHandle.ToIntPtr(ParamCB), SystemCB)

		If Not ZCL.Open(ULong.MaxValue, hCamera) Then
			MessageBox.Show("Camera Not found")
			Exit Sub
		End If

		If Not ZCL.CameraInfo(hCamera, CameraInfo, IntPtr.Zero) Then
			MessageBox.Show("Get Camera Info Error")
			ZCL.Close(hCamera)
			hCamera = IntPtr.Zero
			Exit Sub
		End If

		Me.Text = String.Concat("Free Run Sample   Model=", CameraInfo.VendorName, " ", CameraInfo.ModelName)

		If Not ZCL.CameraBusInfo(hCamera, IntPtr.Zero, CameraType) Then
			MessageBox.Show("Get Camera Bus Info Error")
			ZCL.Close(hCamera)
			hCamera = IntPtr.Zero
			Exit Sub
		End If

		If CameraInfo.VendorName.Equals("Sony", StringComparison.OrdinalIgnoreCase) _
		And CameraType = ZCL_CAMERATYPE.ZCL_CAMERA1394 _
		And CameraInfo.ModelName.Contains("CR") Then
			Sony_CR = True
		End If

#If False Then
        'When change Camera Mode

#If True Then
        'Standard mode

        Dim CameraStdMode As New ZCL_CAMERAMODESTD

        CameraStdMode.StdMode_Flag = True
        CameraStdMode.StdMode = ZCL_STDMODE.ZCL_VGA_MONO
        CameraStdMode.FrameRate = ZCL_FPS.ZCL_Fps_30
        If Not ZCL.SetCameraMode(hCamera, CameraStdMode) Then
            MessageBox.Show("Camera Mode Set Error")
            ZCL.Close(hCamera)
            ZCL.Close(hCamera)
            Exit Sub
        End If
#Else
        'Extended mode

        CameraExtMode.StdMode_Flag = False
        CameraExtMode.ExtMode = ZCL_EXTMODE.ZCL_Mode_0
        CameraExtMode.ColorID = ZCL_COLORID.ZCL_MONO
        If Not ZCL.SetCameraMode(hCamera, CameraExtMode) Then
            MessageBox.Show("Camera Mode Set Error")
            ZCL.Close(hCamera)
            hCamera = IntPtr.Zero
            Exit Sub
        End If

        Dim SetImage As New ZCL_SETIMAGEINFO

        ZCL.GetImageInfo(hCamera, GetImage)
        SetImage.PosX = 0
        SetImage.PosY = 0
        SetImage.Width = GetImage.Width
        SetImage.Height = GetImage.Height
        SetImage.MaxSize_Flag = True
        If Not ZCL.SetImageInfo(hCamera, SetImage) Then
            MessageBox.Show("Camera ImageSize Set Error")
            ZCL.Close(hCamera)
            hCamera = IntPtr.Zero
            Exit Sub
        End If
#End If
#End If

		CameraMode = Marshal.AllocCoTaskMem(Marshal.SizeOf(CameraExtMode))
		If Not ZCL.NowCameraMode(hCamera, CameraMode) Then
			MessageBox.Show("Camera Mode Get Error")
			ZCL.Close(hCamera)
			hCamera = IntPtr.Zero
			Marshal.FreeCoTaskMem(CameraMode)
			Exit Sub
		End If
		Marshal.PtrToStructure(CameraMode, CameraExtMode)
		Marshal.FreeCoTaskMem(CameraMode)

		If Not ZCL.GetImageInfo(hCamera, GetImage) Then
			MessageBox.Show("Camera ImageSize Get Error")
			ZCL.Close(hCamera)
			hCamera = IntPtr.Zero
			Exit Sub
		End If

		ColorMode.ColorID = GetImage.ColorID
		If CameraExtMode.StdMode_Flag = False AndAlso _
		(GetImage.ColorID = ZCL_COLORID.ZCL_RAW _
	   OrElse GetImage.ColorID = ZCL_COLORID.ZCL_RAW10 _
	   OrElse GetImage.ColorID = ZCL_COLORID.ZCL_RAW12 _
		 OrElse GetImage.ColorID = ZCL_COLORID.ZCL_RAW16) Then
			ColorMode.CFilter = CameraExtMode.FilterID
		ElseIf Sony_CR Then

			Dim GetFeature As New ZCL_GETFEATUREVALUE

			GetFeature.FeatureID = ZCL_FEATUREID.ZCL_OPTICAL_FILTER
			ZCL.GetFeatureValue(hCamera, GetFeature)
			Select Case GetFeature.Value
				Case ZCL_CFILTERMODE_SONY.ZCL_SONYGBRG
					ColorMode.CFilter = ZCL_CFILTERMODE.ZCL_FGBRG

				Case ZCL_CFILTERMODE_SONY.ZCL_SONYBGGR
					ColorMode.CFilter = ZCL_CFILTERMODE.ZCL_FBGGR

				Case ZCL_CFILTERMODE_SONY.ZCL_SONYRGGB
					ColorMode.CFilter = ZCL_CFILTERMODE.ZCL_FRGGB

				Case ZCL_CFILTERMODE_SONY.ZCL_SONYGRBG
					ColorMode.CFilter = ZCL_CFILTERMODE.ZCL_FGRBG
			End Select
		Else
			ColorMode.CFilter = ZCL_CFILTERMODE.ZCL_FRGGB
        End If

		ColorMode.StoreMode = ZCL_STOREMODE.ZCL_MEMmode
		If CameraType = ZCL_CAMERATYPE.ZCL_CAMERA1394 Then
			ColorMode.EndianMode = ZCL_ENDIAN.ZCL_BIGENDIAN
		Else
			ColorMode.EndianMode = ZCL_ENDIAN.ZCL_LITTLEENDIAN
        End If
        ColorMode.Parallel_Flag = True

		CameraMode = Marshal.AllocCoTaskMem(Marshal.SizeOf(CameraExtMode))
		ZCL.NowCameraMode(hCamera, CameraMode)
		Marshal.PtrToStructure(CameraMode, CameraExtMode)
		Marshal.FreeCoTaskMem(CameraMode)

		ZCL.CameraBusInfo(hCamera, IntPtr.Zero, CameraType)

		ShiftMenu.Enabled = False
		ShiftID = ZCL_SHIFTID.ZCL_SFT0
		Select Case ColorMode.ColorID
			Case ZCL_COLORID.ZCL_RAW
				ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW8G, ShiftID, IntPtr.Zero)

			Case ZCL_COLORID.ZCL_RAW10
				ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW10G, ShiftID, IntPtr.Zero)

			Case ZCL_COLORID.ZCL_RAW12
				ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW12G, ShiftID, IntPtr.Zero)

			Case ZCL_COLORID.ZCL_RAW16
				ShiftMenu.Enabled = True
				ZCL.GetDataDepth(hCamera, Data)
				If Data = 0 Then Data = 8
				ShiftID = Data - 8
				ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW16G, ShiftID, IntPtr.Zero)

			Case ZCL_COLORID.ZCL_RGB16, ZCL_COLORID.ZCL_SMONO16, ZCL_COLORID.ZCL_SRGB16, ZCL_COLORID.ZCL_BGR16
				ShiftMenu.Enabled = True
				ZCL.GetDataDepth(hCamera, Data)
				If Data = 0 Then Data = 8
				ShiftID = Data - 8
				ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_C32bit, ShiftID, IntPtr.Zero)

			Case ZCL_COLORID.ZCL_MONO16
				ShiftMenu.Enabled = True
				ZCL.GetDataDepth(hCamera, Data)
				If Data = 0 Then Data = 8
				ShiftID = Data - 8
				If Sony_CR Then
					ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW16G, ShiftID, IntPtr.Zero)
				Else
					ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_C32bit, ShiftID, IntPtr.Zero)
				End If

			Case ZCL_COLORID.ZCL_MONO
				If Sony_CR Then
					ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW8G, ShiftID, IntPtr.Zero)
				Else
					ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_C32bit, ShiftID, IntPtr.Zero)
				End If

			Case Else
				ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_C32bit, ShiftID, IntPtr.Zero)
		End Select
		ZCL.ColorConvSetBMPINFO(hTbl, GetImage.Width, GetImage.Height, BmpInfo)
		SetShiftMenuCheck()

		RGBImage = Marshal.AllocCoTaskMem(BmpInfo.biSizeImage)

		If Not ZCL.IsoAlloc(hCamera) Then
			MessageBox.Show("Isoc Alloc Error")
			ZCL.CloseConvHandle(hTbl)
			ZCL.Close(hCamera)
			hCamera = IntPtr.Zero
			Marshal.FreeCoTaskMem(RGBImage)
			Exit Sub
		End If

		Me.ClientSize = New System.Drawing.Size(GetImage.Width, GetImage.Height + Menu1.Size.Height + 2)
		Gra = Me.CreateGraphics()

		If Not ZCL.SetImageCallBack(hCamera, GCHandle.ToIntPtr(ParamCB), ImageCB, 3) Then
			MessageBox.Show("Set Image Callback Error")
			ZCL.CloseConvHandle(hTbl)
			ZCL.Close(hCamera)
			hCamera = IntPtr.Zero
			Marshal.FreeCoTaskMem(RGBImage)
			Gra.Dispose()
		End If

		If Not ZCL.IsoStart(hCamera, 0) Then
			MessageBox.Show("Iso Start Error")
			ZCL.SetImageCallBack(hCamera, IntPtr.Zero, IntPtr.Zero, 0)
			ZCL.CloseConvHandle(hTbl)
			ZCL.Close(hCamera)
			hCamera = IntPtr.Zero
			Marshal.FreeCoTaskMem(RGBImage)
			Gra.Dispose()
		End If
	End Sub

	Private Sub Form1_FormClosed(ByVal sender As Object, ByVal e As FormClosedEventArgs) Handles Me.FormClosed
		If Not hCamera.Equals(IntPtr.Zero) Then
			If Not ZCL.IsoStop(hCamera) Then MessageBox.Show("Iso Stop Error")

			If Not ZCL.SetImageCallBack(hCamera, IntPtr.Zero, IntPtr.Zero, 0) Then MessageBox.Show("Set Image Callback Error")

			If Not ZCL.IsoRelease(hCamera) Then MessageBox.Show("Iso Release Error")

			If Not ZCL.Close(hCamera) Then MessageBox.Show("Camera Close Error")

			If Not hTbl.Equals(IntPtr.Zero) Then ZCL.CloseConvHandle(hTbl)

			Marshal.FreeCoTaskMem(RGBImage)
			ParamCB.Free()
			Gra.Dispose()
		End If
	End Sub

	Private Sub SetShiftMenuCheck()
		If ShiftID = ZCL_SHIFTID.ZCL_SFT0 Then Bit0.Checked = True Else Bit0.Checked = False
		If ShiftID = ZCL_SHIFTID.ZCL_SFT1 Then Bit1.Checked = True Else Bit1.Checked = False
		If ShiftID = ZCL_SHIFTID.ZCL_SFT2 Then Bit2.Checked = True Else Bit2.Checked = False
		If ShiftID = ZCL_SHIFTID.ZCL_SFT3 Then Bit3.Checked = True Else Bit3.Checked = False
		If ShiftID = ZCL_SHIFTID.ZCL_SFT4 Then Bit4.Checked = True Else Bit4.Checked = False
		If ShiftID = ZCL_SHIFTID.ZCL_SFT5 Then Bit5.Checked = True Else Bit5.Checked = False
		If ShiftID = ZCL_SHIFTID.ZCL_SFT6 Then Bit6.Checked = True Else Bit6.Checked = False
		If ShiftID = ZCL_SHIFTID.ZCL_SFT7 Then Bit7.Checked = True Else Bit7.Checked = False
		If ShiftID = ZCL_SHIFTID.ZCL_SFT8 Then Bit8.Checked = True Else Bit8.Checked = False
	End Sub

	Public Sub ImageCallback(ByVal h_Camera As IntPtr, ByVal pBuf As IntPtr, ByVal Length As UInteger, ByVal Width As UInteger, ByVal Height As UInteger, ByVal pInfo As IntPtr, ByVal Context As IntPtr)
		Dim param As GCHandle = GCHandle.FromIntPtr(Context)
		Dim FormRef As Form1 = param.Target

		ZCL.ColorConvExec(FormRef.hTbl, Width, Height, FormRef.ColorMode, pBuf, FormRef.RGBImage)
		Dim RGB As New Bitmap(Width, Height, Width * 4, PixelFormat.Format32bppRgb, FormRef.RGBImage)
		FormRef.Gra.DrawImage(RGB, 0, FormRef.Menu1.Size.Height + 1)
		RGB.Dispose()
	End Sub

	Public Sub SystemCallback(ByVal SystemStatus As STATUS_SYSTEMCODE, ByVal Context As IntPtr)
		Dim param As GCHandle = GCHandle.FromIntPtr(Context)
		Dim FormRef As Form1 = param.Target

		Select Case SystemStatus
			Case STATUS_SYSTEMCODE.STATUSZCL_BUSRESET
				'Processing of bus reset

			Case STATUS_SYSTEMCODE.STATUSZCL_POWERUP
				'Processing of PowerUP

		End Select
	End Sub

	Private Sub OnBit(ByVal sender As Object, ByVal e As EventArgs) _
	Handles Bit0.Click, Bit1.Click, Bit2.Click, Bit3.Click, Bit4.Click, Bit5.Click, Bit6.Click, Bit7.Click, Bit8.Click
		ShiftID = Convert.ToInt32(sender.Name.Substring(3))
		ZCL.IsoStop(hCamera)
		Thread.Sleep(500)
		ZCL.CloseConvHandle(hTbl)
		hTbl = IntPtr.Zero
		Select Case ColorMode.ColorID
			Case ZCL_COLORID.ZCL_RAW16
				ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW16G, ShiftID, IntPtr.Zero)

			Case ZCL_COLORID.ZCL_RGB16, ZCL_COLORID.ZCL_SMONO16, ZCL_COLORID.ZCL_SRGB16, ZCL_COLORID.ZCL_BGR16
				ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_C32bit, ShiftID, IntPtr.Zero)

			Case ZCL_COLORID.ZCL_MONO16
				If Sony_CR Then
					ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW16G, ShiftID, IntPtr.Zero)
				Else
					ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_C32bit, ShiftID, IntPtr.Zero)
				End If
		End Select
		ZCL.IsoStart(hCamera, 0)
		SetShiftMenuCheck()
	End Sub
End Class
