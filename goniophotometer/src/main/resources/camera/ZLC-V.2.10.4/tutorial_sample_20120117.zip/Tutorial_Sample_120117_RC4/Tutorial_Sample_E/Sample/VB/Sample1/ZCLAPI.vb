'****************************************************************
'*	ZCL version 2.10 VB API Header File (32bit)					*
'*	Copyright (C) 2011-2011 TechnoScope Co., Ltd.				*
'****************************************************************
Imports System
Imports System.Runtime.InteropServices


Public Enum ZCL_STDMODE
	ZCL_QQVGA = 0						'   160 x  120 YUV(4:4:4)
	ZCL_QVGA							'   320 x  240 YUV(4:2:2)
	ZCL_VGA_YUV1						'   640 x  480 YUV(4:1:1)
	ZCL_VGA_YUV2						'   640 x  480 YUV(4:2:2)
	ZCL_VGA_RGB							'   640 x  480 RGB
	ZCL_VGA_MONO						'   640 x  480 Mono
	ZCL_VGA_MONO16						'   640 x  480 Mono16
	ZCL_SVGA_YUV						'   800 x  600 YUV(4:2:2)
	ZCL_SVGA_RGB						'   800 x  600 RGB
	ZCL_SVGA_MONO						'   800 x  600 MONO
	ZCL_SVGA_MONO16						'   800 x  600 MONO16
	ZCL_XGA_YUV							'	1024 x  768 YUV(4:2:2)
	ZCL_XGA_RGB							'	1024 x  768 RGB
	ZCL_XGA_MONO						'	1024 x  768 MONO
	ZCL_XGA_MONO16						'	1024 x  768 MONO16
	ZCL_SXGA_YUV						'	1280 x  960 YUV(4:2:2)
	ZCL_SXGA_RGB						'	1280 x  960 RGB
	ZCL_SXGA_MONO						'	1280 x  960 MONO
	ZCL_SXGA_MONO16						'	1280 x  960 MONO16
	ZCL_UXGA_YUV						'	1600 x 1200 YUV(4:2:2)
	ZCL_UXGA_RGB						'	1600 x 1200 RGB
	ZCL_UXGA_MONO						'	1600 x 1200 MONO
	ZCL_UXGA_MONO16						'	1600 x 1200 MONO16
End Enum


Public Enum ZCL_FPS
	ZCL_Fps_1875 = 0					'	FrameRate_0 (1.875fps)
	ZCL_Fps_375							'	FrameRate_1 (3.75fps)
	ZCL_Fps_75							'	FrameRate_2 (7.5fps)
	ZCL_Fps_15							'	FrameRate_3 (15fps)
	ZCL_Fps_30							'	FrameRate_4 (30fps)
	ZCL_Fps_60							'	FrameRate_5 (60fps)
	ZCL_Fps_120							'	FrameRate_6 (120fps)
	ZCL_Fps_240							'	FrameRate_7 (240fps)
End Enum


Public Enum ZCL_EXTMODE
	ZCL_Mode_0 = 0						'	Mode_0
	ZCL_Mode_1							'	Mode_1
	ZCL_Mode_2							'	Mode_2
	ZCL_Mode_3							'	Mode_3
	ZCL_Mode_4							'	Mode_4
	ZCL_Mode_5							'	Mode_5
	ZCL_Mode_6							'	Mode_6
	ZCL_Mode_7							'	Mode_7
	ZCL_Mode_8							'	Mode_8
	ZCL_Mode_9							'	Mode_9
	ZCL_Mode_10							'	Mode_10
	ZCL_Mode_11							'	Mode_11
	ZCL_Mode_12							'	Mode_12
	ZCL_Mode_13							'	Mode_13
	ZCL_Mode_14							'	Mode_14
	ZCL_Mode_15							'	Mode_15
	ZCL_Mode_16							'	Mode_16
	ZCL_Mode_17							'	Mode_17
	ZCL_Mode_18							'	Mode_18
	ZCL_Mode_19							'	Mode_19
	ZCL_Mode_20							'	Mode_20
	ZCL_Mode_21							'	Mode_21
	ZCL_Mode_22							'	Mode_22
	ZCL_Mode_23							'	Mode_23
	ZCL_Mode_24							'	Mode_24
	ZCL_Mode_25							'	Mode_25
	ZCL_Mode_26							'	Mode_26
	ZCL_Mode_27							'	Mode_27
	ZCL_Mode_28							'	Mode_28
	ZCL_Mode_29							'	Mode_29
	ZCL_Mode_30							'	Mode_30
	ZCL_Mode_31							'	Mode_31
End Enum


Public Enum ZCL_COLORID
	ZCL_MONO = 0						'	MONO			8bit No Conv
	ZCL_YUV411							'	YUV411			8bit
	ZCL_YUV422							'	YUV422			8bit
	ZCL_YUV444							'	YUV444			8bit
	ZCL_RGB								'	RGB				8bit
	ZCL_MONO16							'	MONO16			16bit
	ZCL_RGB16							'	RGB16			16bit
	ZCL_SMONO16							'	Signed MONO16	16bit
	ZCL_SRGB16							'	Signed RGB16	16bit
	ZCL_RAW								'	RAW				8bit
	ZCL_RAW16							'	RAW16			16bit
	ZCL_MONO12							'	MONO			12bit
	ZCL_RAW12							'	RAW				12bit

	ZCL_MONO10							'	MONO			10bit
	ZCL_RAW10							'	RAW				10bit
	ZCL_BGR								'	BGR				8bit No Conv
	ZCL_BGR16							'	BGR				16bit
	ZCL_RGBA							'	RGBA			8bit
	ZCL_BGRA							'	BGRA			8bit No Conv
	ZCL_RGB10G							'	RGB V1			10bit
	ZCL_RGB10P							'	RGB V2			10bit
	ZCL_RGB12							'	RGB				12bit
	ZCL_RGB565							'	RGB				5bit
	ZCL_BGR565							'	BGR				5bit No Conv
	ZCL_YUV422Y							'	YUV422			8bit
End Enum


Public Enum ZCL_PIXELFORMATID
	ZCL_PIX_MONO1P = &H1010038
	ZCL_PIX_MONO4P = &H1010039
	ZCL_PIX_MONO8 = &H1080001
	ZCL_PIX_MONO8S = &H1080002
	ZCL_PIX_MONO8_SIGNED = &H1080002
	ZCL_PIX_MONO10 = &H1100003
	ZCL_PIX_MONO10_PACKED = &H10C0004
	ZCL_PIX_MONO10G12 = &H10C003A
	ZCL_PIX_MONO12 = &H1100005
	ZCL_PIX_MONO12_PACKED = &H10C0006
	ZCL_PIX_MONO12G = &H10C003B
	ZCL_PIX_MONO14 = &H1100025
	ZCL_PIX_MONO16 = &H1100007
	ZCL_PIX_BAYERGR8 = &H1080008
	ZCL_PIX_BAYERRG8 = &H1080009
	ZCL_PIX_BAYERGB8 = &H108000A
	ZCL_PIX_BAYERBG8 = &H108000B
	ZCL_PIX_BAYERGR10 = &H110000C
	ZCL_PIX_BAYERRG10 = &H110000D
	ZCL_PIX_BAYERGB10 = &H110000E
	ZCL_PIX_BAYERBG10 = &H110000F
	ZCL_PIX_BAYERGR12 = &H1100010
	ZCL_PIX_BAYERRG12 = &H1100011
	ZCL_PIX_BAYERGB12 = &H1100012
	ZCL_PIX_BAYERBG12 = &H1100013
	ZCL_PIX_BAYERGR10_PACKED = &H10C0026
	ZCL_PIX_BAYERGR10G12 = &H10C003C
	ZCL_PIX_BAYERRG10_PACKED = &H10C0027
	ZCL_PIX_BAYERRG10G12 = &H10C003D
	ZCL_PIX_BAYERGB10_PACKED = &H10C0028
	ZCL_PIX_BAYERGB10G12 = &H10C003E
	ZCL_PIX_BAYERBG10_PACKED = &H10C0029
	ZCL_PIX_BAYERBG10G12 = &H10C003F
	ZCL_PIX_BAYERGR12_PACKED = &H10C002A
	ZCL_PIX_BAYERGR12G = &H10C0040
	ZCL_PIX_BAYERRG12_PACKED = &H10C002B
	ZCL_PIX_BAYERRG12G = &H10C0041
	ZCL_PIX_BAYERGB12_PACKED = &H10C002C
	ZCL_PIX_BAYERGB12G = &H10C0042
	ZCL_PIX_BAYERBG12_PACKED = &H10C002D
	ZCL_PIX_BAYERBG12G = &H10C0043
	ZCL_PIX_BAYERGR16_PACKED = &H110002E
	ZCL_PIX_BAYERGR16 = &H110002E
	ZCL_PIX_BAYERRG16_PACKED = &H110002F
	ZCL_PIX_BAYERRG16 = &H110002F
	ZCL_PIX_BAYERGB16_PACKED = &H1100030
	ZCL_PIX_BAYERGB16 = &H1100030
	ZCL_PIX_BAYERBG16_PACKED = &H1100031
	ZCL_PIX_BAYERBG16 = &H1100031
	ZCL_PIX_RGB8_PACKED = &H2180014
	ZCL_PIX_RGB8 = &H2180014
	ZCL_PIX_BGR8_PACKED = &H2180015
	ZCL_PIX_BGR8 = &H2180015
	ZCL_PIX_RGBA8 = &H2180016
	ZCL_PIX_BGRA8 = &H2180017
	ZCL_PIX_RGB10_PACKED = &H2300018
	ZCL_PIX_RGB10 = &H2300018
	ZCL_PIX_BGR10_PACKED = &H2300019
	ZCL_PIX_BGR10 = &H2300019
	ZCL_PIX_RGB12_PACKED = &H230001A
	ZCL_PIX_RGB12 = &H230001A
	ZCL_PIX_BGR12_PACKED = &H230001B
	ZCL_PIX_BGR12 = &H230001B
	ZCL_PIX_RGB16_PACKED = &H2300033
	ZCL_PIX_RGB16 = &H2300033
	ZCL_PIX_RGB10V1_PACKED = &H220001C
	ZCL_PIX_RGB10G32 = &H2200044
	ZCL_PIX_RGB10V2_PACKED = &H220001D
	ZCL_PIX_RGB10P32 = &H220001D
	ZCL_PIX_RGB12V1_PACKED = &H2240034
	ZCL_PIX_RGB12G = &H2240045
	ZCL_PIX_RGB565_PACKED = &H2100035
	ZCL_PIX_RGB565P = &H2100035
	ZCL_PIX_BGR565_PACKED = &H2100036
	ZCL_PIX_BGR565P = &H2100036
	ZCL_PIX_YUV411_PACKED = &H20C001E
	ZCL_PIX_YUV411_8_UYYVYY = &H20C001E
	ZCL_PIX_YUV422_PACKED = &H210001F
	ZCL_PIX_YUV422_8_UYVY = &H210001F
	ZCL_PIX_YUV422_YUYV_PACKED = &H2100032
	ZCL_PIX_YUV422_8_YUYV = &H2100032
	ZCL_PIX_YUV444_PACKED = &H2180020
	ZCL_PIX_YUV8_UYV = &H2180020
End Enum


Public Enum ZCL_GIGESTREAMTYPE
	ZCL_GIGEIMAGEDATA = 1
	ZCL_GIGERAWDATA
	ZCL_GIGEFILEDATA
	ZCL_GIGECHUNKDATA
	ZCL_GIGEEXTCHUNKDATA
	ZCL_GIGEVENDORDATA = &H8000
End Enum


Public Enum ZCL_FEATUREID
	ZCL_BRIGHTNESS = 0					'	Brightness
	ZCL_AE								'	Auto Exposure
	ZCL_SHARPNESS						'	Sharpness
	ZCL_WHITEBALANCE					'	White Balance
	ZCL_HUE								'	HUE
	ZCL_SATURATION						'	Saturation
	ZCL_GAMMA							'	Gamma
	ZCL_SHUTTER							'	Shutter
	ZCL_GAIN							'	Gain
	ZCL_IRIS							'	Iris
	ZCL_FOCUS							'	Focus
	ZCL_TEMPERATURE						'	Temperature
	ZCL_TRIGGER							'	Trigger
	ZCL_TRIGGER_DELAY					'	Trigger Delay
	ZCL_WHITE_SHADING					'	White Shading
	ZCL_FRAMERATE						'	FrameRate
	ZCL_ZOOM							'	Zoom
	ZCL_PAN								'	Pan
	ZCL_TILT							'	Tilt
	ZCL_OPTICAL_FILTER					'	Optical Filter
	ZCL_ONE_SHOT						'	One Shot
	ZCL_MULTI_SHOT						'	Multi Shot
	ZCL_POWER_ONOFF						'	Power On Off
	ZCL_MEMORYCHANNEL					'	Memory Channel
End Enum


Public Enum ZCL_TRIGGERMODE
	ZCL_Trigger_Mode0 = 0				'	Trigger Mode0
	ZCL_Trigger_Mode1					'	Trigger Mode1
	ZCL_Trigger_Mode2					'	Trigger Mode2
	ZCL_Trigger_Mode3					'	Trigger Mode3
	ZCL_Trigger_Mode4					'	Trigger Mode4
	ZCL_Trigger_Mode5					'	Trigger Mode5
	ZCL_Trigger_Mode14 = 14				'	Trigger Mode14
	ZCL_Trigger_Mode15					'	Trigger Mode15
End Enum


Public Enum ZCL_TRIGGERSOURCE
	ZCL_Trigger_Source0 = 0				'	Trigger Source0
	ZCL_Trigger_Source1					'	Trigger Source1
	ZCL_Trigger_Source2					'	Trigger Source2
	ZCL_Trigger_Source3					'	Trigger Source3
	ZCL_Software_Trigger = 7			'	Software Trigger
End Enum


Public Enum ZCL_TRANSMITSPEED
	ZCL_S100M = 0						'	100M
	ZCL_S200M							'	200M
	ZCL_S400M							'	400M
	ZCL_S800M							'	800M
	ZCL_S1600M							'	1.6G
	ZCL_S3200M							'	3.2G
End Enum


Public Enum ZCL_CONVERTMODE
	ZCL_C24bit = 0						'	24bit
	ZCL_C16bit							'	16bit
	ZCL_C15bit							'	15bit
	ZCL_CFilter							'	Color Filter
	ZCL_C32bit							'	32bit
	ZCL_CFilterRAW8G					'	RAW8 + G
	ZCL_CFilterRAW16					'	RAW16
	ZCL_CFilterRAW16G					'	RAW16 + G
	ZCL_CFilterRAW12					'	RAW12
	ZCL_CFilterRAW12G					'	RAW12 + G
	ZCL_CFilterRAW10					'	RAW10
	ZCL_CFilterRAW10G					'	RAW10 + G
	ZCL_CFilter24RAW8					'	RAW8
	ZCL_CFilter24RAW8G					'	RAW8 + G
	ZCL_CFilter24RAW16					'	RAW16
	ZCL_CFilter24RAW16G					'	RAW16 + G
	ZCL_CFilter24RAW12					'	RAW12
	ZCL_CFilter24RAW12G					'	RAW12 + G
	ZCL_CFilter24RAW10					'	RAW10
	ZCL_CFilter24RAW10G					'	RAW10 + G
	ZCL_CFilterRAW8 = ZCL_CFilter		'	RAW8
End Enum


Public Enum ZCL_CFILTERMODE
	ZCL_FRGGB = 0						'	RG/GB
	ZCL_FGBRG							'	GB/RG
	ZCL_FGRBG							'	GR/BG
	ZCL_FBGGR							'	BG/GR
End Enum


Public Enum ZCL_SHIFTID
	'	15 14 13 12 ..... 2 1 0
	ZCL_SFT0 = 0						'	7-0 bit
	ZCL_SFT1							'	8-1 bit
	ZCL_SFT2							'	9-2 bit
	ZCL_SFT3							'	10-3 bit
	ZCL_SFT4							'	11-4 bit
	ZCL_SFT5							'	12-5 bit
	ZCL_SFT6							'	13-6 bit
	ZCL_SFT7							'	14-7 bit
	ZCL_SFT8							'	15-8 bit
End Enum


Public Enum ZCL_STOREMODE
    ZCL_BMPmode = 0                     '	BMP file mode
    ZCL_MEMmode                         '	MEMORY mode
    ZCL_BMPmodeLR                       '	BMP file mode (Flip horizontal)
    ZCL_MEMmodeLR                       '	MEMORY mode (Flip horizontal)
End Enum


Public Enum ZCL_SETREQID
    ZCL_FEATURE_OFF = 0                 '	Feature function stop
    ZCL_ONE_PUSH                        '	Execution of One Push
    ZCL_AUTO                            '	Automatic setting
    ZCL_VALUE                           '	Manual value setting
    ZCL_ABSVALUE                        '	ABS manual value setting
    ZCL_ABSONE_PUSH                     '	ABS Execution of One Push
    ZCL_ABSAUTO                         '	ABS Automatic setting
End Enum


Public Enum ZCL_ENDIAN
	ZCL_BIGENDIAN = 0					'	Big Endian
	ZCL_LITTLEENDIAN					'	Little Endian
End Enum


Public Enum ZCL_CAMERATYPE
	ZCL_CAMERA1394 = 0
	ZCL_CAMERAGIGE
End Enum


Public Enum STATUS_SYSTEMCODE
    STATUSZCL_BUSRESET = 1              '	Bus reset generation
    STATUSZCL_POWERUP                   '	Return from sleep of system
End Enum


'Status Code
Public Enum STATUS_RTNCODE
    STATUSZCL_NO_ERROR = 0              '	No error
    STATUSZCL_COMPLETE = 0              '	Success in processing
    STATUSZCL_PARAMETER_ERROR           '	A parameter is illegal
    STATUSZCL_BUFFER_SHORT              '	A buffer is short

    STATUSZCL_OPEN_ERROR                '	Failure in the opening of a camera
    STATUSZCL_OPENED                    '	A camera has been already opened
    STATUSZCL_CANNOT_FOUND              '	A camera cannot be found
    STATUSZCL_NO_OPEN                   '	A camera is not opened

    STATUSZCL_COMMUNICATE_ERROR         '	Failure in communication

    STATUSZCL_DATA_INACCURACY           '	The acquired data is inaccurate
    STATUSZCL_NO_SUPPORT                '	No function is mounted
    STATUSZCL_VMODE_ERROR               '	Camera parameter setting error
    STATUSZCL_FEATURE_ERROR             '	Camera feature control error
    STATUSZCL_VALUE_ERROR               '	Camera parameter setting error(AbsValue, Value)
    STATUSZCL_SELFCLEAR_ERROR           '	A self-clear flag is not cleared
    STATUSZCL_IMAGE_ERROR               '	Image size setting error
    STATUSZCL_RESOURCE_ERROR            '	Requested. during securing of isochronous resources
    STATUSZCL_NOTRESOURCE_ERROR         '	Isochronous resources are not secured
    STATUSZCL_ALLOCATE_ERROR            '	Failure in the securing of isochronous resources
    STATUSZCL_STARTED_ERROR             '	The start state has been already reached
    STATUSZCL_NOTSTART_ERROR            '	The start state is not reached
    STATUSZCL_REQUEST_ERROR             '	Failure in request
    STATUSZCL_REQUEST_TIMEOUT           '	Time-out in request

    STATUSZCL_SOFTTRIGGER_BUSY          '	During Softtrigger practice
    STATUSZCL_MULTISLOPE_ERROR          '	Multi-slope setting error

    STATUSZCL_ABORTEXEC_ERROR           '	I was working to cancel it, and it was depended

    STATUSZCL_REQUEST_USERCANCEL        '	user cancel in request
    STATUSZCL_REQUEST_BUSRESETCANCEL    '	busReset cancel in request

    STATUSZCL_REQUEST_EXEC              '	Request exective 

    STATUSZCL_STRUCTVERSION_ERROR       '	The version of the structure body is unjust

    STATUSZCL_FUNCTION_ONLY1394         '	Functions only for 1394 cameras
    STATUSZCL_FUNCTION_ONLYGIGE         '	Functions only for GigE cameras
	STATUSZCL_GIGE_NOTMULTICAST			'	Not MultiCast IPAddr 

    STATUSZCL_UNDEF_ERROR = 99          '	Other error
End Enum


'	CameraInfo 
<StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi)> _
 Public Class ZCL_CAMERAINFO
	Public UID As ULong
	<MarshalAs(UnmanagedType.ByValTStr, SizeConst:=256)> _
	Public VendorName As String
	<MarshalAs(UnmanagedType.ByValTStr, SizeConst:=256)> _
	Public ModelName As String
End Class


'	GigECameraInfo  
<StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi)> _
 Public Class ZCL_GIGECAMERAINFO
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=6)> _
	Public MACAddr As Byte()
	Public Spec_Major As UShort
	Public Spec_Minor As UShort
	Public Dev_Mode As UInteger
	<MarshalAs(UnmanagedType.ByValTStr, SizeConst:=32)> _
	Public VendorName As String
	<MarshalAs(UnmanagedType.ByValTStr, SizeConst:=32)> _
	 Public ModelName As String
	<MarshalAs(UnmanagedType.ByValTStr, SizeConst:=32)> _
	Public Dev_Ver As String
	<MarshalAs(UnmanagedType.ByValTStr, SizeConst:=48)> _
	Public Vendor_Info As String
	<MarshalAs(UnmanagedType.ByValTStr, SizeConst:=16)> _
	Public SerialNumber As String
	<MarshalAs(UnmanagedType.ByValTStr, SizeConst:=16)> _
	Public UserName As String
End Class


'	SetCameraMode 
'	NowCameraMode 
'	CheckCameraMode 
<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_CAMERAMODESTD
	Public StdMode_Flag As Boolean
	Public StdMode As ZCL_STDMODE
	Public FrameRate As ZCL_FPS
	Public Rsvd As UInteger
End Class


<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_CAMERAMODEEXT
	Public StdMode_Flag As Boolean
	Public ExtMode As ZCL_EXTMODE
	Public ColorID As ZCL_COLORID
	Public FilterID As ZCL_CFILTERMODE
End Class


'	GetStreamMode 
<StructLayout(LayoutKind.Sequential)> _
Public Class ZCL_GETSTREAMMODE
	Public MinWidth As UShort
	Public MinHeight As UShort
	Public MaxWidth As UShort
	Public MaxHeight As UShort
	Public IncWidth As UShort
	Public IncHeight As UShort
	Public IncOffsetX As UShort
	Public IncOffsetY As UShort
	Public MinFrameRate As Single
	Public MaxFrameRate As Single
	Public InqFrameRateAuto As Boolean
	Public Width As UShort
	Public Height As UShort
	Public OffsetX As UShort
	Public OffsetY As UShort
	Public PixelFormat As ZCL_PIXELFORMATID
	Public FrameRateAuto As Boolean
	Public FrameRate As Single
End Class


'	SetStreamMode 
<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_SETSTREAMMODE
	Public Width As UShort
	Public Height As UShort
	Public OffsetX As UShort
	Public OffsetY As UShort
	Public PixelFormat As ZCL_PIXELFORMATID
	Public FrameRateAuto As Boolean
	Public FrameRate As Single
End Class


'	GetStreamMode 
'	SetStreamMode 
<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_HEARTBEATMODE
	Public Exec_Flag As Boolean
	Public TimeCount As UInteger
End Class


'	GetPixelFormat
<StructLayout(LayoutKind.Sequential)> _
Public Class ZCL_PIXELFORMATLIST
	Public Count As UInteger
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public PixelFormat As ZCL_PIXELFORMATID()
End Class


'	GetExtModeInfo 
<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_EXTMODEINFO
	Public ModeCount As UInteger
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public MaxWidth As UShort()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public MaxHeight As UShort()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public UnitSizeX As UShort()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public UnitSizeY As UShort()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public UnitPosX As UShort()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public UnitPosY As UShort()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_MONO As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_YUV411 As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_YUV422 As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_YUV444 As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_RGB As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_MONO16 As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_RGB16 As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_SMONO16 As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_SRGB16 As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_RAW As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_RAW16 As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_MONO12 As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_RAW12 As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_MONO10 As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_RAW10 As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_BGR As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_BGR16 As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_RGBA As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_BGRA As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_RGB10G As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_RGB10P As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_RGB12 As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_RGB565 As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_BGR565 As Boolean()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
	Public C_YUV422Y As Boolean()
End Class


'	CheckFeature 
<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_CHECKFEATURE
	Public FeatureID As ZCL_FEATUREID
	Public PresenceFlag As Boolean

	Public Abs_Inq As Boolean
	Public One_Push_Inq As Boolean
	Public ReadOut_Inq As Boolean
	Public On_Off_Inq As Boolean
	Public Auto_Inq As Boolean
	Public Manual_Inq As Boolean
	Public Min_Value As UInteger
	Public Max_Value As UInteger
	Public Abs_Min_Value As Single
	Public Abs_Max_Value As Single

	Public Trigger_Abs_Inq As Boolean
	Public Trigger_ReadOut_Inq As Boolean
	Public Trigger_On_Off_Inq As Boolean
	Public Trigger_Polarity_Inq As Boolean
	Public Trigger_Value_Read_Inq As Boolean
	Public Trigger_Source0 As Boolean
	Public Trigger_Source1 As Boolean
	Public Trigger_Source2 As Boolean
	Public Trigger_Source3 As Boolean
	Public Trigger_Software As Boolean
	Public Trigger_Mode0 As Boolean
	Public Trigger_Mode1 As Boolean
	Public Trigger_Mode2 As Boolean
	Public Trigger_Mode3 As Boolean
	Public Trigger_Mode4 As Boolean
	Public Trigger_Mode5 As Boolean
	Public Trigger_Mode14 As Boolean
	Public Trigger_Mode15 As Boolean
	Public Trigger_Abs_Min_Value As Single
	Public Trigger_Abs_Max_Value As Single

	Public Max_MemChannel As Byte
End Class


'	GetFeatureValue 
<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_GETFEATUREVALUE
	Public FeatureID As ZCL_FEATUREID

	Public Abs As Boolean
	Public On_Off As Boolean
	Public Auto_M As Boolean
	Public Value As UInteger
	Public Abs_Value As Single

	Public WhiteBalance_Abs As Boolean
	Public WhiteBalance_On_Off As Boolean
	Public WhiteBalance_Auto_M As Boolean
	Public WhiteBalance_UB_Value As UInteger
	Public WhiteBalance_VR_Value As UInteger
	Public WhiteBalance_Abs_Value As Single

	Public Temperature_Abs As Boolean
	Public Temperature_On_Off As Boolean
	Public Temperature_Auto_M As Boolean
	Public Temperature_Target_Value As UInteger
	Public Temperature_Temp_Value As UInteger
	Public Temperature_Abs_Value As Single

	Public Trigger_Abs As Boolean
	Public Trigger_On_Off As Boolean
	Public Trigger_Polarity As Boolean
	Public Trigger_Value As Boolean
	Public Trigger_Source As Byte
	Public Trigger_Mode As Byte
	Public Trigger_Parameter As UInteger
	Public Trigger_Abs_Value As Single

	Public TriggerDelay_Abs As Boolean
	Public TriggerDelay_On_Off As Boolean
	Public TriggerDelay_Value As UInteger
	Public TriggerDelay_Abs_Value As Single

	Public WhiteShading_Abs As Boolean
	Public WhiteShadingOn_Off As Boolean
	Public WhiteShadingAuto_M As Boolean
	Public WhiteShadingR_Value As Byte
	Public WhiteShadingG_Value As Byte
	Public WhiteShadingB_Value As Byte
	Public WhiteShadingAbs_Value As Single

	Public Exec_Flag As Boolean
	Public PowerOn_Flag As Boolean
End Class


'	SetFeatureValue 
<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_SETFEATUREVALUE
	Public ReqID As ZCL_SETREQID
	Public FeatureID As ZCL_FEATUREID

	Public Value As UInteger
	Public Abs_Value As Single

	Public WhiteBalance_UB_Value As UInteger
	Public WhiteBalance_VR_Value As UInteger
	Public WhiteBalance_Abs_Value As Single

	Public Trigger_Polarity As Boolean
	Public Trigger_Source As Byte
	Public Trigger_Mode As Byte
	Public Trigger_Parameter As UInteger
	Public Trigger_Abs_Value As Single

	Public WhiteShading_R_Value As Byte
	Public WhiteShading_G_Value As Byte
	Public WhiteShading_B_Value As Byte
	Public WhiteShading_Abs_Value As Single
End Class


'	GetImageInfo 
<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_GETIMAGEINFO
	Public StdMode_Flag As Boolean
	Public PosX As UShort
	Public PosY As UShort
	Public Width As UShort
	Public Height As UShort
	Public ColorID As ZCL_COLORID
	Public DataLength As UInteger
	Public Buffer As UInteger
	Public MaxImageX As UShort
	Public MaxImageY As UShort
	Public UnitSizeX As UShort
	Public UnitSizeY As UShort
	Public UnitPosX As UShort
	Public UnitPosY As UShort
End Class


'	SetImageInfo 
<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_SETIMAGEINFO
	Public PosX As UShort
	Public PosY As UShort
	Public Width As UShort
	Public Height As UShort
	Public MaxSize_Flag As Boolean
End Class


'	StreamComplete 
<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_STREAMINFOV0_IMAGE
	Public Ver As UInteger
	Public Stream_Type As UShort
	Public Fream_ID As UShort

	Public TimeStamp As ULong

	Public Pixel_Type As ZCL_PIXELFORMATID
	Public Width As UInteger
	Public Height As UInteger
	Public Offset_X As UInteger
	Public Offset_Y As UInteger
	Public Padding_X As UShort
	Public Padding_Y As UShort
	Public Size_Y As UInteger
End Class


'	StreamComplete 
<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_STREAMINFOV0_RAW
	Public Ver As UInteger
	Public Stream_Type As UShort
	Public Fream_ID As UShort

	Public TimeStamp As ULong

	Public DataSize As ULong
End Class


'	StreamComplete 
<StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi)> _
 Public Class ZCL_STREAMINFOV0_FILE
	Public Ver As UInteger
	Public Stream_Type As UShort
	Public Fream_ID As UShort

	Public TimeStamp As ULong

	Public DataSize As ULong
	<MarshalAs(UnmanagedType.ByValTStr, SizeConst:=512)> _
	Public File_Name As String
End Class


'	StreamComplete 
<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_STREAMINFOV0_CHUNK
	Public Ver As UInteger
	Public Stream_Type As UShort
	Public Fream_ID As UShort

	Public TimeStamp As ULong

	Public DataSize As UInteger
End Class


'	StreamComplete 
<StructLayout(LayoutKind.Sequential)> _
Public Class ZCL_STREAMINFOV0_EXT_CHUNK
	Public Ver As UInteger
	Public Stream_Type As UShort
	Public Fream_ID As UShort

	Public TimeStamp As ULong

	Public Pixel_Type As ZCL_PIXELFORMATID
	Public Width As UInteger
	Public Height As UInteger
	Public Offset_X As UInteger
	Public Offset_Y As UInteger
	Public Padding_X As UShort
	Public Padding_Y As UShort
	Public DataSize As UInteger
	Public Size_Y As UInteger
	Public Chunk_ID As UInteger
End Class


'	StreamComplete 
<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_STREAMINFOV0_VENDOR
	Public Ver As UInteger
	Public Stream_Type As UShort
	Public Fream_ID As UShort

	Public TimeStamp As ULong

	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=128)> _
	Public Vendor_Data As UInteger()
End Class


'	StreamComplete 
<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_STREAMINFOV1_IMAGE
	Public Ver As UInteger
	Public Stream_Type As ULong
	Public Fream_ID As ULong

	Public TimeStamp As ULong

	Public Pixel_Type As ZCL_PIXELFORMATID
	Public Width As UInteger
	Public Height As UInteger
	Public Offset_X As UInteger
	Public Offset_Y As UInteger
	Public Padding_X As UShort
	Public Padding_Y As UShort
	Public Size_Y As UInteger
End Class


'	StreamComplete 
<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_STREAMINFOV10_RAW
	Public Ver As UInteger
	Public Stream_Type As ULong
	Public Fream_ID As ULong

	Public TimeStamp As ULong

	Public DataSize As ULong
End Class


'	StreamComplete 
<StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi)> _
 Public Class ZCL_STREAMINFOV1_FILE
	Public Ver As UInteger
	Public Stream_Type As ULong
	Public Fream_ID As ULong

	Public TimeStamp As ULong

	Public DataSize As ULong
	<MarshalAs(UnmanagedType.ByValTStr, SizeConst:=512)> _
	Public File_Name As String
End Class


'	StreamComplete 
<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_STREAMINFOV1_CHUNK
	Public Ver As UInteger
	Public Stream_Type As ULong
	Public Fream_ID As ULong

	Public TimeStamp As ULong

	Public DataSize As UInteger
End Class


'	StreamComplete 
<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_STREAMINFOV1_EXT_CHUNK
	Public Ver As UInteger
	Public Stream_Type As ULong
	Public Fream_ID As ULong

	Public TimeStamp As ULong

	Public Pixel_Type As ZCL_PIXELFORMATID
	Public Width As UInteger
	Public Height As UInteger
	Public Offset_X As UInteger
	Public Offset_Y As UInteger
	Public Padding_X As UShort
	Public Padding_Y As UShort
	Public DataSize As UInteger
	Public Size_Y As UInteger
	Public Chunk_ID As UInteger
End Class


'	StreamComplete 
<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_STREAMINFOV1_VENDOR
	Public Ver As UInteger
	Public Stream_Type As ULong
	Public Fream_ID As ULong

	Public TimeStamp As ULong

	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=128)> _
	Public Vendor_Data As UInteger()
End Class


' 
<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_IMAGEDATAINFO_1394
	Public CameraType As ZCL_CAMERATYPE
	Public Speed As ZCL_TRANSMITSPEED
	Public CycleTime_S As UInteger
	Public CycleCount_S As UInteger
	Public CycleTime_E As UInteger
	Public CycleCount_E As UInteger
End Class


' 
<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_IMAGEDATAINFO_GIGE
	Public CameraType As ZCL_CAMERATYPE
	Public PktInfo As IntPtr
	Public PktInfoLen As UInteger
	Public StreamInfo As ZCL_STREAMINFOV0_IMAGE
End Class


Public Enum ZCL_CFILTERMODE_SONY
	ZCL_SONYGBRG = 0					'	GB/RG
	ZCL_SONYBGGR						'	BG/GR
	ZCL_SONYRGGB						'	RG/GB
	ZCL_SONYGRBG						'	GR/BG
End Enum


'	GetRegister 
'	GetExtRegister 
'	SetRegister 
'	SetExtRegister 
<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_REGISTER
	Public Offset As UInteger
	Public Size As UInteger
	Public Value As IntPtr
End Class


'	GigEGetRegister 
'	GigESetRegister 
<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_GIGEREGISTER
	Public Count As UInteger
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=135)> _
	Public Addr As UInteger()
	<MarshalAs(UnmanagedType.ByValArray, SizeConst:=135)> _
	Public Value As UInteger()
End Class


<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_COLORVALUE
	Public a As Double
	Public b As Double
	Public c As Double
	Public d As Double
End Class


<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_COLORMODE
	Public ColorID As ZCL_COLORID
	Public CFilter As ZCL_CFILTERMODE
	Public StoreMode As ZCL_STOREMODE
	Public EndianMode As ZCL_ENDIAN
	Public Parallel_Flag As Boolean
End Class


<StructLayout(LayoutKind.Sequential)> _
 Public Class ZCL_RECT
	Public Left As Integer
	Public Top As Integer
	Public Right As Integer
	Public Bottom As Integer
End Class


<StructLayout(LayoutKind.Sequential)> _
Public Class ZCL_BITMAPINFO
	Public biSize As UInteger
	Public biWidth As Integer
	Public biHeight As Integer
	Public biPlanes As UShort
	Public biBitCount As UShort
	Public biCompression As UInteger
	Public biSizeImage As UInteger
	Public biXPelsPerMeter As Integer
	Public biYPelsPerMeter As Integer
	Public biClrUsed As UInteger
	Public biClrImportant As UInteger
	Public RGBQUAD As UInteger
End Class


Public Class ZCL
	Public Delegate Sub SystemFunc(ByVal SystemStatus As STATUS_SYSTEMCODE, ByVal Context As IntPtr)
	Public Delegate Sub ImageFunc(ByVal h_Camera As IntPtr, ByVal pBuf As IntPtr, ByVal Length As UInteger, ByVal Width As UInteger, ByVal Height As UInteger, ByVal pInfo As IntPtr, ByVal Context As IntPtr)

	Public Const ZCL_LIBRARY_STRUCT_VERSION As Integer = 210

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSetCallBack")> _
	Public Shared Sub SetCallBack(ByVal Context As IntPtr, ByVal cb As SystemFunc)
	End Sub

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSetCallBack")> _
	Public Shared Sub SetCallBack(ByVal Context As IntPtr, ByVal cb As IntPtr)
	End Sub

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSetStructVersion")> _
	Public Shared Sub SetStructVersion(ByVal VerNo As UInteger)
	End Sub

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGetLastError")> _
	Public Shared Function GetLastError() As STATUS_RTNCODE
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGetList")> _
 Public Shared Function GetList(ByRef Count As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGetList")> _
 Public Shared Function GetList(ByVal List As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLOpen")> _
	Public Shared Function Open(ByVal UID As ULong, ByRef h_Camera As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLClose")> _
	Public Shared Function Close(ByVal h_Camera As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLCameraInfo")> _
	Public Shared Function CameraInfo(ByVal h_Camera As IntPtr, <Out()> ByVal CInfo As ZCL_CAMERAINFO, ByRef Speed As ZCL_TRANSMITSPEED) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLCameraInfo")> _
	Public Shared Function CameraInfo(ByVal h_Camera As IntPtr, <Out()> ByVal CInfo As ZCL_CAMERAINFO, ByVal Speed As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLCameraInfo")> _
	Public Shared Function CameraInfo(ByVal h_Camera As IntPtr, ByVal CInfo As IntPtr, ByRef Speed As ZCL_TRANSMITSPEED) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLCameraBusInfo")> _
	Public Shared Function CameraBusInfo(ByVal h_Camera As IntPtr, ByRef BusInfo As UInteger, ByRef CameraType As ZCL_CAMERATYPE) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLCameraBusInfo")> _
	Public Shared Function CameraBusInfo(ByVal h_Camera As IntPtr, ByRef BusInfo As UInteger, ByVal CameraType As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLCameraBusInfo")> _
	Public Shared Function CameraBusInfo(ByVal h_Camera As IntPtr, ByVal BusInfo As IntPtr, ByRef CameraType As ZCL_CAMERATYPE) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLAllClose")> _
	Public Shared Sub AllClose()
	End Sub

	<DllImport("ZCL.DLL", EntryPoint:="ZCLCamera")> _
	Public Shared Function Camera(ByVal h_Camera As IntPtr, ByRef Ari_Flag As Boolean) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLCameraInit")> _
	Public Shared Function CameraInit(ByVal h_Camera As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLCheckCameraMode")> _
	Public Shared Function CheckCameraMode(ByVal h_Camera As IntPtr, <[In]()> ByVal CameraMode As ZCL_CAMERAMODESTD) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLCheckCameraMode")> _
	Public Shared Function CheckCameraMode(ByVal h_Camera As IntPtr, <[In]()> ByVal CameraMode As ZCL_CAMERAMODEEXT) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSetCameraMode")> _
	Public Shared Function SetCameraMode(ByVal h_Camera As IntPtr, <[In]()> ByVal CameraMode As ZCL_CAMERAMODESTD) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSetCameraMode")> _
	Public Shared Function SetCameraMode(ByVal h_Camera As IntPtr, <[In]()> ByVal CameraMode As ZCL_CAMERAMODEEXT) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLNowCameraMode")> _
	Public Shared Function NowCameraMode(ByVal h_Camera As IntPtr, ByVal CameraMode As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGetExtModeInfoCS")> _
	Public Shared Function GetExtModeInfo(ByVal h_Camera As IntPtr, <Out()> ByVal ExtInfo As ZCL_EXTMODEINFO) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSaveMem")> _
	Public Shared Function SaveMem(ByVal h_Camera As IntPtr, ByVal MemoryNo As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLLoadMem")> _
	Public Shared Function LoadMem(ByVal h_Camera As IntPtr, ByVal MemoryNo As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLCheckFeatureCS")> _
	Public Shared Function CheckFeature(ByVal h_Camera As IntPtr, <[In](), Out()> ByVal Feature As ZCL_CHECKFEATURE) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGetFeatureValueCS")> _
	Public Shared Function GetFeatureValue(ByVal h_Camera As IntPtr, <[In](), Out()> ByVal Feature As ZCL_GETFEATUREVALUE) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSetFeatureValueCS")> _
	Public Shared Function SetFeatureValue(ByVal h_Camera As IntPtr, <[In]()> ByVal Feature As ZCL_SETFEATUREVALUE) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGetImageInfo")> _
	Public Shared Function GetImageInfo(ByVal h_Camera As IntPtr, <Out()> ByVal ImageInfo As ZCL_GETIMAGEINFO) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSetImageInfo")> _
	Public Shared Function SetImageInfo(ByVal h_Camera As IntPtr, <[In]()> ByVal ImageInfo As ZCL_SETIMAGEINFO) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSetImageInfo2")> _
	Public Shared Function SetImageInfo(ByVal h_Camera As IntPtr, <[In]()> ByVal ImageInfo As ZCL_SETIMAGEINFO, ByRef MinPktLen As UInteger, ByRef MaxPktLen As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSetPktSize")> _
	Public Shared Function SetPktSize(ByVal h_Camera As IntPtr, ByVal Number As UInteger, ByRef PktLen As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSetPktSize")> _
	Public Shared Function SetPktSize(ByVal h_Camera As IntPtr, ByVal Number As UInteger, ByVal PktLen As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLIsoAlloc")> _
	Public Shared Function IsoAlloc(ByVal h_Camera As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLIsoRelease")> _
	Public Shared Function IsoRelease(ByVal h_Camera As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLIsoStart")> _
	Public Shared Function IsoStart(ByVal h_Camera As IntPtr, ByVal Start_Mode As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLIsoStop")> _
	Public Shared Function IsoStop(ByVal h_Camera As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSoftTrigger")> _
	Public Shared Function SoftTrigger(ByVal h_Camera As IntPtr, ByVal On_Flag As Boolean) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLImageReq")> _
	Public Shared Function ImageReq(ByVal h_Camera As IntPtr, ByVal Buffer As IntPtr, ByVal Length As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLImageCompleteWait")> _
	Public Shared Function ImageComplete(ByVal h_Camera As IntPtr, ByVal Buffer As IntPtr, ByRef Speed As ZCL_TRANSMITSPEED, ByRef Cycle_Time As UInteger, ByRef Cycle_Count As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLImageCompleteWait")> _
	Public Shared Function ImageComplete(ByVal h_Camera As IntPtr, ByVal Buffer As IntPtr, ByRef Speed As ZCL_TRANSMITSPEED, ByVal Cycle_Time As IntPtr, ByVal Cycle_Count As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLImageCompleteWait")> _
	Public Shared Function ImageComplete(ByVal h_Camera As IntPtr, ByVal Buffer As IntPtr, ByVal Speed As IntPtr, ByRef Cycle_Time As UInteger, ByRef Cycle_Count As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLImageCompleteWaitTimeOut")> _
	Public Shared Function ImageComplete(ByVal h_Camera As IntPtr, ByVal Buffer As IntPtr, ByRef Speed As ZCL_TRANSMITSPEED, ByRef Cycle_Time As UInteger, ByRef Cycle_Count As UInteger, ByVal TimeOut As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLImageCompleteWaitTimeOut")> _
	Public Shared Function ImageComplete(ByVal h_Camera As IntPtr, ByVal Buffer As IntPtr, ByRef Speed As ZCL_TRANSMITSPEED, ByVal Cycle_Time As IntPtr, ByVal Cycle_Count As IntPtr, ByVal TimeOut As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLImageCompleteWaitTimeOut")> _
	Public Shared Function ImageComplete(ByVal h_Camera As IntPtr, ByVal Buffer As IntPtr, ByVal Speed As IntPtr, ByRef Cycle_Time As UInteger, ByRef Cycle_Count As UInteger, ByVal TimeOut As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLAbortImageReqAll")> _
	Public Shared Function AbortImageReqAll(ByVal h_Camera As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLVSyncReq")> _
	Public Shared Function VSyncReq(ByVal h_Camera As IntPtr, ByRef Vsync As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLVSyncCompleteWait")> _
	Public Shared Function VSyncComplete(ByVal h_Camera As IntPtr, ByVal Vsync As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLVSyncCompleteWaitTimeOut")> _
	Public Shared Function VSyncComplete(ByVal h_Camera As IntPtr, ByVal Vsync As IntPtr, ByVal TimeOut As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSetImageCallBack")> _
	Public Shared Function SetImageCallBack(ByVal h_Camera As IntPtr, ByVal Context As IntPtr, ByVal cb As ImageFunc, ByVal Count As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSetImageCallBack")> _
	Public Shared Function SetImageCallBack(ByVal h_Camera As IntPtr, ByVal Context As IntPtr, ByVal cb As IntPtr, ByVal Count As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGetRegister")> _
	Public Shared Function GetRegister(ByVal h_Camera As IntPtr, <[In]()> ByVal RegReq As ZCL_REGISTER) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGetExtRegister")> _
	Public Shared Function GetExtRegister(ByVal h_Camera As IntPtr, <[In]()> ByVal RegReq As ZCL_REGISTER) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSetRegister")> _
	Public Shared Function SetRegister(ByVal h_Camera As IntPtr, <[In]()> ByVal RegReq As ZCL_REGISTER) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSetExtRegister")> _
	Public Shared Function SetExtRegister(ByVal h_Camera As IntPtr, <[In]()> ByVal RegReq As ZCL_REGISTER) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGetConfigROM")> _
	Public Shared Function GetConfigROM(ByVal h_Camera As IntPtr, ByVal ConfigROM As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGetDataDepth")> _
	Public Shared Function GetDataDepth(ByVal h_Camera As IntPtr, ByRef DataDepth As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLBroadcastPkt")> _
	Public Shared Function BroadcastPkt(ByVal h_Camera As IntPtr, <[In]()> ByVal RegReq As ZCL_REGISTER) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLBroadcastPktAll")> _
	Public Shared Function BroadcastPktAll(ByVal h_Camera As IntPtr, <[In]()> ByVal RegReq As ZCL_REGISTER) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGetLibraryRevision")> _
	Public Shared Function GetLibraryRevision() As UInteger
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLReset")> _
	Public Shared Function Reset() As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLReDetection")> _
	Public Shared Sub ReDetection()
	End Sub

	<DllImport("ZCL.DLL", EntryPoint:="ZCLShutterAbsAuto")> _
	Public Shared Function ShutterAbsAuto(ByVal h_Camera As IntPtr) As Boolean
	End Function



	<DllImport("ZCL.DLL", EntryPoint:="ZCLOnePushAWB")> _
	Public Shared Function OnePushAWB(ByVal h_Camera As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLOnePushAWBComplete")> _
	Public Shared Function OnePushAWBComplete(ByVal h_Camera As IntPtr, ByVal TimeOut As UInteger) As Boolean
	End Function


	'************************************************
	'	Watch API									*
	'************************************************
	<DllImport("ZCL.DLL", EntryPoint:="ZCLWatchOpen")> _
	Public Shared Function WatchOpen(ByVal UID As ULong, ByRef h_Camera As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLWatchClose")> _
	Public Shared Function WatchClose(ByVal h_Camera As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLWatchCamera")> _
	Public Shared Function WatchCamera(ByVal h_Camera As IntPtr, ByRef Start_OKFlag As Boolean) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLWatchAlloc")> _
	Public Shared Function WatchAlloc(ByVal h_Camera As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLWatchRelease")> _
	Public Shared Function WatchRelease(ByVal h_Camera As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLWatchStart")> _
	Public Shared Function WatchStart(ByVal h_Camera As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLWatchStop")> _
	Public Shared Function WatchStop(ByVal h_Camera As IntPtr) As Boolean
	End Function
	'************************************************
	'	Watch API End								*
	'************************************************


	'************************************************
	'	GigE Only API								*
	'************************************************
	<DllImport("ZCL.DLL", EntryPoint:="ZCLGigECameraInfo")> _
	Public Shared Function GigECameraInfo(ByVal h_Camera As IntPtr, <Out()> ByVal CameraInfo As ZCL_GIGECAMERAINFO, ByRef BusInfo As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGigECameraInfo")> _
	Public Shared Function GigECameraInfo(ByVal h_Camera As IntPtr, <Out()> ByVal CameraInfo As ZCL_GIGECAMERAINFO, ByVal BusInfo As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGetStreamMode")> _
	Public Shared Function GetStreamMode(ByVal h_Camera As IntPtr, <Out()> ByVal StreamMode As ZCL_GETSTREAMMODE, ByRef PktLen As UInteger, <Out()> ByVal HBMode As ZCL_HEARTBEATMODE) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGetStreamMode")> _
	Public Shared Function GetStreamMode(ByVal h_Camera As IntPtr, ByVal StreamMode As IntPtr, ByRef PktLen As UInteger, <Out()> ByVal HBMode As ZCL_HEARTBEATMODE) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGetStreamMode")> _
	Public Shared Function GetStreamMode(ByVal h_Camera As IntPtr, <Out()> ByVal StreamMode As ZCL_GETSTREAMMODE, ByVal PktLen As IntPtr, <Out()> ByVal HBMode As ZCL_HEARTBEATMODE) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGetStreamMode")> _
	Public Shared Function GetStreamMode(ByVal h_Camera As IntPtr, <Out()> ByVal StreamMode As ZCL_GETSTREAMMODE, ByRef PktLen As UInteger, ByVal HBMode As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGetStreamMode")> _
	Public Shared Function GetStreamMode(ByVal h_Camera As IntPtr, ByVal StreamMode As IntPtr, ByVal PktLen As IntPtr, <Out()> ByVal HBMode As ZCL_HEARTBEATMODE) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGetStreamMode")> _
	Public Shared Function GetStreamMode(ByVal h_Camera As IntPtr, ByVal StreamMode As IntPtr, ByRef PktLen As UInteger, ByVal HBMode As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGetStreamMode")> _
	Public Shared Function GetStreamMode(ByVal h_Camera As IntPtr, <Out()> ByVal StreamMode As ZCL_GETSTREAMMODE, ByVal PktLen As IntPtr, ByVal HBMode As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSetStreamMode")> _
	Public Shared Function SetStreamMode(ByVal h_Camera As IntPtr, <[In]()> ByVal StreamMode As ZCL_SETSTREAMMODE, ByRef PktLen As UInteger, <[In]()> ByVal HBMode As ZCL_HEARTBEATMODE) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSetStreamMode")> _
	Public Shared Function SetStreamMode(ByVal h_Camera As IntPtr, ByVal StreamMode As IntPtr, ByRef PktLen As UInteger, <[In]()> ByVal HBMode As ZCL_HEARTBEATMODE) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSetStreamMode")> _
	Public Shared Function SetStreamMode(ByVal h_Camera As IntPtr, <[In]()> ByVal StreamMode As ZCL_SETSTREAMMODE, ByVal PktLen As IntPtr, <[In]()> ByVal HBMode As ZCL_HEARTBEATMODE) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSetStreamMode")> _
	Public Shared Function SetStreamMode(ByVal h_Camera As IntPtr, <[In]()> ByVal StreamMode As ZCL_SETSTREAMMODE, ByRef PktLen As UInteger, ByVal HBMode As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSetStreamMode")> _
	Public Shared Function SetStreamMode(ByVal h_Camera As IntPtr, ByVal StreamMode As IntPtr, ByVal PktLen As IntPtr, <[In]()> ByVal HBMode As ZCL_HEARTBEATMODE) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSetStreamMode")> _
	Public Shared Function SetStreamMode(ByVal h_Camera As IntPtr, ByVal StreamMode As IntPtr, ByRef PktLen As UInteger, ByVal HBMode As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLSetStreamMode")> _
	Public Shared Function SetStreamMode(ByVal h_Camera As IntPtr, <[In]()> ByVal StreamMode As ZCL_SETSTREAMMODE, ByVal PktLen As IntPtr, ByVal HBMode As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGetPixelFormat")> _
	Public Shared Function GetPixelFormat(ByVal h_Camera As IntPtr, <Out()> ByVal PixelList As ZCL_PIXELFORMATLIST) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLBandAdjust")> _
	Public Shared Function BandAdjust(ByVal h_Camera As IntPtr, ByVal On_Flag As Boolean, ByVal Level As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGigEGetPktSize")> _
	Public Shared Function GigEGetPktSize(ByVal h_Camera As IntPtr, ByRef PktLen As UInteger, ByRef MinLen As UInteger, ByRef MaxLen As UInteger, ByRef IncLen As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGigESetPktSize")> _
	Public Shared Function GigESetPktSize(ByVal h_Camera As IntPtr, ByVal PktLen As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLTestStream")> _
	Public Shared Function TestStream(ByVal h_Camera As IntPtr, ByVal PktLen As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLStreamAlloc")> _
	Public Shared Function StreamAlloc(ByVal h_Camera As IntPtr, ByVal IPAddr() As Byte, ByVal Recover_Flag As Boolean) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLStreamAlloc")> _
	Public Shared Function StreamAlloc(ByVal h_Camera As IntPtr, ByVal IPAddr As IntPtr, ByVal Recover_Flag As Boolean) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLStreamRelease")> _
	Public Shared Function StreamRelease(ByVal h_Camera As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLStreamStart")> _
	Public Shared Function StreamStart(ByVal h_Camera As IntPtr, ByVal StartMode As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLStreamStop")> _
	Public Shared Function StreamStop(ByVal h_Camera As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLStreamReq")> _
	Public Shared Function StreamReq(ByVal h_Camera As IntPtr, ByVal Buffer As IntPtr, ByVal Length As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLStreamComplete")> _
	Public Shared Function StreamComplete(ByVal h_Camera As IntPtr, ByVal Buffer As IntPtr, ByVal TimeOut As UInteger, ByVal StreamInfo As IntPtr, ByRef PktInfo As IntPtr, ByRef PktInfoLen As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLStreamComplete")> _
	Public Shared Function StreamComplete(ByVal h_Camera As IntPtr, ByVal Buffer As IntPtr, ByVal TimeOut As UInteger, ByVal StreamInfo As IntPtr, ByVal PktInfo As IntPtr, ByVal PktInfoLen As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLAbortStreamReqAll")> _
	Public Shared Function AbortStreamReqAll(ByVal h_Camera As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGigEGetRegister")> _
	Public Shared Function GigEGetRegister(ByVal h_Camera As IntPtr, <[In](), Out()> ByVal RegReq As ZCL_GIGEREGISTER) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGigESetRegister")> _
	Public Shared Function GigESetRegister(ByVal h_Camera As IntPtr, <[In]()> ByVal RegReq As ZCL_GIGEREGISTER) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGigEGetMemory")> _
	Public Shared Function GigEGetMemory(ByVal h_Camera As IntPtr, <[In]()> ByVal RegReq As ZCL_REGISTER) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLGigESetMemory")> _
	Public Shared Function GigESetMemory(ByVal h_Camera As IntPtr, <[In]()> ByVal RegReq As ZCL_REGISTER) As Boolean
	End Function
	'************************************************
	'	GigE Only API End							*
	'************************************************


	'************************************************
	'	Color Convert								*
	'************************************************
	<DllImport("ZCL.DLL", EntryPoint:="ZCLCreateConvHandle")> _
	Public Shared Function CreateConvHandle(ByRef hCtbl As IntPtr, ByVal ConvertMode As ZCL_CONVERTMODE, ByVal ShiftID As ZCL_SHIFTID, <[In]()> ByVal ColorValue As ZCL_COLORVALUE) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLCreateConvHandle")> _
	Public Shared Function CreateConvHandle(ByRef hCtbl As IntPtr, ByVal ConvertMode As ZCL_CONVERTMODE, ByVal ShiftID As ZCL_SHIFTID, ByVal ColorValue As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLCloseConvHandle")> _
	Public Shared Sub CloseConvHandle(ByVal hCtbl As IntPtr)
	End Sub

	<DllImport("ZCL.DLL", EntryPoint:="ZCLCloseAllConvHandle")> _
	Public Shared Sub CloseAllConvHandle()
	End Sub

	<DllImport("ZCL.DLL", EntryPoint:="ZCLColorConvExec")> _
	Public Shared Function ColorConvExec(ByVal hCtbl As IntPtr, ByVal Width As UInteger, ByVal Height As UInteger, <[In]()> ByVal Mode As ZCL_COLORMODE, ByVal InBuf As IntPtr, ByVal OutBuf As IntPtr) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLColorConvSetBMPINFO")> _
	Public Shared Function ColorConvSetBMPINFO(ByVal hCtbl As IntPtr, ByVal Width As UInteger, ByVal Height As UInteger, <Out()> ByVal BmpInfo As ZCL_BITMAPINFO) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLCreateMonoBMPINFO")> _
	Public Shared Function CreateMonoBMPINFO(ByVal Width As UInteger, ByVal Height As UInteger, ByRef Bmp As IntPtr, ByRef Length As UInteger) As Boolean
	End Function

	<DllImport("ZCL.DLL", EntryPoint:="ZCLDeleteMonoBMPINFO")> _
	Public Shared Sub DeleteMonoBMPINFO(ByVal Bmp As IntPtr)
	End Sub

	<DllImport("ZCL.DLL", EntryPoint:="ZCLDeleteAllMonoBMPINFO")> _
	Public Shared Sub DeleteAllMonoBMPINFO()
	End Sub
End Class
