#pragma once
#include "afxwin.h"


// CCtlWnd dialog

class CCtlWnd : public CDialog
{
	DECLARE_DYNAMIC(CCtlWnd)

public:
	CCtlWnd(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCtlWnd();

// Dialog Data
	enum { IDD = IDD_CTLWND };

	CStatic	m_StZoom;
	CStatic	m_StWhite;
	CStatic	m_StTilt;
	CStatic	m_StShutter;
	CStatic	m_StSharp;
	CStatic	m_StSaturation;
	CStatic	m_StPan;
	CStatic	m_StOptical;
	CStatic	m_StIris;
	CStatic	m_StHue;
	CStatic	m_StGamma;
	CStatic	m_StGain;
	CStatic	m_StFocus;
	CStatic	m_StBright;
	CStatic	m_StAe;
	CSliderCtrl	m_SlZoom;
	CSliderCtrl	m_SlWhiteV;
	CSliderCtrl	m_SlWhiteU;
	CSliderCtrl	m_SlTilt;
	CSliderCtrl	m_SlShutter;
	CSliderCtrl	m_SlSharp;
	CSliderCtrl	m_SlSaturation;
	CSliderCtrl	m_SlPan;
	CSliderCtrl	m_SlOptical;
	CSliderCtrl	m_SlIris;
	CSliderCtrl	m_SlHue;
	CSliderCtrl	m_SlGamma;
	CSliderCtrl	m_SlGain;
	CSliderCtrl	m_SlFocus;
	CSliderCtrl	m_SlBright;
	CSliderCtrl	m_SlAe;
	CButton	m_AutoZoom;
	CButton	m_AutoWhite;
	CButton	m_AutoTilt;
	CButton	m_AutoShutter;
	CButton	m_AutoSharp;
	CButton	m_AutoSaturation;
	CButton	m_AutoPan;
	CButton	m_AutoOptical;
	CButton	m_AutoIris;
	CButton	m_AutoHue;
	CButton	m_AutoGamma;
	CButton	m_AutoGain;
	CButton	m_AutoFocus;
	CButton	m_AutoBright;
	CButton	m_AutoAe;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
protected:
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);

protected:
	HCAMERA	m_hCamera;
	HICON	m_hIcon;
};
