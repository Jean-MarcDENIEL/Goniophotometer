Public Class Form1
	Private hCamera As IntPtr
	Private ParamCB As GCHandle
	Private SystemCB As New ZCL.SystemFunc(AddressOf Me.SystemCallback)
	Private ColorMode As New ZCL_COLORMODE
	Private hTbl As IntPtr
	Private RGBImage As IntPtr
	Private ShiftID As ZCL_SHIFTID
	Private Sony_CR As Boolean = False
	Private Rcv_Thread As New Thread(New ParameterizedThreadStart(AddressOf Me.Rcv_ThreadDoWork))
	Private Thread_End As New ManualResetEvent(False)
	Private GetImage As New ZCL_GETIMAGEINFO
	Private BmpInfo As New ZCL_BITMAPINFO
	Private Gra As Graphics
	Private FileName As String = ""
	Private FileIdx As UInteger = 0

	Public Sub New()
		Dim CameraInfo As New ZCL_CAMERAINFO
		Dim CameraType As ZCL_CAMERATYPE
		Dim CameraMode As IntPtr
		Dim CameraExtMode As New ZCL_CAMERAMODEEXT
		Dim Data As UInteger

		'Required by the Windows Form Designer
		InitializeComponent()

		Save.Filter = "Bitmap Image|*.bmp|All Files|*.*"
		Save.Title = "Save an BMP File"
		If Save.ShowDialog() = DialogResult.OK Then FileName = Save.FileName

		ZCL.SetStructVersion(ZCL.ZCL_LIBRARY_STRUCT_VERSION)

		ParamCB = GCHandle.Alloc(Me)
		ZCL.SetCallBack(GCHandle.ToIntPtr(ParamCB), SystemCB)

		If Not ZCL.Open(ULong.MaxValue, hCamera) Then
			MessageBox.Show("Camera Not found")
			Exit Sub
		End If

		If Not ZCL.CameraInfo(hCamera, CameraInfo, IntPtr.Zero) Then
			MessageBox.Show("Get Camera Info Error")
			ZCL.Close(hCamera)
			hCamera = IntPtr.Zero
			Exit Sub
		End If

		Me.Text = String.Concat("External Trigger Sample   Model=", CameraInfo.VendorName, " ", CameraInfo.ModelName)

		If Not ZCL.CameraBusInfo(hCamera, IntPtr.Zero, CameraType) Then
			MessageBox.Show("Get Camera Bus Info Error")
			ZCL.Close(hCamera)
			hCamera = IntPtr.Zero
			Exit Sub
		End If

		If CameraInfo.VendorName.Equals("Sony", StringComparison.OrdinalIgnoreCase) _
		And CameraType = ZCL_CAMERATYPE.ZCL_CAMERA1394 _
		And CameraInfo.ModelName.Contains("CR") Then
			Sony_CR = True
		End If

#If False Then
        'When change Camera Mode

#If True Then
        'Standard mode

        Dim CameraStdMode As New ZCL_CAMERAMODESTD

        CameraStdMode.StdMode_Flag = True
        CameraStdMode.StdMode = ZCL_STDMODE.ZCL_VGA_MONO
        CameraStdMode.FrameRate = ZCL_FPS.ZCL_Fps_30
        If Not ZCL.SetCameraMode(hCamera, CameraStdMode) Then
            MessageBox.Show("Camera Mode Set Error")
            ZCL.Close(hCamera)
            ZCL.Close(hCamera)
            Exit Sub
        End If
#Else
        'Extended mode

        CameraExtMode.StdMode_Flag = False
        CameraExtMode.ExtMode = ZCL_EXTMODE.ZCL_Mode_0
        CameraExtMode.ColorID = ZCL_COLORID.ZCL_MONO
        If Not ZCL.SetCameraMode(hCamera, CameraExtMode) Then
            MessageBox.Show("Camera Mode Set Error")
            ZCL.Close(hCamera)
            hCamera = IntPtr.Zero
            Exit Sub
        End If

        Dim SetImage As New ZCL_SETIMAGEINFO

        ZCL.GetImageInfo(hCamera, GetImage)
        SetImage.PosX = 0
        SetImage.PosY = 0
        SetImage.Width = GetImage.Width
        SetImage.Height = GetImage.Height
        SetImage.MaxSize_Flag = True
        If Not ZCL.SetImageInfo(hCamera, SetImage) Then
            MessageBox.Show("Camera ImageSize Set Error")
            ZCL.Close(hCamera)
            hCamera = IntPtr.Zero
            Exit Sub
        End If
#End If
#End If

		CameraMode = Marshal.AllocCoTaskMem(Marshal.SizeOf(CameraExtMode))
		If Not ZCL.NowCameraMode(hCamera, CameraMode) Then
			MessageBox.Show("Camera Mode Get Error")
			ZCL.Close(hCamera)
			hCamera = IntPtr.Zero
			Marshal.FreeCoTaskMem(CameraMode)
			Exit Sub
		End If
		Marshal.PtrToStructure(CameraMode, CameraExtMode)
		Marshal.FreeCoTaskMem(CameraMode)

		If Not ZCL.GetImageInfo(hCamera, GetImage) Then
			MessageBox.Show("Camera ImageSize Get Error")
			ZCL.Close(hCamera)
			hCamera = IntPtr.Zero
			Exit Sub
		End If

		ColorMode.ColorID = GetImage.ColorID
		If CameraExtMode.StdMode_Flag = False AndAlso _
		(GetImage.ColorID = ZCL_COLORID.ZCL_RAW _
		  OrElse GetImage.ColorID = ZCL_COLORID.ZCL_RAW10 _
		  OrElse GetImage.ColorID = ZCL_COLORID.ZCL_RAW12 _
		 OrElse GetImage.ColorID = ZCL_COLORID.ZCL_RAW16) Then
			ColorMode.CFilter = CameraExtMode.FilterID
		ElseIf Sony_CR Then

			Dim GetFeature As New ZCL_GETFEATUREVALUE

			GetFeature.FeatureID = ZCL_FEATUREID.ZCL_OPTICAL_FILTER
			ZCL.GetFeatureValue(hCamera, GetFeature)
			Select Case GetFeature.Value
				Case ZCL_CFILTERMODE_SONY.ZCL_SONYGBRG
					ColorMode.CFilter = ZCL_CFILTERMODE.ZCL_FGBRG

				Case ZCL_CFILTERMODE_SONY.ZCL_SONYBGGR
					ColorMode.CFilter = ZCL_CFILTERMODE.ZCL_FBGGR

				Case ZCL_CFILTERMODE_SONY.ZCL_SONYRGGB
					ColorMode.CFilter = ZCL_CFILTERMODE.ZCL_FRGGB

				Case ZCL_CFILTERMODE_SONY.ZCL_SONYGRBG
					ColorMode.CFilter = ZCL_CFILTERMODE.ZCL_FGRBG
			End Select
		Else
			ColorMode.CFilter = ZCL_CFILTERMODE.ZCL_FRGGB
        End If

		ColorMode.StoreMode = ZCL_STOREMODE.ZCL_MEMmode
		If CameraType = ZCL_CAMERATYPE.ZCL_CAMERA1394 Then
			ColorMode.EndianMode = ZCL_ENDIAN.ZCL_BIGENDIAN
		Else
			ColorMode.EndianMode = ZCL_ENDIAN.ZCL_LITTLEENDIAN
		End If
        ColorMode.Parallel_Flag = True

		CameraMode = Marshal.AllocCoTaskMem(Marshal.SizeOf(CameraExtMode))
		ZCL.NowCameraMode(hCamera, CameraMode)
		Marshal.PtrToStructure(CameraMode, CameraExtMode)
		Marshal.FreeCoTaskMem(CameraMode)

		ZCL.CameraBusInfo(hCamera, IntPtr.Zero, CameraType)

		ShiftMenu.Enabled = False
		ShiftID = ZCL_SHIFTID.ZCL_SFT0
		Select Case ColorMode.ColorID
			Case ZCL_COLORID.ZCL_RAW
				ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW8G, ShiftID, IntPtr.Zero)

			Case ZCL_COLORID.ZCL_RAW10
				ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW10G, ShiftID, IntPtr.Zero)

			Case ZCL_COLORID.ZCL_RAW12
				ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW12G, ShiftID, IntPtr.Zero)

			Case ZCL_COLORID.ZCL_RAW16
				ShiftMenu.Enabled = True
				ZCL.GetDataDepth(hCamera, Data)
				If Data = 0 Then Data = 8
				ShiftID = Data - 8
				ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW16G, ShiftID, IntPtr.Zero)

			Case ZCL_COLORID.ZCL_RGB16, ZCL_COLORID.ZCL_SMONO16, ZCL_COLORID.ZCL_SRGB16, ZCL_COLORID.ZCL_BGR16
				ShiftMenu.Enabled = True
				ZCL.GetDataDepth(hCamera, Data)
				If Data = 0 Then Data = 8
				ShiftID = Data - 8
				ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_C32bit, ShiftID, IntPtr.Zero)

			Case ZCL_COLORID.ZCL_MONO16
				ShiftMenu.Enabled = True
				ZCL.GetDataDepth(hCamera, Data)
				If Data = 0 Then Data = 8
				ShiftID = Data - 8
				If Sony_CR Then
					ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW16G, ShiftID, IntPtr.Zero)
				Else
					ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_C32bit, ShiftID, IntPtr.Zero)
				End If

			Case ZCL_COLORID.ZCL_MONO
				If Sony_CR Then
					ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW8G, ShiftID, IntPtr.Zero)
				Else
					ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_C32bit, ShiftID, IntPtr.Zero)
				End If

			Case Else
				ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_C32bit, ShiftID, IntPtr.Zero)
		End Select
		ZCL.ColorConvSetBMPINFO(hTbl, GetImage.Width, GetImage.Height, BmpInfo)
		SetShiftMenuCheck()

		RGBImage = Marshal.AllocCoTaskMem(BmpInfo.biSizeImage)

		If Not ZCL.IsoAlloc(hCamera) Then
			MessageBox.Show("Isoc Alloc Error")
			ZCL.CloseConvHandle(hTbl)
			ZCL.Close(hCamera)
			hCamera = IntPtr.Zero
			Marshal.FreeCoTaskMem(RGBImage)
			Exit Sub
		End If

		Me.ClientSize = New System.Drawing.Size(GetImage.Width, GetImage.Height + Menu1.Size.Height + 2)
		Gra = Me.CreateGraphics()

		Dim Feature As New ZCL_SETFEATUREVALUE
		Feature.FeatureID = ZCL_FEATUREID.ZCL_TRIGGER
		Feature.ReqID = ZCL_SETREQID.ZCL_VALUE
		Feature.Trigger_Polarity = False
		Feature.Trigger_Source = ZCL_TRIGGERSOURCE.ZCL_Trigger_Source0
		Feature.Trigger_Mode = ZCL_TRIGGERMODE.ZCL_Trigger_Mode0
		Feature.Trigger_Parameter = 0
		If Not ZCL.SetFeatureValue(hCamera, Feature) Then
			MessageBox.Show("Trigger Set Error")
			ZCL.CloseConvHandle(hTbl)
			ZCL.Close(hCamera)
			hCamera = IntPtr.Zero
			Marshal.FreeCoTaskMem(RGBImage)
			Gra.Dispose()
			Exit Sub

		End If

		Rcv_Thread.Start(Me)

		If Not ZCL.IsoStart(hCamera, 0) Then
			MessageBox.Show("Iso Start Error")
			Thread_End.Set()
			Rcv_Thread.Join()
			ZCL.CloseConvHandle(hTbl)
			ZCL.Close(hCamera)
			hCamera = IntPtr.Zero
			Marshal.FreeCoTaskMem(RGBImage)
			Gra.Dispose()
		End If
	End Sub

	Private Sub Form1_FormClosed(ByVal sender As Object, ByVal e As FormClosedEventArgs) Handles Me.FormClosed
		If Not hCamera.Equals(IntPtr.Zero) Then
			If Not ZCL.IsoStop(hCamera) Then MessageBox.Show("Iso Stop Error")

			Thread_End.Set()
			ZCL.AbortImageReqAll(hCamera)
			Rcv_Thread.Join()

			If Not ZCL.IsoRelease(hCamera) Then MessageBox.Show("Iso Release Error")

			Dim Feature As New ZCL_SETFEATUREVALUE
			Feature.FeatureID = ZCL_FEATUREID.ZCL_TRIGGER
			Feature.ReqID = ZCL_SETREQID.ZCL_FEATURE_OFF
			ZCL.SetFeatureValue(hCamera, Feature)

			If Not ZCL.Close(hCamera) Then MessageBox.Show("Camera Close Error")

			If Not hTbl.Equals(IntPtr.Zero) Then ZCL.CloseConvHandle(hTbl)

			Marshal.FreeCoTaskMem(RGBImage)
			ParamCB.Free()
			Gra.Dispose()
		End If
	End Sub

	Private Sub SetShiftMenuCheck()
		If ShiftID = ZCL_SHIFTID.ZCL_SFT0 Then Bit0.Checked = True Else Bit0.Checked = False
		If ShiftID = ZCL_SHIFTID.ZCL_SFT1 Then Bit1.Checked = True Else Bit1.Checked = False
		If ShiftID = ZCL_SHIFTID.ZCL_SFT2 Then Bit2.Checked = True Else Bit2.Checked = False
		If ShiftID = ZCL_SHIFTID.ZCL_SFT3 Then Bit3.Checked = True Else Bit3.Checked = False
		If ShiftID = ZCL_SHIFTID.ZCL_SFT4 Then Bit4.Checked = True Else Bit4.Checked = False
		If ShiftID = ZCL_SHIFTID.ZCL_SFT5 Then Bit5.Checked = True Else Bit5.Checked = False
		If ShiftID = ZCL_SHIFTID.ZCL_SFT6 Then Bit6.Checked = True Else Bit6.Checked = False
		If ShiftID = ZCL_SHIFTID.ZCL_SFT7 Then Bit7.Checked = True Else Bit7.Checked = False
		If ShiftID = ZCL_SHIFTID.ZCL_SFT8 Then Bit8.Checked = True Else Bit8.Checked = False
	End Sub

	Public Sub SystemCallback(ByVal SystemStatus As STATUS_SYSTEMCODE, ByVal Context As IntPtr)
		Dim param As GCHandle = GCHandle.FromIntPtr(Context)
		Dim FormRef As Form1 = param.Target

		Select Case SystemStatus
			Case STATUS_SYSTEMCODE.STATUSZCL_BUSRESET
				'Processing of bus reset

			Case STATUS_SYSTEMCODE.STATUSZCL_POWERUP
				'Processing of PowerUP

		End Select
	End Sub

	Private Sub OnBit(ByVal sender As Object, ByVal e As EventArgs) _
	Handles Bit0.Click, Bit1.Click, Bit2.Click, Bit3.Click, Bit4.Click, Bit5.Click, Bit6.Click, Bit7.Click, Bit8.Click
		ShiftID = Convert.ToInt32(sender.Name.Substring(3))
		ZCL.IsoStop(hCamera)
		Thread.Sleep(500)
		ZCL.CloseConvHandle(hTbl)
		hTbl = IntPtr.Zero
		Select Case ColorMode.ColorID
			Case ZCL_COLORID.ZCL_RAW16
				ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW16G, ShiftID, IntPtr.Zero)

			Case ZCL_COLORID.ZCL_RGB16, ZCL_COLORID.ZCL_SMONO16, ZCL_COLORID.ZCL_SRGB16, ZCL_COLORID.ZCL_BGR16
				ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_C32bit, ShiftID, IntPtr.Zero)

			Case ZCL_COLORID.ZCL_MONO16
				If Sony_CR Then
					ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW16G, ShiftID, IntPtr.Zero)
				Else
					ZCL.CreateConvHandle(hTbl, ZCL_CONVERTMODE.ZCL_C32bit, ShiftID, IntPtr.Zero)
				End If
		End Select
		ZCL.IsoStart(hCamera, 0)
		SetShiftMenuCheck()
	End Sub

	Public Sub Rcv_ThreadDoWork(ByVal Context As Object)
		Const Max_Buffer As Integer = 4
		Dim FormRef As Form1 = Context
		Dim pBuf(Max_Buffer) As IntPtr
		Dim idx As Integer
		Dim FileColorMode As New ZCL_COLORMODE
        Dim Speed As ZCL_TRANSMITSPEED = ZCL_TRANSMITSPEED.ZCL_S800M
        Dim rtn As Boolean

		FileColorMode.ColorID = FormRef.ColorMode.ColorID
		FileColorMode.CFilter = FormRef.ColorMode.CFilter
		FileColorMode.StoreMode = ZCL_STOREMODE.ZCL_BMPmode
        FileColorMode.EndianMode = FormRef.ColorMode.EndianMode
        FileColorMode.Parallel_Flag = FormRef.ColorMode.Parallel_Flag

		For idx = 0 To Max_Buffer
			pBuf(idx) = Marshal.AllocCoTaskMem(FormRef.GetImage.Buffer)
		Next idx
		For idx = 0 To Max_Buffer
			ZCL.ImageReq(FormRef.hCamera, pBuf(idx), FormRef.GetImage.Buffer)
		Next idx
		idx = 0
		While (True)
            rtn = ZCL.ImageComplete(FormRef.hCamera, pBuf(idx), Speed, IntPtr.Zero, IntPtr.Zero)
			If FormRef.Thread_End.WaitOne(0, False) Then
				Exit While
			End If
			If rtn Then
				ZCL.ColorConvExec(FormRef.hTbl, _
				  FormRef.BmpInfo.biWidth, _
				  FormRef.BmpInfo.biHeight, _
				  FormRef.ColorMode, _
				  pBuf(idx), _
				  FormRef.RGBImage)
				Dim RGB As New Bitmap(FormRef.BmpInfo.biWidth, FormRef.BmpInfo.biHeight, _
				FormRef.BmpInfo.biWidth * 4, PixelFormat.Format32bppRgb, FormRef.RGBImage)
				FormRef.Gra.DrawImage(RGB, 0, FormRef.Menu1.Size.Height + 1)
				RGB.Dispose()
				ZCL.ColorConvExec(FormRef.hTbl, _
				  FormRef.BmpInfo.biWidth, _
				  FormRef.BmpInfo.biHeight, _
				  FileColorMode, _
				  pBuf(idx), _
				  FormRef.RGBImage)
				FormRef.RcvWorker.RunWorkerAsync()
			End If
			ZCL.ImageReq(FormRef.hCamera, pBuf(idx), FormRef.GetImage.Buffer)
			idx += 1
			If idx >= Max_Buffer Then idx = 0
		End While

		ZCL.AbortImageReqAll(FormRef.hCamera)
		For idx = 0 To Max_Buffer
			Marshal.FreeCoTaskMem(pBuf(idx))
		Next idx
	End Sub

	Private Sub RcvWorker_RunWorkerCompleted(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs) Handles RcvWorker.RunWorkerCompleted
		Dim TmpName As String
        Dim buf(BmpInfo.biSizeImage - 1) As Byte
        Dim Info(Marshal.SizeOf(BmpInfo) - 1) As Byte
		Dim gch As GCHandle = GCHandle.Alloc(Info, GCHandleType.Pinned)

		If FileName.Length <> 0 Then
			TmpName = FileName.Insert(Save.FileName.Length - 4, FileIdx.ToString("d8"))
			Dim fs As New FileStream(TmpName, FileMode.Create)
			Dim w As New BinaryWriter(fs)
			Dim Format As New BinaryFormatter
			w.Write(CUShort(19778))
			w.Write(CUInt(14 + Marshal.SizeOf(BmpInfo) + BmpInfo.biSizeImage))
			w.Write(CUShort(0))
			w.Write(CUShort(0))
			w.Write(CUInt(14 + Marshal.SizeOf(BmpInfo)))
			Marshal.StructureToPtr(BmpInfo, gch.AddrOfPinnedObject(), False)
			w.Write(Info)
			Marshal.Copy(RGBImage, buf, 0, BmpInfo.biSizeImage)
			w.Write(buf)
			w.Close()
			fs.Close()

			FileIdx += 1
		End If
		gch.Free()
	End Sub
End Class
