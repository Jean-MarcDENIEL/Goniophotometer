// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "Sample4.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
END_MESSAGE_MAP()



// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS,
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnExec()
{
	Invalidate(FALSE);
}

void CChildView::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	// TODO: Add your message handler code here
	RECT		rect;
	CDC			dcBitmap;
	HBITMAP		hBitmapOld;
	CBitmap		BitmapImage;


#ifdef	FPS_DISP
	TEXTMETRIC	textinfo;
	CString		string;
	string.Format( " Frame Rate %02.3f fps", gotime );
	dc.GetTextMetrics( &textinfo );
#endif
	GetClientRect( &rect );

	BitmapImage.CreateBitmap( m_BitInfo.bmiHeader.biWidth,
						m_BitInfo.bmiHeader.biHeight,
						m_BitInfo.bmiHeader.biPlanes,
						m_BitInfo.bmiHeader.biBitCount,
						m_pImage );

	dcBitmap.CreateCompatibleDC( &dc );
	hBitmapOld = (HBITMAP)dcBitmap.SelectObject( BitmapImage );
#ifdef	FPS_DISP
	dc.BitBlt( rect.left,
				rect.top + textinfo.tmHeight,
				m_BitInfo.bmiHeader.biWidth,
				m_BitInfo.bmiHeader.biHeight,
				&dcBitmap,
				0,
				0,
				SRCCOPY);
#else
	dc.BitBlt( rect.left,
				rect.top,
				m_BitInfo.bmiHeader.biWidth,
				m_BitInfo.bmiHeader.biHeight,
				&dcBitmap,
				0,
				0,
				SRCCOPY);
#endif
	dcBitmap.SelectObject( hBitmapOld );
	BitmapImage.DeleteObject();

#ifdef	FPS_DISP
	dc.TextOut( rect.left, rect.top, string );
#endif

	dcBitmap.DeleteDC();

	// Do not call CWnd::OnPaint() for painting messages
}

