// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Tutorial.h"

#include "MainFrm.h"

#ifdef ZCL_TUTORIAL_BMP
#using <system.drawing.dll>
using namespace System;
using namespace System::Drawing;
using namespace System::Drawing::Imaging;
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#ifdef ZCL_TUTORIAL_VIEW
UINT	RcvThread( LPVOID );
#endif

// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
	ON_COMMAND(ID_FILE_CLOSE, &CMainFrame::OnFileClose)
	ON_WM_CLOSE()
	ON_COMMAND(ID_EDIT_BMPSAVE, &CMainFrame::OnEditBmpsave)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};


// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
#ifdef ZCL_TUTORIAL_VIEW
	hCamera = NULL;
	hTbl = NULL;
#endif
#ifdef ZCL_TUTORIAL_END
	m_EndEvent = NULL;
	m_RcvTermEvent = NULL;
#endif
}

CMainFrame::~CMainFrame()
{
#ifdef ZCL_TUTORIAL_END
	if( m_EndEvent )
	{
		SetEvent( m_EndEvent );
		ZCLAbortImageReqAll( hCamera );
		WaitForSingleObject( m_RcvTermEvent, INFINITE );
		CloseHandle( m_EndEvent );
		CloseHandle( m_RcvTermEvent );
	}

	if( hTbl )
		ZCLCloseConvHandle( hTbl );

	if( hCamera )
		ZCLClose( hCamera );
#endif
}


int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

#ifdef ZCL_TUTORIAL_VIEW
	if( !m_wndView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW,
		CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST, NULL) )
		return -1;
#endif

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}


// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG


// CMainFrame message handlers



BOOL CMainFrame::LoadFrame(UINT nIDResource, DWORD dwDefaultStyle, CWnd* pParentWnd, CCreateContext* pContext) 
{
	// base class does the real work

	if (!CFrameWnd::LoadFrame(nIDResource, dwDefaultStyle, pParentWnd, pContext))
	{
		return FALSE;
	}

	CWinApp* pApp = AfxGetApp();
	if (pApp->m_pMainWnd == NULL)
		pApp->m_pMainWnd = this;

	// replace Exit option on File menu with Close for secondary windows
	if (AfxGetApp()->m_pMainWnd != this)
	{
		CMenu *pMenu = GetMenu();
		ASSERT(pMenu);
		pMenu->ModifyMenu(ID_APP_EXIT, MF_BYCOMMAND | MF_STRING, ID_FILE_CLOSE, _T("&Close"));
#ifdef ZCL_TUTORIAL_END
		m_EndEvent = CreateEvent( NULL, TRUE, FALSE, NULL );
		m_RcvTermEvent = CreateEvent( NULL, TRUE, FALSE, NULL );
#endif

#ifdef ZCL_TUTORIAL_VIEW
		ZCL_GETIMAGEINFO	ImageInfo;

		ZCLSetStructVersion( ZCL_LIBRARY_STRUCT_VERSION ); 
		ZCLOpen( -1, &hCamera );
		ZCLGetImageInfo( hCamera, &ImageInfo );

		RECT		rect;
		ULONG		Width, Height;
		Width = ImageInfo.Image.Width;
		Height = ImageInfo.Image.Height;
		SetWindowPos(
				0,
				0,
				0,
				Width,
				Height,
				SWP_NOMOVE );
		GetClientRect( &rect );
		if( ImageInfo.Image.Width != rect.right + 1 )
			Width += ImageInfo.Image.Width - rect.right - 1;
		if( ImageInfo.Image.Height != rect.bottom + 1 )
			Height += ImageInfo.Image.Height - rect.bottom - 1;
		SetWindowPos(
				0,
				0,
				0,
				Width,
				Height,
				SWP_NOMOVE );

		StartProc();
		AfxBeginThread( RcvThread, this, THREAD_PRIORITY_ABOVE_NORMAL );
#endif
	}

	return TRUE;
}

void CMainFrame::OnFileClose()
{
   DestroyWindow();
}

void CMainFrame::OnClose() 
{
	CTutorialApp *pApp = reinterpret_cast<CTutorialApp*>(AfxGetApp());
	// main window is being closed so cleanup
	if (pApp->m_pMainWnd == this)
	{
		for (int iCntr=0; iCntr < pApp->m_aryFrames.GetSize(); iCntr++)
		{
			HWND hFrame = pApp->m_aryFrames.GetAt(iCntr);
			if (::IsWindow(hFrame))
				::SendMessage(hFrame, WM_CLOSE, 0, 0);
		}
	}
	CFrameWnd::OnClose();
}


#ifdef ZCL_TUTORIAL_VIEW
void CMainFrame::StartProc()
{
	ZCL_GETIMAGEINFO	GetImage;

#ifdef ZCL_TUTORIAL_FEATURE
	ZCL_CHECKFEATURE	Feature;
	ZCL_SETFEATUREVALUE	FeatureValue;

	Feature.Version =
	FeatureValue.Version = ZCLGetLibraryRevision();

	// All parameters set to Auto
	for( int idx = ZCL_BRIGHTNESS; idx < ZCL_OPTICAL_FILTER; idx++ )
	{
		Feature.FeatureID =
		FeatureValue.FeatureID = (ZCL_FEATUREID)idx;
		ZCLCheckFeature( hCamera, &Feature );
		if( Feature.PresenceFlag && Feature.u.Std.Auto_Inq )
		{
			FeatureValue.ReqID = ZCL_AUTO;
			ZCLSetFeatureValue( hCamera, &FeatureValue );
		}
	}

	// Auto Exposure set to median value
	Feature.FeatureID =
	FeatureValue.FeatureID = ZCL_AE;
	ZCLCheckFeature( hCamera, &Feature );
	if( Feature.PresenceFlag )
	{
		FeatureValue.ReqID = ZCL_VALUE;
		FeatureValue.u.Std.Value = Feature.u.Std.Min_Value + ( Feature.u.Std.Max_Value - Feature.u.Std.Min_Value ) / 2;
		ZCLSetFeatureValue( hCamera, &FeatureValue );
	}
#endif
#ifdef ZCL_TUTORIAL_FEATURE
	ZCL_CAMERAMODE		cmode;

 #if 0
	// Standard mode
	cmode.StdMode_Flag = true;
	cmode.u.Std.Mode = ZCL_VGA_MONO;
	cmode.u.Std.FrameRate = ZCL_Fps_15;
	ZCLSetCameraMode( hCamera, &cmode );
 #else
	// Extended mode(Format7)
	cmode.StdMode_Flag = false;
	cmode.u.Ext.Mode = ZCL_Mode_0;
//	cmode.u.Ext.ColorID = ZCL_MONO;
	cmode.u.Ext.ColorID = ZCL_RAW;
	cmode.u.Ext.FilterID = ZCL_FRGGB;
	ZCLSetCameraMode( hCamera, &cmode );

	ZCL_SETIMAGEINFO	SetImage;

	ZCLGetImageInfo( hCamera, &GetImage );

	SetImage.PosX = 0;
	SetImage.PosY = 0;
	SetImage.Width = GetImage.Ext.MaxImageX;
	SetImage.Height = GetImage.Ext.MaxImageY;
	SetImage.MaxSize_Flag = false;
	ZCLSetImageInfo( hCamera, &SetImage );
 #endif
#endif

	ZCLGetImageInfo( hCamera, &GetImage );

	// Set color conversion information
	ZCL_CAMERATYPE		CameraType;
	ZCL_CAMERAINFO		cinfo;

	ZCLCameraBusInfo( hCamera, NULL, &CameraType );
	ZCLCameraInfo( hCamera, &cinfo, 0 );

	ColorMode.ColorID = GetImage.Image.ColorID;
	ColorMode.StoreMode = ZCL_MEMmode;
	ColorMode.EndianMode = (CameraType == ZCL_CAMERA1394) ? ZCL_BIGENDIAN : ZCL_LITTLEENDIAN;
	ColorMode.Parallel_Flag = TRUE;

	if( !cmode.StdMode_Flag &&
		( ColorMode.ColorID == ZCL_RAW
		|| ColorMode.ColorID == ZCL_RAW10
		|| ColorMode.ColorID == ZCL_RAW12
		|| ColorMode.ColorID == ZCL_RAW16 ) )
		ColorMode.CFilter = cmode.u.Ext.FilterID;
	else if( !_stricmp( (char*)cinfo.VendorName, "Sony" )
		&& CameraType == ZCL_CAMERA1394
		&& strstr( (char*)cinfo.ModelName, (char*)"CR" ) )
	{
		ZCL_GETFEATUREVALUE	GetFeature;

		GetFeature.Version = ZCLGetLibraryRevision();

		GetFeature.FeatureID = ZCL_OPTICAL_FILTER;
		ZCLGetFeatureValue( hCamera, &GetFeature );
		switch( GetFeature.u.Std.Value )
		{
		case ZCL_SONYGBRG:
			ColorMode.CFilter = ZCL_FGBRG;
			break;

		case ZCL_SONYBGGR:
			ColorMode.CFilter = ZCL_FBGGR;
			break;

		case ZCL_SONYRGGB:
			ColorMode.CFilter = ZCL_FRGGB;
			break;

		case ZCL_SONYGRBG:
			ColorMode.CFilter = ZCL_FGRBG;
			break;
		}
	}
	else
		ColorMode.CFilter = ZCL_FRGGB;

	// Create a color conversion table
	if( hTbl )
	{
		ZCLCloseConvHandle( hTbl );
		hTbl = NULL;
	}

	if( GetImage.Image.ColorID == ZCL_RAW )
		ZCLCreateConvHandle( &hTbl, ZCL_CFilterRAW8G, ZCL_SFT0, 0 );
	else if( GetImage.Image.ColorID == ZCL_RAW16 )
		ZCLCreateConvHandle( &hTbl, ZCL_CFilterRAW16G, ZCL_SFT0, 0 );
	else
	{
		CClientDC 	dc(this);
		switch ( dc.GetDeviceCaps( BITSPIXEL ) )
		{
		case 32:
			ZCLCreateConvHandle( &hTbl, ZCL_C32bit, ZCL_SFT0, 0 );
			break;

		case 24:
			ZCLCreateConvHandle( &hTbl, ZCL_C24bit, ZCL_SFT0, 0 );
			break;

		case 16:
			ZCLCreateConvHandle( &hTbl, ZCL_C16bit, ZCL_SFT0, 0 );
			break;

		case 15:
			ZCLCreateConvHandle( &hTbl, ZCL_C15bit, ZCL_SFT0, 0 );
			break;
		}
	}

	// Set BITMAPINFO Information
	ZCLColorConvSetBMPINFO( hTbl, GetImage.Image.Width, GetImage.Image.Height, &m_wndView.m_BitInfo );

	// Memory allocation for data after the color conversion
	if( m_wndView.m_pImage )
	{
		delete m_wndView.m_pImage;
		m_wndView.m_pImage = 0;
	}
	m_wndView.m_pImage = new BYTE[ m_wndView.m_BitInfo.bmiHeader.biSizeImage ];

	// Securing of Transmission Resources
	ZCLIsoAlloc( hCamera );
	// Start of Transmission
	ZCLIsoStart( hCamera, 0 );
}
#endif

#ifdef ZCL_TUTORIAL_VIEW
#define Max_Buffer	3
// Data Receives Thread
UINT
RcvThread( LPVOID Countext )
{
	CMainFrame*				pMp = (CMainFrame*)Countext;
	int						idx;
	PUCHAR					pBuf[ Max_Buffer ];
	ZCL_GETIMAGEINFO		ImageInfo;

	// Memory allocation for receive data
	ZCLGetImageInfo( pMp->hCamera, &ImageInfo );

	for( idx = 0; idx < Max_Buffer; idx++ )
		pBuf[ idx ] = new BYTE[ ImageInfo.Image.Buffer ];

	// Request of first image data
	for( idx = 0; idx < Max_Buffer; idx++ )
		ZCLImageReq( pMp->hCamera, pBuf[ idx ], ImageInfo.Image.Buffer );
	idx = 0;
	while( 1 )
	{
		// Completion wait of image data
		ZCLImageCompleteWait( pMp->hCamera, pBuf[ idx ], 0, 0, 0 );
#ifdef ZCL_TUTORIAL_END
		// Start of end process
		if( ::WaitForSingleObject( pMp->m_EndEvent, 0 ) == WAIT_OBJECT_0 )
			break;
#endif
#ifdef ZCL_TUTORIAL_BMP
		pMp->pBuffer = pBuf[ idx ];
#endif
		// Color conversion of receive data
		ZCLColorConvExec( pMp->hTbl,
							pMp->m_wndView.m_BitInfo.bmiHeader.biWidth,
							pMp->m_wndView.m_BitInfo.bmiHeader.biHeight,
							&pMp->ColorMode,
							pBuf[ idx ],
							pMp->m_wndView.m_pImage );
		// Redraw
		pMp->m_wndView.OnExec();
		// Request of next image data
		ZCLImageReq( pMp->hCamera, pBuf[ idx ], ImageInfo.Image.Buffer );
		idx++;
		if( idx >= Max_Buffer )
			idx = 0;
	}
#ifdef ZCL_TUTORIAL_END
	// End process
	ZCLAbortImageReqAll( pMp->hCamera );
	for( idx = 0; idx < Max_Buffer; idx++ )
		delete pBuf[ idx ];
	SetEvent( pMp->m_RcvTermEvent );
#endif
	return 0;
}
#endif

#ifdef ZCL_TUTORIAL_BMP
void CMainFrame::OnEditBmpsave()
{
	VOID *pvBits;
	HDC hDC = ::GetWindowDC( m_hWnd );
	HBITMAP hBitmap = CreateDIBSection(hDC, &m_wndView.m_BitInfo, DIB_RGB_COLORS, &pvBits, NULL, NULL);

	// Set color conversion information
	ZCL_COLORMODE	TempColorMode;
	TempColorMode.ColorID = ColorMode.ColorID;
	TempColorMode.CFilter = ColorMode.CFilter;
	TempColorMode.StoreMode = ZCL_BMPmode;

	// Color conversion of receive data
	ZCLColorConvExec( hTbl,
						m_wndView.m_BitInfo.bmiHeader.biWidth,
						m_wndView.m_BitInfo.bmiHeader.biHeight,
						&TempColorMode,
						pBuffer,
						(BYTE*)pvBits );

	// Save Bitmap
	IntPtr		ptr_hBitmap(hBitmap);
	Bitmap^		SaveBitmap;
	SaveBitmap	= SaveBitmap->FromHbitmap(ptr_hBitmap);
	DeleteObject(hBitmap);

	SaveBitmap->Save("ZCL_Tutorial_C.bmp", ImageFormat::Bmp);
	SaveBitmap->Save("ZCL_Tutorial_C.jpg", ImageFormat::Jpeg);
	SaveBitmap->Save("ZCL_Tutorial_C.tif", ImageFormat::Tiff);
}
#endif
