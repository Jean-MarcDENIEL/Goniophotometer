// CtlWnd.cpp : implementation file
//

#include "stdafx.h"
#include "Sample1.h"
#include "CtlWnd.h"


// CCtlWnd dialog

IMPLEMENT_DYNAMIC(CCtlWnd, CDialog)

CCtlWnd::CCtlWnd(CWnd* pParent /*=NULL*/)
	: CDialog(CCtlWnd::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

CCtlWnd::~CCtlWnd()
{
}

void CCtlWnd::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_StZoom, m_StZoom);
	DDX_Control(pDX, IDC_StWhite, m_StWhite);
	DDX_Control(pDX, IDC_StTilt, m_StTilt);
	DDX_Control(pDX, IDC_StShutter, m_StShutter);
	DDX_Control(pDX, IDC_StSharp, m_StSharp);
	DDX_Control(pDX, IDC_StSaturation, m_StSaturation);
	DDX_Control(pDX, IDC_StPan, m_StPan);
	DDX_Control(pDX, IDC_StOptical, m_StOptical);
	DDX_Control(pDX, IDC_StIris, m_StIris);
	DDX_Control(pDX, IDC_StHue, m_StHue);
	DDX_Control(pDX, IDC_StGamma, m_StGamma);
	DDX_Control(pDX, IDC_StGain, m_StGain);
	DDX_Control(pDX, IDC_StFocus, m_StFocus);
	DDX_Control(pDX, IDC_StBright, m_StBright);
	DDX_Control(pDX, IDC_StAe, m_StAe);
	DDX_Control(pDX, IDC_SlZoom, m_SlZoom);
	DDX_Control(pDX, IDC_SlWhiteV, m_SlWhiteV);
	DDX_Control(pDX, IDC_SlWhiteU, m_SlWhiteU);
	DDX_Control(pDX, IDC_SlTilt, m_SlTilt);
	DDX_Control(pDX, IDC_SlShutter, m_SlShutter);
	DDX_Control(pDX, IDC_SlSharp, m_SlSharp);
	DDX_Control(pDX, IDC_SlSaturation, m_SlSaturation);
	DDX_Control(pDX, IDC_SlPan, m_SlPan);
	DDX_Control(pDX, IDC_SlOptical, m_SlOptical);
	DDX_Control(pDX, IDC_SlIris, m_SlIris);
	DDX_Control(pDX, IDC_SlHue, m_SlHue);
	DDX_Control(pDX, IDC_SlGamma, m_SlGamma);
	DDX_Control(pDX, IDC_SlGain, m_SlGain);
	DDX_Control(pDX, IDC_SlFocus, m_SlFocus);
	DDX_Control(pDX, IDC_SlBright, m_SlBright);
	DDX_Control(pDX, IDC_SlAe, m_SlAe);
	DDX_Control(pDX, IDC_AutoZoom, m_AutoZoom);
	DDX_Control(pDX, IDC_AutoWhite, m_AutoWhite);
	DDX_Control(pDX, IDC_AutoTilt, m_AutoTilt);
	DDX_Control(pDX, IDC_AutoShutter, m_AutoShutter);
	DDX_Control(pDX, IDC_AutoSharp, m_AutoSharp);
	DDX_Control(pDX, IDC_AutoSaturation, m_AutoSaturation);
	DDX_Control(pDX, IDC_AutoPan, m_AutoPan);
	DDX_Control(pDX, IDC_AutoOptical, m_AutoOptical);
	DDX_Control(pDX, IDC_AutoIris, m_AutoIris);
	DDX_Control(pDX, IDC_AutoHue, m_AutoHue);
	DDX_Control(pDX, IDC_AutoGamma, m_AutoGamma);
	DDX_Control(pDX, IDC_AutoGain, m_AutoGain);
	DDX_Control(pDX, IDC_AutoFocus, m_AutoFocus);
	DDX_Control(pDX, IDC_AutoBright, m_AutoBright);
	DDX_Control(pDX, IDC_AutoAe, m_AutoAe);
}


BEGIN_MESSAGE_MAP(CCtlWnd, CDialog)
	ON_WM_HSCROLL()
END_MESSAGE_MAP()


// CCtlWnd message handlers

BOOL CCtlWnd::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here
	SetIcon( m_hIcon, TRUE );
	SetIcon( m_hIcon, FALSE );

	CSample1App	*pApp;
	pApp = (CSample1App*)AfxGetApp();
	m_hCamera = pApp->hCamera;

	RECT					rect, rect1;
	GetDesktopWindow()->GetWindowRect( &rect );
	GetWindowRect( &rect1 );
	MoveWindow(
		rect.right - ( rect1.right - rect1.left ) - 5,
		rect.bottom - ( rect1.bottom - rect1.top ) - 30,
		rect1.right - rect1.left,
		rect1.bottom - rect1.top,
		TRUE );

	// The setting of the slider and the button.


	int		Min, Max;
	int		Value1, Value2;
	ZCL_CHECKFEATURE	Feature;
	ZCL_GETFEATUREVALUE	FeatureValue;

	FeatureValue.Version =
	Feature.Version = ZCLGetLibraryRevision();


	// Stop isochronous transfer.
	// While communicate of Isochronous, Isochronous is given
	// priority to over Asynchronous.
	// Therefore Asynchronous is late.
	ZCLIsoStop( m_hCamera );
	Sleep( 50 );

	//Bright
	Feature.FeatureID =
	FeatureValue.FeatureID = ZCL_BRIGHTNESS;
	ZCLCheckFeature( m_hCamera, &Feature );
	if( Feature.PresenceFlag )
	{
		ZCLGetFeatureValue( m_hCamera, &FeatureValue );
		Value1 = FeatureValue.u.Std.Value;

		m_StBright.EnableWindow( TRUE );

		Min = Feature.u.Std.Min_Value;
		Max = Feature.u.Std.Max_Value;
		m_SlBright.SetRange( Min, Max, TRUE );
		m_SlBright.SetPos( Value1 );

		if( Feature.u.Std.Auto_Inq )
		{
			m_AutoBright.EnableWindow( TRUE );
			if( FeatureValue.u.Std.Auto_M )
				m_AutoBright.SetCheck( BST_CHECKED );
			else
				m_SlBright.EnableWindow( TRUE );
		}
		else
			m_SlBright.EnableWindow( TRUE );
	}

	//Ae
	Feature.FeatureID =
	FeatureValue.FeatureID = ZCL_AE;
	ZCLCheckFeature( m_hCamera, &Feature );
	if( Feature.PresenceFlag )
	{
		ZCLGetFeatureValue( m_hCamera, &FeatureValue );
		Value1 = FeatureValue.u.Std.Value;

		m_StAe.EnableWindow( TRUE );

		Min = Feature.u.Std.Min_Value;
		Max = Feature.u.Std.Max_Value;
		m_SlAe.SetRange( Min, Max, TRUE );
		m_SlAe.SetPos( Value1 );

		if( Feature.u.Std.Auto_Inq )
		{
			m_AutoAe.EnableWindow( TRUE );
			if( FeatureValue.u.Std.Auto_M )
				m_AutoAe.SetCheck( BST_CHECKED );
			else
				m_SlAe.EnableWindow( TRUE );
		}
		else
			m_SlAe.EnableWindow( TRUE );
	}

	//Sharpness
	Feature.FeatureID =
	FeatureValue.FeatureID = ZCL_SHARPNESS;
	ZCLCheckFeature( m_hCamera, &Feature );
	if( Feature.PresenceFlag )
	{
		ZCLGetFeatureValue( m_hCamera, &FeatureValue );
		Value1 = FeatureValue.u.Std.Value;

		m_StSharp.EnableWindow( TRUE );

		Min = Feature.u.Std.Min_Value;
		Max = Feature.u.Std.Max_Value;
		m_SlSharp.SetRange( Min, Max, TRUE );
		m_SlSharp.SetPos( Value1 );

		if( Feature.u.Std.Auto_Inq )
		{
			m_AutoSharp.EnableWindow( TRUE );
			if( FeatureValue.u.Std.Auto_M )
				m_AutoSharp.SetCheck( BST_CHECKED );
			else
				m_SlSharp.EnableWindow( TRUE );
		}
		else
			m_SlSharp.EnableWindow( TRUE );
	}

	//WhiteBalance
	Feature.FeatureID =
	FeatureValue.FeatureID = ZCL_WHITEBALANCE;
	ZCLCheckFeature( m_hCamera, &Feature );
	if( Feature.PresenceFlag )
	{
		ZCLGetFeatureValue( m_hCamera, &FeatureValue );
		Value1 = FeatureValue.u.WhiteBalance.UB_Value;
		Value2 = FeatureValue.u.WhiteBalance.VR_Value;

		m_StWhite.EnableWindow( TRUE );

		Min = Feature.u.Std.Min_Value;
		Max = Feature.u.Std.Max_Value;
		m_SlWhiteU.SetRange( Min, Max, TRUE );
		m_SlWhiteV.SetRange( Min, Max, TRUE );
		m_SlWhiteU.SetPos( Value1 );
		m_SlWhiteV.SetPos( Value2 );

		if( Feature.u.Std.Auto_Inq )
		{
			m_AutoWhite.EnableWindow( TRUE );
			if( FeatureValue.u.WhiteBalance.Auto_M )
				m_AutoWhite.SetCheck( BST_CHECKED );
			else
			{
				m_SlWhiteU.EnableWindow( TRUE );
				m_SlWhiteV.EnableWindow( TRUE );
			}
		}
		else
		{
			m_SlWhiteU.EnableWindow( TRUE );
			m_SlWhiteV.EnableWindow( TRUE );
		}
	}

	//Hue
	Feature.FeatureID =
	FeatureValue.FeatureID = ZCL_HUE;
	ZCLCheckFeature( m_hCamera, &Feature );
	if( Feature.PresenceFlag )
	{
		ZCLGetFeatureValue( m_hCamera, &FeatureValue );
		Value1 = FeatureValue.u.Std.Value;

		m_StHue.EnableWindow( TRUE );

		Min = Feature.u.Std.Min_Value;
		Max = Feature.u.Std.Max_Value;
		m_SlHue.SetRange( Min, Max, TRUE );
		m_SlHue.SetPos( Value1 );

		if( Feature.u.Std.Auto_Inq )
		{
			m_AutoHue.EnableWindow( TRUE );
			if( FeatureValue.u.Std.Auto_M )
				m_AutoHue.SetCheck( BST_CHECKED );
			else
				m_SlHue.EnableWindow( TRUE );
		}
		else
			m_SlHue.EnableWindow( TRUE );
	}

	//Saturation
	Feature.FeatureID =
	FeatureValue.FeatureID = ZCL_SATURATION;
	ZCLCheckFeature( m_hCamera, &Feature );
	if( Feature.PresenceFlag )
	{
		ZCLGetFeatureValue( m_hCamera, &FeatureValue );
		Value1 = FeatureValue.u.Std.Value;

		m_StSaturation.EnableWindow( TRUE );

		Min = Feature.u.Std.Min_Value;
		Max = Feature.u.Std.Max_Value;
		m_SlSaturation.SetRange( Min, Max, TRUE );
		m_SlSaturation.SetPos( Value1 );

		if( Feature.u.Std.Auto_Inq )
		{
			m_AutoSaturation.EnableWindow( TRUE );
			if( FeatureValue.u.Std.Auto_M )
				m_AutoSaturation.SetCheck( BST_CHECKED );
			else
				m_SlSaturation.EnableWindow( TRUE );
		}
		else
			m_SlSaturation.EnableWindow( TRUE );
	}

	//Gamma
	Feature.FeatureID =
	FeatureValue.FeatureID = ZCL_GAMMA;
	ZCLCheckFeature( m_hCamera, &Feature );
	if( Feature.PresenceFlag )
	{
		ZCLGetFeatureValue( m_hCamera, &FeatureValue );
		Value1 = FeatureValue.u.Std.Value;

		m_StGamma.EnableWindow( TRUE );

		Min = Feature.u.Std.Min_Value;
		Max = Feature.u.Std.Max_Value;
		m_SlGamma.SetRange( Min, Max, TRUE );
		m_SlGamma.SetPos( Value1 );

		if( Feature.u.Std.Auto_Inq )
		{
			m_AutoGamma.EnableWindow( TRUE );
			if( FeatureValue.u.Std.Auto_M )
				m_AutoGamma.SetCheck( BST_CHECKED );
			else
				m_SlGamma.EnableWindow( TRUE );
		}
		else
			m_SlGamma.EnableWindow( TRUE );
	}

	//Shutter
	Feature.FeatureID =
	FeatureValue.FeatureID = ZCL_SHUTTER;
	ZCLCheckFeature( m_hCamera, &Feature );
	if( Feature.PresenceFlag )
	{
		ZCLGetFeatureValue( m_hCamera, &FeatureValue );
		Value1 = FeatureValue.u.Std.Value;

		m_StShutter.EnableWindow( TRUE );

		Min = Feature.u.Std.Min_Value;
		Max = Feature.u.Std.Max_Value;
		m_SlShutter.SetRange( Min, Max, TRUE );
		m_SlShutter.SetPos( Value1 );

		if( Feature.u.Std.Auto_Inq )
		{
			m_AutoShutter.EnableWindow( TRUE );
			if( FeatureValue.u.Std.Auto_M )
				m_AutoShutter.SetCheck( BST_CHECKED );
			else
				m_SlShutter.EnableWindow( TRUE );
		}
		else
			m_SlShutter.EnableWindow( TRUE );
	}

	//Gain
	Feature.FeatureID =
	FeatureValue.FeatureID = ZCL_GAIN;
	ZCLCheckFeature( m_hCamera, &Feature );
	if( Feature.PresenceFlag )
	{
		ZCLGetFeatureValue( m_hCamera, &FeatureValue );
		Value1 = FeatureValue.u.Std.Value;

		m_StGain.EnableWindow( TRUE );

		Min = Feature.u.Std.Min_Value;
		Max = Feature.u.Std.Max_Value;
		m_SlGain.SetRange( Min, Max, TRUE );
		m_SlGain.SetPos( Value1 );

		if( Feature.u.Std.Auto_Inq )
		{
			m_AutoGain.EnableWindow( TRUE );
			if( FeatureValue.u.Std.Auto_M )
				m_AutoGain.SetCheck( BST_CHECKED );
			else
				m_SlGain.EnableWindow( TRUE );
		}
		else
			m_SlGain.EnableWindow( TRUE );
	}

	//Iris
	Feature.FeatureID =
	FeatureValue.FeatureID = ZCL_IRIS;
	ZCLCheckFeature( m_hCamera, &Feature );
	if( Feature.PresenceFlag )
	{
		ZCLGetFeatureValue( m_hCamera, &FeatureValue );
		Value1 = FeatureValue.u.Std.Value;

		m_StIris.EnableWindow( TRUE );

		Min = Feature.u.Std.Min_Value;
		Max = Feature.u.Std.Max_Value;
		m_SlIris.SetRange( Min, Max, TRUE );
		m_SlIris.SetPos( Value1 );

		if( Feature.u.Std.Auto_Inq )
		{
			m_AutoIris.EnableWindow( TRUE );
			if( FeatureValue.u.Std.Auto_M )
				m_AutoIris.SetCheck( BST_CHECKED );
			else
				m_SlIris.EnableWindow( TRUE );
		}
		else
			m_SlIris.EnableWindow( TRUE );
	}

	//Focus
	Feature.FeatureID =
	FeatureValue.FeatureID = ZCL_FOCUS;
	ZCLCheckFeature( m_hCamera, &Feature );
	if( Feature.PresenceFlag )
	{
		ZCLGetFeatureValue( m_hCamera, &FeatureValue );
		Value1 = FeatureValue.u.Std.Value;

		m_StFocus.EnableWindow( TRUE );

		Min = Feature.u.Std.Min_Value;
		Max = Feature.u.Std.Max_Value;
		m_SlFocus.SetRange( Min, Max, TRUE );
		m_SlFocus.SetPos( Value1 );

		if( Feature.u.Std.Auto_Inq )
		{
			m_AutoFocus.EnableWindow( TRUE );
			if( FeatureValue.u.Std.Auto_M )
				m_AutoFocus.SetCheck( BST_CHECKED );
			else
				m_SlFocus.EnableWindow( TRUE );
		}
		else
			m_SlFocus.EnableWindow( TRUE );
	}

	//Zoom
	Feature.FeatureID =
	FeatureValue.FeatureID = ZCL_ZOOM;
	ZCLCheckFeature( m_hCamera, &Feature );
	if( Feature.PresenceFlag )
	{
		ZCLGetFeatureValue( m_hCamera, &FeatureValue );
		Value1 = FeatureValue.u.Std.Value;

		m_StZoom.EnableWindow( TRUE );

		Min = Feature.u.Std.Min_Value;
		Max = Feature.u.Std.Max_Value;
		m_SlZoom.SetRange( Min, Max, TRUE );
		m_SlZoom.SetPos( Value1 );

		if( Feature.u.Std.Auto_Inq )
		{
			m_AutoZoom.EnableWindow( TRUE );
			if( FeatureValue.u.Std.Auto_M )
				m_AutoZoom.SetCheck( BST_CHECKED );
			else
				m_SlZoom.EnableWindow( TRUE );
		}
		else
			m_SlZoom.EnableWindow( TRUE );
	}

	//Optical Filter
	Feature.FeatureID =
	FeatureValue.FeatureID = ZCL_OPTICAL_FILTER;
	ZCLCheckFeature( m_hCamera, &Feature );
	if( Feature.PresenceFlag )
	{
		ZCLGetFeatureValue( m_hCamera, &FeatureValue );
		Value1 = FeatureValue.u.Std.Value;

		m_StOptical.EnableWindow( TRUE );

		Min = Feature.u.Std.Min_Value;
		Max = Feature.u.Std.Max_Value;
		m_SlOptical.SetRange( Min, Max, TRUE );
		m_SlOptical.SetPos( Value1 );

		if( Feature.u.Std.Auto_Inq )
		{
			m_AutoOptical.EnableWindow( TRUE );
			if( FeatureValue.u.Std.Auto_M )
				m_AutoOptical.SetCheck( BST_CHECKED );
			else
				m_SlOptical.EnableWindow( TRUE );
		}
		else
			m_SlOptical.EnableWindow( TRUE );
	}

	//Pan
	Feature.FeatureID =
	FeatureValue.FeatureID = ZCL_PAN;
	ZCLCheckFeature( m_hCamera, &Feature );
	if( Feature.PresenceFlag )
	{
		ZCLGetFeatureValue( m_hCamera, &FeatureValue );
		Value1 = FeatureValue.u.Std.Value;

		m_StPan.EnableWindow( TRUE );

		Min = Feature.u.Std.Min_Value;
		Max = Feature.u.Std.Max_Value;
		m_SlPan.SetRange( Min, Max, TRUE );
		m_SlPan.SetPos( Value1 );

		if( Feature.u.Std.Auto_Inq )
		{
			m_AutoPan.EnableWindow( TRUE );
			if( FeatureValue.u.Std.Auto_M )
				m_AutoPan.SetCheck( BST_CHECKED );
			else
				m_SlPan.EnableWindow( TRUE );
		}
		else
			m_SlPan.EnableWindow( TRUE );
	}

	//Tilt
	Feature.FeatureID =
	FeatureValue.FeatureID = ZCL_TILT;
	ZCLCheckFeature( m_hCamera, &Feature );
	if( Feature.PresenceFlag )
	{
		ZCLGetFeatureValue( m_hCamera, &FeatureValue );
		Value1 = FeatureValue.u.Std.Value;

		m_StTilt.EnableWindow( TRUE );

		Min = Feature.u.Std.Min_Value;
		Max = Feature.u.Std.Max_Value;
		m_SlTilt.SetRange( Min, Max, TRUE );
		m_SlTilt.SetPos( Value1 );

		if( Feature.u.Std.Auto_Inq )
		{
			m_AutoTilt.EnableWindow( TRUE );
			if( FeatureValue.u.Std.Auto_M )
				m_AutoTilt.SetCheck( BST_CHECKED );
			else
				m_SlTilt.EnableWindow( TRUE );
		}
		else
			m_SlTilt.EnableWindow( TRUE );
	}

	UpdateWindow();

	// Start isochronous transfer again
	ZCLIsoStart( m_hCamera, 0 );

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CCtlWnd::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: Add your message handler code here and/or call default

	// Processing when each slider was moved

	ZCL_SETFEATUREVALUE		Feature;

	Feature.Version = ZCLGetLibraryRevision();

	if( (CSliderCtrl *)pScrollBar == &m_SlBright )	//Brightness
	{
		Feature.u.Std.Value = m_SlBright.GetPos();
		Feature.FeatureID = ZCL_BRIGHTNESS;
	}
	if( (CSliderCtrl *)pScrollBar == &m_SlAe )		//Ae
	{
		Feature.u.Std.Value = m_SlAe.GetPos();
		Feature.FeatureID = ZCL_AE;
	}
	if( (CSliderCtrl *)pScrollBar == &m_SlSharp )	//Sharpness
	{
		Feature.u.Std.Value = m_SlSharp.GetPos();
		Feature.FeatureID = ZCL_SHARPNESS;
	}
	if( (CSliderCtrl *)pScrollBar == &m_SlWhiteU  || (CSliderCtrl *)pScrollBar == &m_SlWhiteV )	//WhiteBalance
	{
		Feature.u.WhiteBalance.UB_Value = m_SlWhiteU.GetPos();
		Feature.u.WhiteBalance.VR_Value = m_SlWhiteV.GetPos();

		Feature.FeatureID = ZCL_WHITEBALANCE;
	}
	if( (CSliderCtrl *)pScrollBar == &m_SlHue )		//Hue
	{
		Feature.u.Std.Value = m_SlHue.GetPos();
		Feature.FeatureID = ZCL_HUE;
	}
	if( (CSliderCtrl *)pScrollBar == &m_SlSaturation )	//Saturation
	{
		Feature.u.Std.Value = m_SlSaturation.GetPos();
		Feature.FeatureID = ZCL_SATURATION;
	}
	if( (CSliderCtrl *)pScrollBar == &m_SlGamma )	//Gamma
	{
		Feature.u.Std.Value = m_SlGamma.GetPos();
		Feature.FeatureID = ZCL_GAMMA;
	}
	if( (CSliderCtrl *)pScrollBar == &m_SlShutter )	//Shutter
	{
		Feature.u.Std.Value = m_SlShutter.GetPos();
		Feature.FeatureID = ZCL_SHUTTER;
	}
	if( (CSliderCtrl *)pScrollBar == &m_SlGain )	//Gain
	{
		Feature.u.Std.Value = m_SlGain.GetPos();
		Feature.FeatureID = ZCL_GAIN;
	}
	if( (CSliderCtrl *)pScrollBar == &m_SlIris )	//Iris
	{
		Feature.u.Std.Value = m_SlIris.GetPos();
		Feature.FeatureID = ZCL_IRIS;
	}
	if( (CSliderCtrl *)pScrollBar == &m_SlFocus )	//Focus
	{
		Feature.u.Std.Value = m_SlFocus.GetPos();
		Feature.FeatureID = ZCL_FOCUS;
	}
	if( (CSliderCtrl *)pScrollBar == &m_SlZoom )	//Zoom
	{
		Feature.u.Std.Value = m_SlZoom.GetPos();
		Feature.FeatureID = ZCL_ZOOM;
	}
	if( (CSliderCtrl *)pScrollBar == &m_SlOptical )	//OpticalFilter
	{
		Feature.u.Std.Value = m_SlOptical.GetPos();
		Feature.FeatureID = ZCL_OPTICAL_FILTER;
	}
	if( (CSliderCtrl *)pScrollBar == &m_SlPan )		//Pan
	{
		Feature.u.Std.Value = m_SlPan.GetPos();
		Feature.FeatureID = ZCL_PAN;
	}
	if( (CSliderCtrl *)pScrollBar == &m_SlTilt )	//Tilt
	{
		Feature.u.Std.Value = m_SlTilt.GetPos();
		Feature.FeatureID = ZCL_TILT;
	}

	Feature.ReqID = ZCL_VALUE;
	ZCLSetFeatureValue( m_hCamera, &Feature );		// Set the parameter to the camera

	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

BOOL CCtlWnd::OnCommand(WPARAM wParam, LPARAM lParam)
{
	// TODO: Add your specialized code here and/or call the base class

	// Processing when check box was clicked

	ZCL_SETFEATUREVALUE		Feature;
	ZCL_GETFEATUREVALUE		GetFeature;

	Feature.Version =
	GetFeature.Version = ZCLGetLibraryRevision();

	switch( wParam )
	{
	case	IDC_AutoBright:							//Auto Brightness
		Feature.FeatureID = ZCL_BRIGHTNESS;
		GetFeature.FeatureID = ZCL_BRIGHTNESS;
		if( !m_AutoBright.GetCheck() )
		{
			ZCLGetFeatureValue( m_hCamera, &GetFeature );
			m_SlBright.SetPos( GetFeature.u.Std.Value );
			m_SlBright.EnableWindow( TRUE );
			Feature.ReqID = ZCL_VALUE;
			Feature.u.Std.Value = m_SlBright.GetPos();
		}
		else
		{
			m_SlBright.EnableWindow( FALSE );
			Feature.ReqID = ZCL_AUTO;
		}
		break;
	case	IDC_AutoAe:								//Auto Ae
		Feature.FeatureID = ZCL_AE;
		GetFeature.FeatureID = ZCL_AE;
		if( !m_AutoAe.GetCheck() )
		{
			ZCLGetFeatureValue( m_hCamera, &GetFeature );
			m_SlAe.SetPos( GetFeature.u.Std.Value );
			m_SlAe.EnableWindow( TRUE );
			Feature.ReqID = ZCL_VALUE;
			Feature.u.Std.Value = m_SlAe.GetPos();
		}
		else
		{
			m_SlAe.EnableWindow( FALSE );
			Feature.ReqID = ZCL_AUTO;
		}
		break;
	case	IDC_AutoSharp:							//Auto Sharpness
		Feature.FeatureID = ZCL_SHARPNESS;
		GetFeature.FeatureID = ZCL_SHARPNESS;
		if( !m_AutoSharp.GetCheck() )
		{
			ZCLGetFeatureValue( m_hCamera, &GetFeature );
			m_SlSharp.SetPos( GetFeature.u.Std.Value );
			m_SlSharp.EnableWindow( TRUE );
			Feature.ReqID = ZCL_VALUE;
			Feature.u.Std.Value = m_SlSharp.GetPos();
		}
		else
		{
			m_SlSharp.EnableWindow( FALSE );
			Feature.ReqID = ZCL_AUTO;
		}
		break;
	case	IDC_AutoWhite:							//Auto WhiteBalance
		Feature.FeatureID = ZCL_WHITEBALANCE;
		GetFeature.FeatureID = ZCL_WHITEBALANCE;
		if( !m_AutoWhite.GetCheck() )
		{
			ZCLGetFeatureValue( m_hCamera, &GetFeature );
			m_SlWhiteU.SetPos( GetFeature.u.WhiteBalance.UB_Value );
			m_SlWhiteV.SetPos( GetFeature.u.WhiteBalance.VR_Value );
			m_SlWhiteU.EnableWindow( TRUE );
			m_SlWhiteV.EnableWindow( TRUE );
			Feature.ReqID = ZCL_VALUE;
			Feature.u.WhiteBalance.UB_Value = m_SlWhiteU.GetPos();
			Feature.u.WhiteBalance.VR_Value = m_SlWhiteV.GetPos();
		}
		else
		{
			m_SlWhiteU.EnableWindow( FALSE );
			m_SlWhiteV.EnableWindow( FALSE );
			Feature.ReqID = ZCL_AUTO;
		}
		break;
	case	IDC_AutoHue:							//Auto Hue
		Feature.FeatureID = ZCL_HUE;
		GetFeature.FeatureID = ZCL_HUE;
		if( !m_AutoHue.GetCheck() )
		{
			ZCLGetFeatureValue( m_hCamera, &GetFeature );
			m_SlHue.SetPos( GetFeature.u.Std.Value );
			m_SlHue.EnableWindow( TRUE );
			Feature.ReqID = ZCL_VALUE;
			Feature.u.Std.Value = m_SlHue.GetPos();
		}
		else
		{
			m_SlHue.EnableWindow( FALSE );
			Feature.ReqID = ZCL_AUTO;
		}
		break;
	case	IDC_AutoSaturation:						//Auto Saturation
		Feature.FeatureID = ZCL_SATURATION;
		GetFeature.FeatureID = ZCL_SATURATION;
		if( !m_AutoSaturation.GetCheck() )
		{
			ZCLGetFeatureValue( m_hCamera, &GetFeature );
			m_SlSaturation.SetPos( GetFeature.u.Std.Value );
			m_SlSaturation.EnableWindow( TRUE );
			Feature.ReqID = ZCL_VALUE;
			Feature.u.Std.Value = m_SlSaturation.GetPos();
		}
		else
		{
			m_SlSaturation.EnableWindow( FALSE );
			Feature.ReqID = ZCL_AUTO;
		}
		break;
	case	IDC_AutoGamma:							//Auto Gamma
		Feature.FeatureID = ZCL_GAMMA;
		GetFeature.FeatureID = ZCL_GAMMA;
		if( !m_AutoGamma.GetCheck() )
		{
			ZCLGetFeatureValue( m_hCamera, &GetFeature );
			m_SlGamma.SetPos( GetFeature.u.Std.Value );
			m_SlGamma.EnableWindow( TRUE );
			Feature.ReqID = ZCL_VALUE;
			Feature.u.Std.Value = m_SlGamma.GetPos();
		}
		else
		{
			m_SlGamma.EnableWindow( FALSE );
			Feature.ReqID = ZCL_AUTO;
		}
		break;
	case	IDC_AutoShutter:						//Auto Shutter
		Feature.FeatureID = ZCL_SHUTTER;
		GetFeature.FeatureID = ZCL_SHUTTER;
		if( !m_AutoShutter.GetCheck() )
		{
			ZCLGetFeatureValue( m_hCamera, &GetFeature );
			m_SlShutter.SetPos( GetFeature.u.Std.Value );
			m_SlShutter.EnableWindow( TRUE );
			Feature.ReqID = ZCL_VALUE;
			Feature.u.Std.Value = m_SlShutter.GetPos();
		}
		else
		{
			m_SlShutter.EnableWindow( FALSE );
			Feature.ReqID = ZCL_AUTO;
		}
		break;
	case	IDC_AutoGain:							//Auto Gain
		Feature.FeatureID = ZCL_GAIN;
		GetFeature.FeatureID = ZCL_GAIN;
		if( !m_AutoGain.GetCheck() )
		{
			ZCLGetFeatureValue( m_hCamera, &GetFeature );
			m_SlGain.SetPos( GetFeature.u.Std.Value );
			m_SlGain.EnableWindow( TRUE );
			Feature.ReqID = ZCL_VALUE;
			Feature.u.Std.Value = m_SlGain.GetPos();
		}
		else
		{
			m_SlGain.EnableWindow( FALSE );
			Feature.ReqID = ZCL_AUTO;
		}
		break;
	case	IDC_AutoIris:							//Auto Iris
		Feature.FeatureID = ZCL_IRIS;
		GetFeature.FeatureID = ZCL_IRIS;
		if( !m_AutoIris.GetCheck() )
		{
			ZCLGetFeatureValue( m_hCamera, &GetFeature );
			m_SlIris.SetPos( GetFeature.u.Std.Value );
			m_SlIris.EnableWindow( TRUE );
			Feature.ReqID = ZCL_VALUE;
			Feature.u.Std.Value = m_SlIris.GetPos();
		}
		else
		{
			m_SlIris.EnableWindow( FALSE );
			Feature.ReqID = ZCL_AUTO;
		}
		break;
	case	IDC_AutoFocus:							//Auto Focus
		Feature.FeatureID = ZCL_FOCUS;
		GetFeature.FeatureID = ZCL_FOCUS;
		if( !m_AutoFocus.GetCheck() )
		{
			ZCLGetFeatureValue( m_hCamera, &GetFeature );
			m_SlFocus.SetPos( GetFeature.u.Std.Value );
			m_SlFocus.EnableWindow( TRUE );
			Feature.ReqID = ZCL_VALUE;
			Feature.u.Std.Value = m_SlFocus.GetPos();
		}
		else
		{
			m_SlFocus.EnableWindow( FALSE );
			Feature.ReqID = ZCL_AUTO;
		}
		break;
	case	IDC_AutoZoom:							//Auto Zoom
		Feature.FeatureID = ZCL_ZOOM;
		GetFeature.FeatureID = ZCL_ZOOM;
		if( !m_AutoZoom.GetCheck() )
		{
			ZCLGetFeatureValue( m_hCamera, &GetFeature );
			m_SlZoom.SetPos( GetFeature.u.Std.Value );
			m_SlZoom.EnableWindow( TRUE );
			Feature.ReqID = ZCL_VALUE;
			Feature.u.Std.Value = m_SlZoom.GetPos();
		}
		else
		{
			m_SlZoom.EnableWindow( FALSE );
			Feature.ReqID = ZCL_AUTO;
		}
		break;
	case	IDC_AutoOptical:						//Auto OpticalFilter
		Feature.FeatureID = ZCL_OPTICAL_FILTER;
		GetFeature.FeatureID = ZCL_OPTICAL_FILTER;
		if( !m_AutoOptical.GetCheck() )
		{
			ZCLGetFeatureValue( m_hCamera, &GetFeature );
			m_SlOptical.SetPos( GetFeature.u.Std.Value );
			m_SlOptical.EnableWindow( TRUE );
			Feature.ReqID = ZCL_VALUE;
			Feature.u.Std.Value = m_SlOptical.GetPos();
		}
		else
		{
			m_SlOptical.EnableWindow( FALSE );
			Feature.ReqID = ZCL_AUTO;
		}
		break;
	case	IDC_AutoPan:							//Auto Pan
		Feature.FeatureID = ZCL_PAN;
		GetFeature.FeatureID = ZCL_PAN;
		if( !m_AutoPan.GetCheck() )
		{
			ZCLGetFeatureValue( m_hCamera, &GetFeature );
			m_SlPan.SetPos( GetFeature.u.Std.Value );
			m_SlPan.EnableWindow( TRUE );
			Feature.ReqID = ZCL_VALUE;
			Feature.u.Std.Value = m_SlPan.GetPos();
		}
		else
		{
			m_SlPan.EnableWindow( FALSE );
			Feature.ReqID = ZCL_AUTO;
		}
		break;
	case	IDC_AutoTilt:							//Auto Tilt
		Feature.FeatureID = ZCL_TILT;
		GetFeature.FeatureID = ZCL_TILT;
		if( !m_AutoTilt.GetCheck() )
		{
			ZCLGetFeatureValue( m_hCamera, &GetFeature );
			m_SlTilt.SetPos( GetFeature.u.Std.Value );
			m_SlTilt.EnableWindow( TRUE );
			Feature.ReqID = ZCL_VALUE;
			Feature.u.Std.Value = m_SlTilt.GetPos();
		}
		else
		{
			m_SlTilt.EnableWindow( FALSE );
			Feature.ReqID = ZCL_AUTO;
		}
		break;
	default:
		return CDialog::OnCommand(wParam, lParam);
	}
	ZCLSetFeatureValue( m_hCamera, &Feature );		// Set Auto Mode of an appointed function

	return CDialog::OnCommand(wParam, lParam);
}
