using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;


namespace Sample8
{
	public partial class Form1 : Form
	{
		private IntPtr hCamera;
		private GCHandle ParamCB;
		private ZCL.SystemFunc SystemCB = new ZCL.SystemFunc(SystemCallback);
		private ZCL_COLORMODE ColorMode = new ZCL_COLORMODE();
		private IntPtr hTbl;
		private IntPtr RGBImage;
		private ZCL.ImageFunc ImageCB = new ZCL.ImageFunc(ImageCallback);
		private ZCL_SHIFTID ShiftID;
		private Boolean Sony_CR = false;
		private Graphics Gra;

		public Form1()
		{
			ZCL_CAMERAINFO CameraInfo = new ZCL_CAMERAINFO();
			ZCL_CAMERATYPE CameraType;
			ZCL_GETIMAGEINFO GetImage = new ZCL_GETIMAGEINFO();
			IntPtr CameraMode;
			ZCL_CAMERAMODEEXT CameraExtMode = new ZCL_CAMERAMODEEXT();
			UInt32 Data;
			ZCL_BITMAPINFO BmpInfo = new ZCL_BITMAPINFO();

			InitializeComponent();

			ZCL.SetStructVersion(ZCL.ZCL_LIBRARY_STRUCT_VERSION);

			ParamCB = GCHandle.Alloc(this);
			ZCL.SetCallBack(GCHandle.ToIntPtr(ParamCB), SystemCB);

			if (!ZCL.Open(ulong.MaxValue, out hCamera))
			{
				MessageBox.Show("Camera Not found");
				return;
			}

			if (!ZCL.CameraInfo(hCamera, CameraInfo, IntPtr.Zero))
			{
				MessageBox.Show("Get Camera Info Error");
				ZCL.Close(hCamera);
				hCamera = IntPtr.Zero;
				return;
			}

			this.Text = String.Concat("Free Run Sample   Model=", CameraInfo.VendorName, " ", CameraInfo.ModelName);

			if (!ZCL.CameraBusInfo(hCamera, IntPtr.Zero, out CameraType))
			{
				MessageBox.Show("Get Camera Bus Info Error");
				ZCL.Close(hCamera);
				hCamera = IntPtr.Zero;
				return;
			}

			if (CameraInfo.VendorName.Equals("Sony", StringComparison.OrdinalIgnoreCase)
				&& CameraType == ZCL_CAMERATYPE.ZCL_CAMERA1394
				&& CameraInfo.ModelName.Contains("CR"))
				Sony_CR = true;

#if (false)
			// When change Camera Mode

#if (true)
            // Standard mode
			ZCL_CAMERAMODESTD CameraStdMode = new ZCL_CAMERAMODESTD();

			CameraStdMode.StdMode_Flag = true;
			CameraStdMode.StdMode = ZCL_STDMODE.ZCL_VGA_MONO;
			CameraStdMode.FrameRate = ZCL_FPS.ZCL_Fps_30;
			if (!ZCL.SetCameraMode(hCamera, CameraStdMode))
			{
				MessageBox.Show("Camera Mode Set Error");
				ZCL.Close(hCamera);
				hCamera = IntPtr.Zero;
				return;
			}
#else
			// Extended mode

			CameraExtMode.StdMode_Flag = false;
			CameraExtMode.ExtMode = ZCL_EXTMODE.ZCL_Mode_0;
			CameraExtMode.ColorID = ZCL_COLORID.ZCL_MONO;
			if (!ZCL.SetCameraMode(hCamera, CameraExtMode))
			{
				MessageBox.Show("Camera Mode Set Error");
				ZCL.Close(hCamera);
				hCamera = IntPtr.Zero;
				return;
			}

			ZCL_SETIMAGEINFO SetImage = new ZCL_SETIMAGEINFO();

			ZCL.GetImageInfo(hCamera, GetImage);

			SetImage.PosX = 0;
			SetImage.PosY = 0;
			SetImage.Width = GetImage.Width;
			SetImage.Height = GetImage.Height;
			SetImage.MaxSize_Flag = true;
			if (!ZCL.SetImageInfo(hCamera, SetImage))
			{
				MessageBox.Show("Camera ImageSize Set Error");
				ZCL.Close(hCamera);
				hCamera = IntPtr.Zero;
				return;
			}
#endif
#endif

			CameraMode = Marshal.AllocCoTaskMem(Marshal.SizeOf(CameraExtMode));
			if (!ZCL.NowCameraMode(hCamera, CameraMode))
			{
				MessageBox.Show("Camera Mode Get Error");
				ZCL.Close(hCamera);
				hCamera = IntPtr.Zero;
				Marshal.FreeCoTaskMem(CameraMode);
				return;
			}
			Marshal.PtrToStructure(CameraMode, CameraExtMode);
			Marshal.FreeCoTaskMem(CameraMode);

			if (!ZCL.GetImageInfo(hCamera, GetImage))
			{
				MessageBox.Show("Camera ImageSize Get Error");
				ZCL.Close(hCamera);
				hCamera = IntPtr.Zero;
				return;
			}

			ColorMode.ColorID = GetImage.ColorID;
			if (!CameraExtMode.StdMode_Flag &&
				( GetImage.ColorID == ZCL_COLORID.ZCL_RAW
				|| GetImage.ColorID == ZCL_COLORID.ZCL_RAW10
				|| GetImage.ColorID == ZCL_COLORID.ZCL_RAW12
				|| GetImage.ColorID == ZCL_COLORID.ZCL_RAW16))
				ColorMode.CFilter = CameraExtMode.FilterID;
			else if (Sony_CR)
			{
				ZCL_GETFEATUREVALUE GetFeature = new ZCL_GETFEATUREVALUE();

				GetFeature.FeatureID = ZCL_FEATUREID.ZCL_OPTICAL_FILTER;
				ZCL.GetFeatureValue(hCamera, GetFeature);
				switch ((ZCL_CFILTERMODE_SONY)GetFeature.Value)
				{
					case ZCL_CFILTERMODE_SONY.ZCL_SONYGBRG:
						ColorMode.CFilter = ZCL_CFILTERMODE.ZCL_FGBRG;
						break;

					case ZCL_CFILTERMODE_SONY.ZCL_SONYBGGR:
						ColorMode.CFilter = ZCL_CFILTERMODE.ZCL_FBGGR;
						break;

					case ZCL_CFILTERMODE_SONY.ZCL_SONYRGGB:
						ColorMode.CFilter = ZCL_CFILTERMODE.ZCL_FRGGB;
						break;

					case ZCL_CFILTERMODE_SONY.ZCL_SONYGRBG:
						ColorMode.CFilter = ZCL_CFILTERMODE.ZCL_FGRBG;
						break;
				}
			}
			else
				ColorMode.CFilter = ZCL_CFILTERMODE.ZCL_FRGGB;

			ColorMode.StoreMode = ZCL_STOREMODE.ZCL_MEMmode;
			ColorMode.EndianMode = CameraType == ZCL_CAMERATYPE.ZCL_CAMERA1394 ? ZCL_ENDIAN.ZCL_BIGENDIAN : ZCL_ENDIAN.ZCL_LITTLEENDIAN;
            ColorMode.Parallel_Flag = true;

			ShiftMenu.Enabled = false;
			ShiftID = ZCL_SHIFTID.ZCL_SFT0;
			switch (ColorMode.ColorID)
			{
				case ZCL_COLORID.ZCL_RAW:
					ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW8G, ShiftID, IntPtr.Zero);
					break;

				case ZCL_COLORID.ZCL_RAW10:
					ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW10G, ShiftID, IntPtr.Zero);
					break;

				case ZCL_COLORID.ZCL_RAW12:
					ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW12G, ShiftID, IntPtr.Zero);
					break;

				case ZCL_COLORID.ZCL_RAW16:
					ShiftMenu.Enabled = true;
					ZCL.GetDataDepth(hCamera, out Data);
					if (Data == 0)
						Data = 8;
					ShiftID = (ZCL_SHIFTID)(Data - 8);
					ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW16G, ShiftID, IntPtr.Zero);
					break;

				case ZCL_COLORID.ZCL_RGB16:
				case ZCL_COLORID.ZCL_SMONO16:
				case ZCL_COLORID.ZCL_SRGB16:
				case ZCL_COLORID.ZCL_BGR16:
					ShiftMenu.Enabled = true;
					ZCL.GetDataDepth(hCamera, out Data);
					if (Data == 0)
						Data = 8;
					ShiftID = (ZCL_SHIFTID)(Data - 8);
					ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_C32bit, ShiftID, IntPtr.Zero);
					break;

				case ZCL_COLORID.ZCL_MONO16:
					ShiftMenu.Enabled = true;
					ZCL.GetDataDepth(hCamera, out Data);
					if (Data == 0)
						Data = 8;
					ShiftID = (ZCL_SHIFTID)(Data - 8);
					if(Sony_CR)
						ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW16G, ShiftID, IntPtr.Zero);
					else
						ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_C32bit, ShiftID, IntPtr.Zero);
					break;

				case ZCL_COLORID.ZCL_MONO:
					if (Sony_CR)
						ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW8G, ShiftID, IntPtr.Zero);
					else
						ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_C32bit, ShiftID, IntPtr.Zero);
					break;

				default:
					ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_C32bit, ShiftID, IntPtr.Zero);
					break;
			}
			ZCL.ColorConvSetBMPINFO(hTbl, GetImage.Width, GetImage.Height, BmpInfo);
			SetShiftMenuCheck();

			RGBImage = Marshal.AllocCoTaskMem((int)BmpInfo.biSizeImage);

			if (!ZCL.IsoAlloc(hCamera))
			{
				MessageBox.Show("Isoc Alloc Error");
				ZCL.CloseConvHandle(hTbl);
				ZCL.Close(hCamera);
				hCamera = IntPtr.Zero;
				Marshal.FreeCoTaskMem(RGBImage);
				return;
			}

			this.ClientSize = new System.Drawing.Size(GetImage.Width, GetImage.Height + Menu1.Size.Height + 2);
			Gra = this.CreateGraphics();

			if (!ZCL.SetImageCallBack(hCamera, GCHandle.ToIntPtr(ParamCB), ImageCB, 3))
			{
				MessageBox.Show("Set Image Callback Error");
				ZCL.CloseConvHandle(hTbl);
				ZCL.Close(hCamera);
				hCamera = IntPtr.Zero;
				Marshal.FreeCoTaskMem(RGBImage);
				Gra.Dispose();
				return;
			}

			if (!ZCL.IsoStart(hCamera, 0))
			{
				MessageBox.Show("Iso Start Error");
				ZCL.SetImageCallBack(hCamera, IntPtr.Zero, IntPtr.Zero, 0);
				ZCL.CloseConvHandle(hTbl);
				ZCL.Close(hCamera);
				hCamera = IntPtr.Zero;
				Marshal.FreeCoTaskMem(RGBImage);
				Gra.Dispose();
			}
		}

		private void Form1_FormClosed(object sender, FormClosedEventArgs e)
		{
			if (!hCamera.Equals(IntPtr.Zero) )
			{
				if( !ZCL.IsoStop(hCamera))
					MessageBox.Show("Iso Stop Error");

				if( !ZCL.SetImageCallBack(hCamera, IntPtr.Zero, IntPtr.Zero, 0))
					MessageBox.Show("Set Image Callback Error");

				if( !ZCL.IsoRelease(hCamera))
					MessageBox.Show("Iso Release Error");

				if( !ZCL.Close(hCamera))
					MessageBox.Show("Camera Close Error");

				if( !hTbl.Equals(IntPtr.Zero) )
					ZCL.CloseConvHandle(hTbl);

				Marshal.FreeCoTaskMem(RGBImage);
				ParamCB.Free();
				Gra.Dispose();
			}
		}

		private void SetShiftMenuCheck()
		{
			Bit0.Checked = ShiftID == ZCL_SHIFTID.ZCL_SFT0 ? true : false;
			Bit1.Checked = ShiftID == ZCL_SHIFTID.ZCL_SFT1 ? true : false;
			Bit2.Checked = ShiftID == ZCL_SHIFTID.ZCL_SFT2 ? true : false;
			Bit3.Checked = ShiftID == ZCL_SHIFTID.ZCL_SFT3 ? true : false;
			Bit4.Checked = ShiftID == ZCL_SHIFTID.ZCL_SFT4 ? true : false;
			Bit5.Checked = ShiftID == ZCL_SHIFTID.ZCL_SFT5 ? true : false;
			Bit6.Checked = ShiftID == ZCL_SHIFTID.ZCL_SFT6 ? true : false;
			Bit7.Checked = ShiftID == ZCL_SHIFTID.ZCL_SFT7 ? true : false;
			Bit8.Checked = ShiftID == ZCL_SHIFTID.ZCL_SFT8 ? true : false;
		}

		public static void ImageCallback(IntPtr h_Camera, IntPtr pBuf, UInt32 Length, UInt32 Width, UInt32 Height, IntPtr pInfo, IntPtr Context)
		{
			GCHandle param = GCHandle.FromIntPtr(Context);
			Form1 FormRef = (Form1)param.Target;


			ZCL.ColorConvExec(FormRef.hTbl, Width, Height, FormRef.ColorMode, pBuf, FormRef.RGBImage);
			Bitmap RGB = new Bitmap((int)Width, (int)Height, (int)Width * 4, PixelFormat.Format32bppRgb, FormRef.RGBImage);
			FormRef.Gra.DrawImage(RGB, 0, FormRef.Menu1.Size.Height + 1);
			RGB.Dispose();
		}

		public static void SystemCallback(STATUS_SYSTEMCODE SystemStatus, IntPtr Context)
		{
			GCHandle param = GCHandle.FromIntPtr(Context);
			Form1 FormRef = (Form1)param.Target;

			switch (SystemStatus)
			{
				case STATUS_SYSTEMCODE.STATUSZCL_BUSRESET: // Processing of bus reset
					break;

				case STATUS_SYSTEMCODE.STATUSZCL_POWERUP: // Processing of PowerUP
					break;
			}
		}

		private void OnBit(object sender, EventArgs e)
		{
			ShiftID = (ZCL_SHIFTID)Convert.ToInt32(((ToolStripMenuItem)sender).Name.Substring(3));
			ZCL.IsoStop(hCamera);
			Thread.Sleep(500);
			ZCL.CloseConvHandle(hTbl);
			hTbl = IntPtr.Zero;
			switch (ColorMode.ColorID)
			{
				case ZCL_COLORID.ZCL_RAW16:
					ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW16G, ShiftID, IntPtr.Zero);
					break;

				case ZCL_COLORID.ZCL_RGB16:
				case ZCL_COLORID.ZCL_SMONO16:
				case ZCL_COLORID.ZCL_SRGB16:
				case ZCL_COLORID.ZCL_BGR16:
					ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_C32bit, ShiftID, IntPtr.Zero);
					break;

				case ZCL_COLORID.ZCL_MONO16:
					if (Sony_CR)
						ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_CFilterRAW16G, ShiftID, IntPtr.Zero);
					else
						ZCL.CreateConvHandle(out hTbl, ZCL_CONVERTMODE.ZCL_C32bit, ShiftID, IntPtr.Zero);
					break;
			}
			ZCL.IsoStart(hCamera, 0);
			SetShiftMenuCheck();
		}
	}
}