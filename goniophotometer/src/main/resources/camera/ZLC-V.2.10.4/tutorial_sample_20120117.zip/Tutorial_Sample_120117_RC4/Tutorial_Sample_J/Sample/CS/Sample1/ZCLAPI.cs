//***************************************************************//
//*	ZCL version 2.10 C# API Header File (32bit)					*//
//*	Copyright (C) 2011-2011 TechnoScope Co., Ltd.				*//
//***************************************************************//
using System;
using System.Runtime.InteropServices;


public enum ZCL_STDMODE
{
	ZCL_QQVGA = 0,						//   160 x  120 YUV(4:4:4)
	ZCL_QVGA,							//   320 x  240 YUV(4:2:2)
	ZCL_VGA_YUV1,						//   640 x  480 YUV(4:1:1)
	ZCL_VGA_YUV2,						//   640 x  480 YUV(4:2:2)
	ZCL_VGA_RGB,						//   640 x  480 RGB
	ZCL_VGA_MONO,						//   640 x  480 Mono
	ZCL_VGA_MONO16,						//   640 x  480 Mono16
	ZCL_SVGA_YUV,						//   800 x  600 YUV(4:2:2)
	ZCL_SVGA_RGB,						//   800 x  600 RGB
	ZCL_SVGA_MONO,						//   800 x  600 MONO
	ZCL_SVGA_MONO16,					//   800 x  600 MONO16
	ZCL_XGA_YUV,						//	1024 x  768 YUV(4:2:2)
	ZCL_XGA_RGB,						//	1024 x  768 RGB
	ZCL_XGA_MONO,						//	1024 x  768 MONO
	ZCL_XGA_MONO16,						//	1024 x  768 MONO16
	ZCL_SXGA_YUV,						//	1280 x  960 YUV(4:2:2)
	ZCL_SXGA_RGB,						//	1280 x  960 RGB
	ZCL_SXGA_MONO,						//	1280 x  960 MONO
	ZCL_SXGA_MONO16,					//	1280 x  960 MONO16
	ZCL_UXGA_YUV,						//	1600 x 1200 YUV(4:2:2)
	ZCL_UXGA_RGB,						//	1600 x 1200 RGB
	ZCL_UXGA_MONO,						//	1600 x 1200 MONO
	ZCL_UXGA_MONO16						//	1600 x 1200 MONO16
}


public enum ZCL_FPS
{
	ZCL_Fps_1875 = 0,					//	FrameRate_0 (1.875fps)
	ZCL_Fps_375,						//	FrameRate_1 (3.75fps)
	ZCL_Fps_75,							//	FrameRate_2 (7.5fps)
	ZCL_Fps_15,							//	FrameRate_3 (15fps)
	ZCL_Fps_30,							//	FrameRate_4 (30fps)
	ZCL_Fps_60,							//	FrameRate_5 (60fps)
	ZCL_Fps_120,						//	FrameRate_6 (120fps)
	ZCL_Fps_240							//	FrameRate_7 (240fps)
}


public enum ZCL_EXTMODE
{
	ZCL_Mode_0 = 0,						//	Mode_0
	ZCL_Mode_1,							//	Mode_1
	ZCL_Mode_2,							//	Mode_2
	ZCL_Mode_3,							//	Mode_3
	ZCL_Mode_4,							//	Mode_4
	ZCL_Mode_5,							//	Mode_5
	ZCL_Mode_6,							//	Mode_6
	ZCL_Mode_7,							//	Mode_7
	ZCL_Mode_8,							//	Mode_8
	ZCL_Mode_9,							//	Mode_9
	ZCL_Mode_10,						//	Mode_10
	ZCL_Mode_11,						//	Mode_11
	ZCL_Mode_12,						//	Mode_12
	ZCL_Mode_13,						//	Mode_13
	ZCL_Mode_14,						//	Mode_14
	ZCL_Mode_15,						//	Mode_15
	ZCL_Mode_16,						//	Mode_16
	ZCL_Mode_17,						//	Mode_17
	ZCL_Mode_18,						//	Mode_18
	ZCL_Mode_19,						//	Mode_19
	ZCL_Mode_20,						//	Mode_20
	ZCL_Mode_21,						//	Mode_21
	ZCL_Mode_22,						//	Mode_22
	ZCL_Mode_23,						//	Mode_23
	ZCL_Mode_24,						//	Mode_24
	ZCL_Mode_25,						//	Mode_25
	ZCL_Mode_26,						//	Mode_26
	ZCL_Mode_27,						//	Mode_27
	ZCL_Mode_28,						//	Mode_28
	ZCL_Mode_29,						//	Mode_29
	ZCL_Mode_30,						//	Mode_30
	ZCL_Mode_31							//	Mode_31
}


public enum ZCL_COLORID
{
	ZCL_MONO = 0,						//	MONO			8bit No Conv
	ZCL_YUV411,							//	YUV411			8bit
	ZCL_YUV422,							//	YUV422			8bit
	ZCL_YUV444,							//	YUV444			8bit
	ZCL_RGB,							//	RGB				8bit
	ZCL_MONO16,							//	MONO16			16bit
	ZCL_RGB16,							//	RGB16			16bit
	ZCL_SMONO16,						//	Signed MONO16	16bit
	ZCL_SRGB16,							//	Signed RGB16	16bit
	ZCL_RAW,							//	RAW				8bit
	ZCL_RAW16,							//	RAW16			16bit
	ZCL_MONO12,							//	MONO			12bit
	ZCL_RAW12,							//	RAW				12bit

	ZCL_MONO10,							//	MONO			10bit
	ZCL_RAW10,							//	RAW				10bit
	ZCL_BGR,							//	BGR				8bit No Conv
	ZCL_BGR16,							//	BGR				16bit
	ZCL_RGBA,							//	RGBA			8bit
	ZCL_BGRA,							//	BGRA			8bit No Conv
	ZCL_RGB10G,							//	RGB V1			10bit
	ZCL_RGB10P,							//	RGB V2			10bit
	ZCL_RGB12,							//	RGB				12bit
	ZCL_RGB565,							//	RGB				5bit
	ZCL_BGR565,							//	BGR				5bit No Conv
	ZCL_YUV422Y,						//	YUV422			8bit
}


public enum ZCL_PIXELFORMATID
{
	ZCL_PIX_MONO1P = 0x01010038,
	ZCL_PIX_MONO4P = 0x01010039,
	ZCL_PIX_MONO8 = 0x01080001,
	ZCL_PIX_MONO8S = 0x01080002,
	ZCL_PIX_MONO8_SIGNED = 0x01080002,
	ZCL_PIX_MONO10 = 0x01100003,
	ZCL_PIX_MONO10_PACKED = 0x010C0004,
	ZCL_PIX_MONO10G12 = 0x010C003A,
	ZCL_PIX_MONO12 = 0x01100005,
	ZCL_PIX_MONO12_PACKED = 0x010C0006,
	ZCL_PIX_MONO12G = 0x010C003B,
	ZCL_PIX_MONO14 = 0x01100025,
	ZCL_PIX_MONO16 = 0x01100007,
	ZCL_PIX_BAYERGR8 = 0x01080008,
	ZCL_PIX_BAYERRG8 = 0x01080009,
	ZCL_PIX_BAYERGB8 = 0x0108000A,
	ZCL_PIX_BAYERBG8 = 0x0108000B,
	ZCL_PIX_BAYERGR10 = 0x0110000C,
	ZCL_PIX_BAYERRG10 = 0x0110000D,
	ZCL_PIX_BAYERGB10 = 0x0110000E,
	ZCL_PIX_BAYERBG10 = 0x0110000F,
	ZCL_PIX_BAYERGR12 = 0x01100010,
	ZCL_PIX_BAYERRG12 = 0x01100011,
	ZCL_PIX_BAYERGB12 = 0x01100012,
	ZCL_PIX_BAYERBG12 = 0x01100013,
	ZCL_PIX_BAYERGR10_PACKED = 0x010C0026,
	ZCL_PIX_BAYERGR10G12 = 0x010C003C,
	ZCL_PIX_BAYERRG10_PACKED = 0x010C0027,
	ZCL_PIX_BAYERRG10G12 = 0x010C003D,
	ZCL_PIX_BAYERGB10_PACKED = 0x010C0028,
	ZCL_PIX_BAYERGB10G12 = 0x010C003E,
	ZCL_PIX_BAYERBG10_PACKED = 0x010C0029,
	ZCL_PIX_BAYERBG10G12 = 0x010C003F,
	ZCL_PIX_BAYERGR12_PACKED = 0x010C002A,
	ZCL_PIX_BAYERGR12G = 0x010C0040,
	ZCL_PIX_BAYERRG12_PACKED = 0x010C002B,
	ZCL_PIX_BAYERRG12G = 0x010C0041,
	ZCL_PIX_BAYERGB12_PACKED = 0x010C002C,
	ZCL_PIX_BAYERGB12G = 0x010C0042,
	ZCL_PIX_BAYERBG12_PACKED = 0x010C002D,
	ZCL_PIX_BAYERBG12G = 0x010C0043,
	ZCL_PIX_BAYERGR16_PACKED = 0x0110002E,
	ZCL_PIX_BAYERGR16 = 0x0110002E,
	ZCL_PIX_BAYERRG16_PACKED = 0x0110002F,
	ZCL_PIX_BAYERRG16 = 0x0110002F,
	ZCL_PIX_BAYERGB16_PACKED = 0x01100030,
	ZCL_PIX_BAYERGB16 = 0x01100030,
	ZCL_PIX_BAYERBG16_PACKED = 0x01100031,
	ZCL_PIX_BAYERBG16 = 0x01100031,
	ZCL_PIX_RGB8_PACKED = 0x02180014,
	ZCL_PIX_RGB8 = 0x02180014,
	ZCL_PIX_BGR8_PACKED = 0x02180015,
	ZCL_PIX_BGR8 = 0x02180015,
	ZCL_PIX_RGBA8 = 0x02180016,
	ZCL_PIX_BGRA8 = 0x02180017,
	ZCL_PIX_RGB10_PACKED = 0x02300018,
	ZCL_PIX_RGB10 = 0x02300018,
	ZCL_PIX_BGR10_PACKED = 0x02300019,
	ZCL_PIX_BGR10 = 0x02300019,
	ZCL_PIX_RGB12_PACKED = 0x0230001A,
	ZCL_PIX_RGB12 = 0x0230001A,
	ZCL_PIX_BGR12_PACKED = 0x0230001B,
	ZCL_PIX_BGR12 = 0x0230001B,
	ZCL_PIX_RGB16_PACKED = 0x02300033,
	ZCL_PIX_RGB16 = 0x02300033,
	ZCL_PIX_RGB10V1_PACKED = 0x0220001C,
	ZCL_PIX_RGB10G32 = 0x02200044,
	ZCL_PIX_RGB10V2_PACKED = 0x0220001D,
	ZCL_PIX_RGB10P32 = 0x0220001D,
	ZCL_PIX_RGB12V1_PACKED = 0x02240034,
	ZCL_PIX_RGB12G = 0x02240045,
	ZCL_PIX_RGB565_PACKED = 0x02100035,
	ZCL_PIX_RGB565P = 0x02100035,
	ZCL_PIX_BGR565_PACKED = 0x02100036,
	ZCL_PIX_BGR565P = 0x02100036,
	ZCL_PIX_YUV411_PACKED = 0x020C001E,
	ZCL_PIX_YUV411_8_UYYVYY = 0x020C001E,
	ZCL_PIX_YUV422_PACKED = 0x0210001F,
	ZCL_PIX_YUV422_8_UYVY = 0x0210001F,
	ZCL_PIX_YUV422_YUYV_PACKED = 0x02100032,
	ZCL_PIX_YUV422_8_YUYV = 0x02100032,
	ZCL_PIX_YUV444_PACKED = 0x02180020,
	ZCL_PIX_YUV8_UYV = 0x02180020,
}


public enum ZCL_GIGESTREAMTYPE
{
	ZCL_GIGEIMAGEDATA = 1,
	ZCL_GIGERAWDATA,
	ZCL_GIGEFILEDATA,
	ZCL_GIGECHUNKDATA,
	ZCL_GIGEEXTCHUNKDATA,
	ZCL_GIGEVENDORDATA = 0x8000,
}


public enum ZCL_FEATUREID
{
	ZCL_BRIGHTNESS = 0,					//	Brightness
	ZCL_AE,								//	Auto Exposure
	ZCL_SHARPNESS,						//	Sharpness
	ZCL_WHITEBALANCE,					//	White Balance
	ZCL_HUE,							//	HUE
	ZCL_SATURATION,						//	Saturation
	ZCL_GAMMA,							//	Gamma
	ZCL_SHUTTER,						//	Shutter
	ZCL_GAIN,							//	Gain
	ZCL_IRIS,							//	Iris
	ZCL_FOCUS,							//	Focus
	ZCL_TEMPERATURE,					//	Temperature
	ZCL_TRIGGER,						//	Trigger
	ZCL_TRIGGER_DELAY,					//	Trigger Delay
	ZCL_WHITE_SHADING,					//	White Shading
	ZCL_FRAMERATE,						//	FrameRate
	ZCL_ZOOM,							//	Zoom
	ZCL_PAN,							//	Pan
	ZCL_TILT,							//	Tilt
	ZCL_OPTICAL_FILTER,					//	Optical Filter
	ZCL_ONE_SHOT,						//	One Shot
	ZCL_MULTI_SHOT,						//	Multi Shot
	ZCL_POWER_ONOFF,					//	Power On Off
	ZCL_MEMORYCHANNEL,					//	Memory Channel
}


public enum ZCL_TRIGGERMODE
{
	ZCL_Trigger_Mode0 = 0,				//	Trigger Mode0
	ZCL_Trigger_Mode1,					//	Trigger Mode1
	ZCL_Trigger_Mode2,					//	Trigger Mode2
	ZCL_Trigger_Mode3,					//	Trigger Mode3
	ZCL_Trigger_Mode4,					//	Trigger Mode4
	ZCL_Trigger_Mode5,					//	Trigger Mode5
	ZCL_Trigger_Mode14 = 14,			//	Trigger Mode14
	ZCL_Trigger_Mode15					//	Trigger Mode15
}


public enum ZCL_TRIGGERSOURCE
{
	ZCL_Trigger_Source0 = 0,			//	Trigger Source0
	ZCL_Trigger_Source1,				//	Trigger Source1
	ZCL_Trigger_Source2,				//	Trigger Source2
	ZCL_Trigger_Source3,				//	Trigger Source3
	ZCL_Software_Trigger = 7			//	Software Trigger
}


public enum ZCL_TRANSMITSPEED
{
	ZCL_S100M = 0,						//	100M
	ZCL_S200M,							//	200M
	ZCL_S400M,							//	400M
	ZCL_S800M,							//	800M
	ZCL_S1600M,							//	1.6G
	ZCL_S3200M							//	3.2G
}


public enum ZCL_CONVERTMODE
{
	ZCL_C24bit = 0,						//	24bit
	ZCL_C16bit,							//	16bit
	ZCL_C15bit,							//	15bit
	ZCL_CFilter,						//	Color Filter
	ZCL_C32bit,							//	32bit
	ZCL_CFilterRAW8G,					//	RAW8 + G
	ZCL_CFilterRAW16,					//	RAW16
	ZCL_CFilterRAW16G,					//	RAW16 + G
	ZCL_CFilterRAW12,					//	RAW12
	ZCL_CFilterRAW12G,					//	RAW12 + G
	ZCL_CFilterRAW10,					//	RAW10
	ZCL_CFilterRAW10G,					//	RAW10 + G
	ZCL_CFilter24RAW8,					//	RAW8
	ZCL_CFilter24RAW8G,					//	RAW8 + G
	ZCL_CFilter24RAW16,					//	RAW16
	ZCL_CFilter24RAW16G,				//	RAW16 + G
	ZCL_CFilter24RAW12,					//	RAW12
	ZCL_CFilter24RAW12G,				//	RAW12 + G
	ZCL_CFilter24RAW10,					//	RAW10
	ZCL_CFilter24RAW10G,				//	RAW10 + G
	ZCL_CFilterRAW8 = ZCL_CFilter,		//	RAW8
}


public enum ZCL_CFILTERMODE
{
	ZCL_FRGGB = 0,						//	RG/GB
	ZCL_FGBRG,							//	GB/RG
	ZCL_FGRBG,							//	GR/BG
	ZCL_FBGGR							//	BG/GR
}


public enum ZCL_SHIFTID
{
	//	15 14 13 12 ..... 2 1 0
	ZCL_SFT0 = 0,						//	7-0 bit
	ZCL_SFT1,							//	8-1 bit
	ZCL_SFT2,							//	9-2 bit
	ZCL_SFT3,							//	10-3 bit
	ZCL_SFT4,							//	11-4 bit
	ZCL_SFT5,							//	12-5 bit
	ZCL_SFT6,							//	13-6 bit
	ZCL_SFT7,							//	14-7 bit
	ZCL_SFT8							//	15-8 bit
}


public enum ZCL_STOREMODE
{
	ZCL_BMPmode = 0,					//	BMP�t�@�C�����[�h
	ZCL_MEMmode,						//	MEMORY���[�h
	ZCL_BMPmodeLR,						//	BMP�t�@�C�����[�h ���E���]
	ZCL_MEMmodeLR,						//	MEMORY���[�h ���E���]
}


public enum ZCL_SETREQID
{
	ZCL_FEATURE_OFF = 0,				//	Feature�@�\��~
	ZCL_ONE_PUSH,						//	One Push�̎��s
	ZCL_AUTO,							//	�����ݒ�
	ZCL_VALUE,							//	�}�j���A���l�ݒ�
	ZCL_ABSVALUE,						//	ABS �}�j���A���l�ݒ�
	ZCL_ABSONE_PUSH,					//	ABS One Push�̎��s
	ZCL_ABSAUTO							//	ABS �����ݒ�
}


public enum ZCL_ENDIAN
{
	ZCL_BIGENDIAN = 0,					//	Big Endian
	ZCL_LITTLEENDIAN					//	Little Endian
}


public enum ZCL_CAMERATYPE
{
	ZCL_CAMERA1394 = 0,
	ZCL_CAMERAGIGE
}


public enum STATUS_SYSTEMCODE
{
	STATUSZCL_BUSRESET = 1,				//	�o�X���Z�b�g����
	STATUSZCL_POWERUP					//	�V�X�e���̃X���[�v����̕��A
}


//�X�e�[�^�X�R�[�h
public enum STATUS_RTNCODE
{
	STATUSZCL_NO_ERROR = 0,				//	�G���[�Ȃ�
	STATUSZCL_COMPLETE = 0,				//	��������
	STATUSZCL_PARAMETER_ERROR,			//	�p�����[�^���s��
	STATUSZCL_BUFFER_SHORT,				//	�o�b�t�@���Z��

	STATUSZCL_OPEN_ERROR,				//	�J�����̃I�[�v���Ɏ��s�@
	STATUSZCL_OPENED,					//	�J���������łɃI�[�v������Ă���
	STATUSZCL_CANNOT_FOUND,				//	�J������������Ȃ�
	STATUSZCL_NO_OPEN,					//	�J�������I�[�v������Ă��Ȃ�

	STATUSZCL_COMMUNICATE_ERROR,		//	�ʐM�Ɏ��s

	STATUSZCL_DATA_INACCURACY,			//	�擾�f�[�^���s���m�ł���B
	STATUSZCL_NO_SUPPORT,				//	�@�\������(�w�肳�ꂽ�@�\���ΏۃJ�����Ɏ�������Ă��Ȃ�)
	STATUSZCL_VMODE_ERROR,				//	�J�����p�����[�^�ݒ�G���[
	STATUSZCL_FEATURE_ERROR,			//	�J����Feature�R���g���[���G���[
	STATUSZCL_VALUE_ERROR,				//	�J�����p�����[�^�ݒ�G���[(AbsValue�AValue)
	STATUSZCL_SELFCLEAR_ERROR,			//	�Z���t�N���A�t���O���N���A�����Ȃ�
	STATUSZCL_IMAGE_ERROR,				//	�C���[�W�T�C�Y�ݒ�G���[
	STATUSZCL_RESOURCE_ERROR,			//	�A�C�\�N���i�X�̃��\�[�X�m�ے��Ɉ˗����ꂽ
	STATUSZCL_NOTRESOURCE_ERROR,		//	�A�C�\�N���i�X�̃��\�[�X���m�ۂ���Ă��Ȃ�
	STATUSZCL_ALLOCATE_ERROR,			//	�A�C�\�N���i�X�̃��\�[�X�m�ۂɎ��s
	STATUSZCL_STARTED_ERROR,			//	���łɃX�^�[�g��Ԃł���
	STATUSZCL_NOTSTART_ERROR,			//	�X�^�[�g��ԂłȂ�
	STATUSZCL_REQUEST_ERROR,			//	�v�����s
	STATUSZCL_REQUEST_TIMEOUT,			//	�v���m�F�^�C���A�E�g

	STATUSZCL_SOFTTRIGGER_BUSY,			//	�\�t�g�g���K���s��
	STATUSZCL_MULTISLOPE_ERROR,			//	�}���`�X���[�v�ݒ�G���[

	STATUSZCL_ABORTEXEC_ERROR,			//	�L�����Z���������Ɉ˗����ꂽ

	STATUSZCL_REQUEST_USERCANCEL,		//	�v���̃��[�U�L�����Z��
	STATUSZCL_REQUEST_BUSRESETCANCEL,	//	�v���̃o�X���Z�b�g�L�����Z��

	STATUSZCL_REQUEST_EXEC,				//	�v�������s��

	STATUSZCL_STRUCTVERSION_ERROR,		//	�\���̂̃o�[�W�������s��

	STATUSZCL_FUNCTION_ONLY1394,		//	1394�J�����݂̂̊֐�
	STATUSZCL_FUNCTION_ONLYGIGE,		//	GIGE�J�����݂̂̊֐�
	STATUSZCL_GIGE_NOTMULTICAST,		//	Not MultiCast IPAddr 

	STATUSZCL_UNDEF_ERROR = 99			//	���̑��G���[
}


//	CameraInfo
[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
public class ZCL_CAMERAINFO
{
	public UInt64 UID;
	[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
	public String VendorName = null;
	[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
	public String ModelName = null;
}


//	GigECameraInfo
[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
public class ZCL_GIGECAMERAINFO
{
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
	public Byte[] MACAddr;
	public UInt16 Spec_Major;
	public UInt16 Spec_Minor;
	public UInt32 Dev_Mode;
	[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
	public String VendorName = null;
	[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
	public String ModelName = null;
	[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
	public String Dev_Ver = null;
	[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 48)]
	public String Vendor_Info = null;
	[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)]
	public String SerialNumber = null;
	[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)]
	public String UserName = null;
}


//	SetCameraMode
//	NowCameraMode
//	CheckCameraMode
[StructLayout(LayoutKind.Sequential)]
public class ZCL_CAMERAMODESTD
{
	public bool StdMode_Flag;
	public ZCL_STDMODE StdMode;
	public ZCL_FPS FrameRate;
	public UInt32 Rsvd;
}

[StructLayout(LayoutKind.Sequential)]
public class ZCL_CAMERAMODEEXT
{
	public bool StdMode_Flag;
	public ZCL_EXTMODE ExtMode;
	public ZCL_COLORID ColorID;
	public ZCL_CFILTERMODE FilterID;
}


//	GetStreamMode
[StructLayout(LayoutKind.Sequential)]
public class ZCL_GETSTREAMMODE
{
	public UInt16 MinWidth;
	public UInt16 MinHeight;
	public UInt16 MaxWidth;
	public UInt16 MaxHeight;
	public UInt16 IncWidth;
	public UInt16 IncHeight;
	public UInt16 IncOffsetX;
	public UInt16 IncOffsetY;
	public float MinFrameRate;
	public float MaxFrameRate;
	public bool InqFrameRateAuto;
	public UInt16 Width;
	public UInt16 Height;
	public UInt16 OffsetX;
	public UInt16 OffsetY;
	public ZCL_PIXELFORMATID PixelFormat;
	public bool FrameRateAuto;
	public float FrameRate;
}


//	SetStreamMode
[StructLayout(LayoutKind.Sequential)]
public class ZCL_SETSTREAMMODE
{
	public UInt16 Width;
	public UInt16 Height;
	public UInt16 OffsetX;
	public UInt16 OffsetY;
	public ZCL_PIXELFORMATID PixelFormat;
	public bool FrameRateAuto;
	public float FrameRate;
}


//	GetStreamMode
//	SetStreamMode
[StructLayout(LayoutKind.Sequential)]
public class ZCL_HEARTBEATMODE
{
	public bool Exec_Flag;
	public UInt32 TimeCount;
}


//	GetPixelFormat
[StructLayout(LayoutKind.Sequential)]
public class ZCL_PIXELFORMATLIST
{
	public UInt32 Count;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public ZCL_PIXELFORMATID[] PixelFormat;
}


//	GetExtModeInfo
[StructLayout(LayoutKind.Sequential)]
public class ZCL_EXTMODEINFO
{
	public UInt32 ModeCount;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public UInt16[] MaxWidth;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public UInt16[] MaxHeight;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public UInt16[] UnitSizeX;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public UInt16[] UnitSizeY;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public UInt16[] UnitPosX;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public UInt16[] UnitPosY;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_MONO;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_YUV411;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_YUV422;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_YUV444;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_RGB;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_MONO16;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_RGB16;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_SMONO16;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_SRGB16;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_RAW;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_RAW16;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_MONO12;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_RAW12;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_MONO10;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_RAW10;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_BGR;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_BGR16;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_RGBA;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_BGRA;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_RGB10G;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_RGB10P;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_RGB12;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_RGB565;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_BGR565;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public bool[] C_YUV422Y;
}


//	CheckFeature
[StructLayout(LayoutKind.Sequential)]
public class ZCL_CHECKFEATURE
{
	public ZCL_FEATUREID FeatureID;
	public bool PresenceFlag;

	public bool Abs_Inq;
	public bool One_Push_Inq;
	public bool ReadOut_Inq;
	public bool On_Off_Inq;
	public bool Auto_Inq;
	public bool Manual_Inq;
	public UInt32 Min_Value;
	public UInt32 Max_Value;
	public float Abs_Min_Value;
	public float Abs_Max_Value;

	public bool Trigger_Abs_Inq;
	public bool Trigger_ReadOut_Inq;
	public bool Trigger_On_Off_Inq;
	public bool Trigger_Polarity_Inq;
	public bool Trigger_Value_Read_Inq;
	public bool Trigger_Source0;
	public bool Trigger_Source1;
	public bool Trigger_Source2;
	public bool Trigger_Source3;
	public bool Trigger_Software;
	public bool Trigger_Mode0;
	public bool Trigger_Mode1;
	public bool Trigger_Mode2;
	public bool Trigger_Mode3;
	public bool Trigger_Mode4;
	public bool Trigger_Mode5;
	public bool Trigger_Mode14;
	public bool Trigger_Mode15;
	public float Trigger_Abs_Min_Value;
	public float Trigger_Abs_Max_Value;

	public byte Max_MemChannel;
}


//	GetFeatureValue
[StructLayout(LayoutKind.Sequential)]
public class ZCL_GETFEATUREVALUE
{
	public ZCL_FEATUREID FeatureID;

	public bool Abs;
	public bool On_Off;
	public bool Auto_M;
	public UInt32 Value;
	public float Abs_Value;

	public bool WhiteBalance_Abs;
	public bool WhiteBalance_On_Off;
	public bool WhiteBalance_Auto_M;
	public UInt32 WhiteBalance_UB_Value;
	public UInt32 WhiteBalance_VR_Value;
	public float WhiteBalance_Abs_Value;

	public bool Temperature_Abs;
	public bool Temperature_On_Off;
	public bool Temperature_Auto_M;
	public UInt32 Temperature_Target_Value;
	public UInt32 Temperature_Temp_Value;
	public float Temperature_Abs_Value;

	public bool Trigger_Abs;
	public bool Trigger_On_Off;
	public bool Trigger_Polarity;
	public bool Trigger_Value;
	public byte Trigger_Source;
	public byte Trigger_Mode;
	public UInt32 Trigger_Parameter;
	public float Trigger_Abs_Value;

	public bool TriggerDelay_Abs;
	public bool TriggerDelay_On_Off;
	public UInt32 TriggerDelay_Value;
	public float TriggerDelay_Abs_Value;

	public bool WhiteShading_Abs;
	public bool WhiteShadingOn_Off;
	public bool WhiteShadingAuto_M;
	public byte WhiteShadingR_Value;
	public byte WhiteShadingG_Value;
	public byte WhiteShadingB_Value;
	public float WhiteShadingAbs_Value;

	public bool Exec_Flag;
	public bool PowerOn_Flag;
}


//	SetFeatureValue
[StructLayout(LayoutKind.Sequential)]
public class ZCL_SETFEATUREVALUE
{
	public ZCL_SETREQID ReqID;
	public ZCL_FEATUREID FeatureID;

	public UInt32 Value;
	public float Abs_Value;

	public UInt32 WhiteBalance_UB_Value;
	public UInt32 WhiteBalance_VR_Value;
	public float WhiteBalance_Abs_Value;

	public bool Trigger_Polarity;
	public byte Trigger_Source;
	public byte Trigger_Mode;
	public UInt32 Trigger_Parameter;
	public float Trigger_Abs_Value;

	public byte WhiteShading_R_Value;
	public byte WhiteShading_G_Value;
	public byte WhiteShading_B_Value;
	public float WhiteShading_Abs_Value;
}


//	GetImageInfo
[StructLayout(LayoutKind.Sequential)]
public class ZCL_GETIMAGEINFO
{
	public bool StdMode_Flag;
	public UInt16 PosX;
	public UInt16 PosY;
	public UInt16 Width;
	public UInt16 Height;
	public ZCL_COLORID ColorID;
	public UInt32 DataLength;
	public UInt32 Buffer;
	public UInt16 MaxImageX;
	public UInt16 MaxImageY;
	public UInt16 UnitSizeX;
	public UInt16 UnitSizeY;
	public UInt16 UnitPosX;
	public UInt16 UnitPosY;
}


//	SetImageInfo
[StructLayout(LayoutKind.Sequential)]
public class ZCL_SETIMAGEINFO
{
	public UInt16 PosX;
	public UInt16 PosY;
	public UInt16 Width;
	public UInt16 Height;
	public bool MaxSize_Flag;
}


//	StreamComplete
[StructLayout(LayoutKind.Sequential)]
public class ZCL_STREAMINFOV0_IMAGE
{
	public UInt32 Ver;
	public UInt16 Stream_Type;
	public UInt16 Fream_ID;

	public UInt64 TimeStamp;

	public ZCL_PIXELFORMATID Pixel_Type;
	public UInt32 Width;
	public UInt32 Height;
	public UInt32 Offset_X;
	public UInt32 Offset_Y;
	public UInt16 Padding_X;
	public UInt16 Padding_Y;
	public UInt32 Size_Y;
}


//	StreamComplete
[StructLayout(LayoutKind.Sequential)]
public class ZCL_STREAMINFOV0_RAW
{
	public UInt32 Ver;
	public UInt16 Stream_Type;
	public UInt16 Fream_ID;

	public UInt64 TimeStamp;

	public UInt64 DataSize;
}


//	StreamComplete
[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
public class ZCL_STREAMINFOV0_FILE
{
	public UInt32 Ver;
	public UInt16 Stream_Type;
	public UInt16 Fream_ID;

	public UInt64 TimeStamp;

	public UInt64 DataSize;
	[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 512)]
	public String File_Name = null;
}


//	StreamComplete
[StructLayout(LayoutKind.Sequential)]
public class ZCL_STREAMINFOV0_CHUNK
{
	public UInt32 Ver;
	public UInt16 Stream_Type;
	public UInt16 Fream_ID;

	public UInt64 TimeStamp;

	public UInt32 DataSize;
}


//	StreamComplete
[StructLayout(LayoutKind.Sequential)]
public class ZCL_STREAMINFOV0_EXT_CHUNK
{
	public UInt32 Ver;
	public UInt16 Stream_Type;
	public UInt16 Fream_ID;

	public UInt64 TimeStamp;

	public ZCL_PIXELFORMATID Pixel_Type;
	public UInt32 Width;
	public UInt32 Height;
	public UInt32 Offset_X;
	public UInt32 Offset_Y;
	public UInt16 Padding_X;
	public UInt16 Padding_Y;
	public UInt32 DataSize;
	public UInt32 Size_Y;
	public UInt32 Chunk_ID;
}


//	StreamComplete
[StructLayout(LayoutKind.Sequential)]
public class ZCL_STREAMINFOV0_VENDOR
{
	public UInt32 Ver;
	public UInt16 Stream_Type;
	public UInt16 Fream_ID;

	public UInt64 TimeStamp;

	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
	public UInt32[] Vendor_Data;
}


//	StreamComplete
[StructLayout(LayoutKind.Sequential)]
public class ZCL_STREAMINFOV1_IMAGE
{
	public UInt32 Ver;
	public UInt32 Stream_Type;
	public UInt64 Fream_ID;

	public UInt64 TimeStamp;

	public ZCL_PIXELFORMATID Pixel_Type;
	public UInt32 Width;
	public UInt32 Height;
	public UInt32 Offset_X;
	public UInt32 Offset_Y;
	public UInt16 Padding_X;
	public UInt16 Padding_Y;
	public UInt32 Size_Y;
}


//	StreamComplete
[StructLayout(LayoutKind.Sequential)]
public class ZCL_STREAMINFOV1_RAW
{
	public UInt32 Ver;
	public UInt32 Stream_Type;
	public UInt64 Fream_ID;

	public UInt64 TimeStamp;

	public UInt64 DataSize;
}


//	StreamComplete
[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
public class ZCL_STREAMINFOV1_FILE
{
	public UInt32 Ver;
	public UInt32 Stream_Type;
	public UInt64 Fream_ID;

	public UInt64 TimeStamp;

	public UInt64 DataSize;
	[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 512)]
	public String File_Name = null;
}


//	StreamComplete
[StructLayout(LayoutKind.Sequential)]
public class ZCL_STREAMINFOV1_CHUNK
{
	public UInt32 Ver;
	public UInt32 Stream_Type;
	public UInt64 Fream_ID;

	public UInt64 TimeStamp;

	public UInt32 DataSize;
}


//	StreamComplete
[StructLayout(LayoutKind.Sequential)]
public class ZCL_STREAMINFOV1_EXT_CHUNK
{
	public UInt32 Ver;
	public UInt32 Stream_Type;
	public UInt64 Fream_ID;

	public UInt64 TimeStamp;

	public ZCL_PIXELFORMATID Pixel_Type;
	public UInt32 Width;
	public UInt32 Height;
	public UInt32 Offset_X;
	public UInt32 Offset_Y;
	public UInt16 Padding_X;
	public UInt16 Padding_Y;
	public UInt32 DataSize;
	public UInt32 Size_Y;
	public UInt32 Chunk_ID;
}


//	StreamComplete
[StructLayout(LayoutKind.Sequential)]
public class ZCL_STREAMINFOV1_VENDOR
{
	public UInt32 Ver;
	public UInt32 Stream_Type;
	public UInt64 Fream_ID;

	public UInt64 TimeStamp;

	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
	public UInt32[] Vendor_Data;
}


//
[StructLayout(LayoutKind.Sequential)]
public class ZCL_IMAGEDATAINFO_1394
{
	public ZCL_CAMERATYPE CameraType;
	public ZCL_TRANSMITSPEED Speed;
	public UInt32 CycleTime_S;
	public UInt32 CycleCount_S;
	public UInt32 CycleTime_E;
	public UInt32 CycleCount_E;
}


//
[StructLayout(LayoutKind.Sequential)]
public class ZCL_IMAGEDATAINFO_GIGE
{
	public ZCL_CAMERATYPE CameraType;
	public IntPtr PktInfo;
	public UInt32 PktInfoLen;
	public ZCL_STREAMINFOV0_IMAGE StreamInfo;
}


public enum ZCL_CFILTERMODE_SONY
{
	ZCL_SONYGBRG = 0,					//	GB/RG
	ZCL_SONYBGGR,						//	BG/GR
	ZCL_SONYRGGB,						//	RG/GB
	ZCL_SONYGRBG,						//	GR/BG
}


//	GetRegister
//	GetExtRegister
//	SetRegister
//	SetExtRegister
[StructLayout(LayoutKind.Sequential)]
public class ZCL_REGISTER
{
	public UInt32 Offset;
	public UInt32 Size;
	public IntPtr Value;
}


//	GigEGetRegister
//	GigESetRegister
[StructLayout(LayoutKind.Sequential)]
public class ZCL_GIGEREGISTER
{
	public UInt32 Count;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 135)]
	public UInt32[] Addr;
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 135)]
	public UInt32[] Value;
}


[StructLayout(LayoutKind.Sequential)]
public class ZCL_COLORVALUE
{
	public double a;
	public double b;
	public double c;
	public double d;
}


[StructLayout(LayoutKind.Sequential)]
public class ZCL_COLORMODE
{
	public ZCL_COLORID ColorID;
	public ZCL_CFILTERMODE CFilter;
	public ZCL_STOREMODE StoreMode;
	public ZCL_ENDIAN EndianMode;
	public bool Parallel_Flag;
}


[StructLayout(LayoutKind.Sequential)]
public class ZCL_RECT
{
	public int Left;
	public int Top;
	public int Right;
	public int Bottom;
}


[StructLayout(LayoutKind.Sequential)]
public class ZCL_BITMAPINFO
{
	public UInt32 biSize;
	public int biWidth;
	public int biHeight;
	public UInt16 biPlanes;
	public UInt16 biBitCount;
	public UInt32 biCompression;
	public UInt32 biSizeImage;
	public int biXPelsPerMeter;
	public int biYPelsPerMeter;
	public UInt32 biClrUsed;
	public UInt32 biClrImportant;
	public UInt32 RGBQUAD;
}


public class ZCL
{
	public delegate void SystemFunc(STATUS_SYSTEMCODE SystemStatus, IntPtr Context);
	public delegate void ImageFunc(IntPtr h_Camera, IntPtr pBuf, UInt32 Length, UInt32 Width, UInt32 Height, IntPtr pInfo, IntPtr Context);

	public const int ZCL_LIBRARY_STRUCT_VERSION = 210;

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSetCallBack")]
	public static extern void SetCallBack(IntPtr Context, SystemFunc cb);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSetCallBack")]
	public static extern void SetCallBack(IntPtr Context, IntPtr cb);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSetStructVersion")]
	public static extern void SetStructVersion(UInt32 VerNo);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGetLastError")]
	public static extern STATUS_RTNCODE GetLastError();

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGetList")]
	public static extern bool GetList(out UInt32 Count);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGetList")]
	public static extern bool GetList(IntPtr List);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLOpen")]
	public static extern bool Open(UInt64 UID, out IntPtr h_Camera);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLClose")]
	public static extern bool Close(IntPtr h_Camera);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLCameraInfo")]
	public static extern bool CameraInfo(IntPtr h_Camera, [Out]ZCL_CAMERAINFO CameraInfo, out ZCL_TRANSMITSPEED Speed);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLCameraInfo")]
	public static extern bool CameraInfo(IntPtr h_Camera, [Out]ZCL_CAMERAINFO CameraInfo, IntPtr Speed);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLCameraInfo")]
	public static extern bool CameraInfo(IntPtr h_Camera, IntPtr CameraInfo, out ZCL_TRANSMITSPEED Speed);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLCameraBusInfo")]
	public static extern bool CameraBusInfo(IntPtr h_Camera, out UInt32 BusInfo, out ZCL_CAMERATYPE CameraType);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLCameraBusInfo")]
	public static extern bool CameraBusInfo(IntPtr h_Camera, IntPtr BusInfo, out ZCL_CAMERATYPE CameraType);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLCameraBusInfo")]
	public static extern bool CameraBusInfo(IntPtr h_Camera, out UInt32 BusInfo, IntPtr CameraType);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLAllClose")]
	public static extern void AllClose();

	[DllImport("ZCL.DLL", EntryPoint = "ZCLCamera")]
	public static extern bool Camera(IntPtr h_Camera, out bool Ari_Flag);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLCameraInit")]
	public static extern bool CameraInit(IntPtr h_Camera);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLCheckCameraMode")]
	public static extern bool CheckCameraMode(IntPtr h_Camera, [In]ZCL_CAMERAMODESTD CameraMode);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLCheckCameraMode")]
	public static extern bool CheckCameraMode(IntPtr h_Camera, [In]ZCL_CAMERAMODEEXT CameraMode);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSetCameraMode")]
	public static extern bool SetCameraMode(IntPtr h_Camera, [In]ZCL_CAMERAMODESTD CameraMode);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSetCameraMode")]
	public static extern bool SetCameraMode(IntPtr h_Camera, [In]ZCL_CAMERAMODEEXT CameraMode);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLNowCameraMode")]
	public static extern bool NowCameraMode(IntPtr h_Camera, IntPtr CameraMode);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGetExtModeInfoCS")]
	public static extern bool GetExtModeInfo(IntPtr h_Camera, [Out]ZCL_EXTMODEINFO ExtInfo);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSaveMem")]
	public static extern bool SaveMem(IntPtr h_Camera, UInt32 MemoryNo);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLLoadMem")]
	public static extern bool LoadMem(IntPtr h_Camera, UInt32 MemoryNo);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLCheckFeatureCS")]
	public static extern bool CheckFeature(IntPtr h_Camera, [In, Out]ZCL_CHECKFEATURE CheckFeature);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGetFeatureValueCS")]
	public static extern bool GetFeatureValue(IntPtr h_Camera, [In, Out]ZCL_GETFEATUREVALUE GetFeature);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSetFeatureValueCS")]
	public static extern bool SetFeatureValue(IntPtr h_Camera, [In]ZCL_SETFEATUREVALUE SetFeature);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGetImageInfo")]
	public static extern bool GetImageInfo(IntPtr h_Camera, [Out]ZCL_GETIMAGEINFO ImageInfo);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSetImageInfo")]
	public static extern bool SetImageInfo(IntPtr h_Camera, [In]ZCL_SETIMAGEINFO ImageInfo);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSetImageInfo2")]
	public static extern bool SetImageInfo(IntPtr h_Camera, [In]ZCL_SETIMAGEINFO ImageInfo, out UInt32 MinPktLen, out UInt32 MaxPktLen);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSetPktSize")]
	public static extern bool SetPktSize(IntPtr h_Camera, UInt32 Number, out UInt32 PktLen);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSetPktSize")]
	public static extern bool SetPktSize(IntPtr h_Camera, UInt32 Number, IntPtr PktLen);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLIsoAlloc")]
	public static extern bool IsoAlloc(IntPtr h_Camera);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLIsoRelease")]
	public static extern bool IsoRelease(IntPtr h_Camera);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLIsoStart")]
	public static extern bool IsoStart(IntPtr h_Camera, UInt32 Strart_Mode);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLIsoStop")]
	public static extern bool IsoStop(IntPtr h_Camera);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSoftTrigger")]
	public static extern bool SoftTrigger(IntPtr h_Camera, bool On_Flag);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLImageReq")]
	public static extern bool ImageReq(IntPtr h_Camera, IntPtr Buffer, UInt32 Length);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLImageCompleteWait")]
	public static extern bool ImageComplete(IntPtr h_Camera, IntPtr Buffer, out ZCL_TRANSMITSPEED Speed, out UInt32 Cycle_Time, out UInt32 Cycle_Count);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLImageCompleteWait")]
	public static extern bool ImageComplete(IntPtr h_Camera, IntPtr Buffer, IntPtr Speed, out UInt32 Cycle_Time, out UInt32 Cycle_Count);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLImageCompleteWait")]
	public static extern bool ImageComplete(IntPtr h_Camera, IntPtr Buffer, IntPtr Speed, IntPtr Cycle_Time, IntPtr Cycle_Count);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLImageCompleteWaitTimeOut")]
	public static extern bool ImageComplete(IntPtr h_Camera, IntPtr Buffer, out ZCL_TRANSMITSPEED Speed, out UInt32 Cycle_Time, out UInt32 Cycle_Count, UInt32 TimeOut);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLImageCompleteWaitTimeOut")]
	public static extern bool ImageComplete(IntPtr h_Camera, IntPtr Buffer, IntPtr Speed, out UInt32 Cycle_Time, out UInt32 Cycle_Count, UInt32 TimeOut);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLImageCompleteWaitTimeOut")]
	public static extern bool ImageComplete(IntPtr h_Camera, IntPtr Buffer, IntPtr Speed, IntPtr Cycle_Time, IntPtr Cycle_Count, UInt32 TimeOut);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLAbortImageReqAll")]
	public static extern bool AbortImageReqAll(IntPtr h_Camera);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLVSyncReq")]
	public static extern bool VSyncReq(IntPtr h_Camera, out IntPtr Vsync);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLVSyncCompleteWait")]
	public static extern bool VSyncComplete(IntPtr h_Camera, IntPtr Vsync);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLVSyncCompleteWaitTimeOut")]
	public static extern bool VSyncComplete(IntPtr h_Camera, IntPtr Vsync, UInt32 TimeOut);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSetImageCallBack")]
	public static extern bool SetImageCallBack(IntPtr h_Camera, IntPtr Context, ImageFunc cb, UInt32 Count);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSetImageCallBack")]
	public static extern bool SetImageCallBack(IntPtr h_Camera, IntPtr Context, IntPtr cb, UInt32 Count);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGetRegister")]
	public static extern bool GetRegister(IntPtr h_Camera, [In]ZCL_REGISTER RegReq);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGetExtRegister")]
	public static extern bool GetExtRegister(IntPtr h_Camera, [In]ZCL_REGISTER RegReq);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSetRegister")]
	public static extern bool SetRegister(IntPtr h_Camera, [In]ZCL_REGISTER RegReq);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSetExtRegister")]
	public static extern bool SetExtRegister(IntPtr h_Camera, [In]ZCL_REGISTER RegReq);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGetConfigROM")]
	public static extern bool GetConfigROM(IntPtr h_Camera, IntPtr ConfigROM);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGetDataDepth")]
	public static extern bool GetDataDepth(IntPtr h_Camera, out UInt32 DataDepth);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLBroadcastPkt")]
	public static extern bool BroadcastPkt(IntPtr h_Camera, [In]ZCL_REGISTER RegReq);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLBroadcastPktAll")]
	public static extern bool BroadcastPktAll(IntPtr h_Camera, [In]ZCL_REGISTER RegReq);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGetLibraryRevision")]
	public static extern UInt32 GetLibraryRevision();

	[DllImport("ZCL.DLL", EntryPoint = "ZCLReset")]
	public static extern bool Reset();

	[DllImport("ZCL.DLL", EntryPoint = "ZCLReDetection")]
	public static extern void ReDetection();

	[DllImport("ZCL.DLL", EntryPoint = "ZCLShutterAbsAuto")]
	public static extern bool ShutterAbsAuto(IntPtr h_Camera);


	[DllImport("ZCL.DLL", EntryPoint = "ZCLOnePushAWB")]
	public static extern bool OnePushAWB(IntPtr h_Camera);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLOnePushAWBComplete")]
	public static extern bool OnePushAWBComplete(IntPtr h_Camera, UInt32 TimeOut);


	//***********************************************/
	//	Watch API									*/
	//***********************************************/
	[DllImport("ZCL.DLL", EntryPoint = "ZCLWatchOpen")]
	public static extern bool WatchOpen(UInt64 UID, out IntPtr h_Camera);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLWatchClose")]
	public static extern bool WatchClose(IntPtr h_Camera);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLWatchCamera")]
	public static extern bool WatchCamera(IntPtr h_Camera, out bool Start_OKFlag);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLWatchAlloc")]
	public static extern bool WatchAlloc(IntPtr h_Camera);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLWatchRelease")]
	public static extern bool WatchRelease(IntPtr h_Camera);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLWatchStart")]
	public static extern bool WatchStart(IntPtr h_Camera);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLWatchStop")]
	public static extern bool WatchStop(IntPtr h_Camera);
	//***********************************************/
	//	Watch API End								*/
	//***********************************************/


	//***********************************************/
	//	GigE Only API								*/
	//***********************************************/
	[DllImport("ZCL.DLL", EntryPoint = "ZCLGigECameraInfo")]
	public static extern bool GigECameraInfo(IntPtr h_Camera, [Out]ZCL_GIGECAMERAINFO CameraInfo, out UInt32 BusInfo);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGigECameraInfo")]
	public static extern bool GigECameraInfo(IntPtr h_Camera, [Out]ZCL_GIGECAMERAINFO CameraInfo, IntPtr BusInfo);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGetStreamMode")]
	public static extern bool GetStreamMode(IntPtr h_Camera, [Out]ZCL_GETSTREAMMODE GetStreamMode, out UInt32 PktLen, [Out]ZCL_HEARTBEATMODE HBMode);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGetStreamMode")]
	public static extern bool GetStreamMode(IntPtr h_Camera, IntPtr GetStreamMode, out UInt32 PktLen, [Out]ZCL_HEARTBEATMODE HBMode);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGetStreamMode")]
	public static extern bool GetStreamMode(IntPtr h_Camera, [Out]ZCL_GETSTREAMMODE GetStreamMode, IntPtr PktLen, [Out]ZCL_HEARTBEATMODE HBMode);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGetStreamMode")]
	public static extern bool GetStreamMode(IntPtr h_Camera, [Out]ZCL_GETSTREAMMODE GetStreamMode, out UInt32 PktLen, IntPtr HBMode);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGetStreamMode")]
	public static extern bool GetStreamMode(IntPtr h_Camera, IntPtr GetStreamMode, IntPtr PktLen, [Out]ZCL_HEARTBEATMODE HBMode);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGetStreamMode")]
	public static extern bool GetStreamMode(IntPtr h_Camera, IntPtr GetStreamMode, out UInt32 PktLen, IntPtr HBMode);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGetStreamMode")]
	public static extern bool GetStreamMode(IntPtr h_Camera, [Out]ZCL_GETSTREAMMODE GetStreamMode, IntPtr PktLen, IntPtr HBMode);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSetStreamMode")]
	public static extern bool SetStreamMode(IntPtr h_Camera, [In]ZCL_SETSTREAMMODE SetStreamMode, ref UInt32 PktLen, [In]ZCL_HEARTBEATMODE HBMode);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSetStreamMode")]
	public static extern bool SetStreamMode(IntPtr h_Camera, IntPtr SetStreamMode, ref UInt32 PktLen, [In]ZCL_HEARTBEATMODE HBMode);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSetStreamMode")]
	public static extern bool SetStreamMode(IntPtr h_Camera, [In]ZCL_SETSTREAMMODE SetStreamMode, IntPtr PktLen, [In]ZCL_HEARTBEATMODE HBMode);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSetStreamMode")]
	public static extern bool SetStreamMode(IntPtr h_Camera, [In]ZCL_SETSTREAMMODE SetStreamMode, ref UInt32 PktLen, IntPtr HBMode);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSetStreamMode")]
	public static extern bool SetStreamMode(IntPtr h_Camera, IntPtr SetStreamMode, IntPtr PktLen, [In]ZCL_HEARTBEATMODE HBMode);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSetStreamMode")]
	public static extern bool SetStreamMode(IntPtr h_Camera, IntPtr SetStreamMode, ref UInt32 PktLen, IntPtr HBMode);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLSetStreamMode")]
	public static extern bool SetStreamMode(IntPtr h_Camera, [In]ZCL_SETSTREAMMODE SetStreamMode, IntPtr PktLen, IntPtr HBMode);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGetPixelFormat")]
	public static extern bool GetPixelFormat(IntPtr h_Camera, [Out]ZCL_PIXELFORMATLIST PixelList);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLBandAdjust")]
	public static extern bool BandAdjust(IntPtr h_Camera, bool On_Flag, UInt32 Level);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGigEGetPktSize")]
	public static extern bool GigEGetPktSize(IntPtr h_Camera, out UInt32 PktLen, out UInt32 MinLen, out UInt32 MaxLen, out UInt32 IncLen);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGigESetPktSize")]
	public static extern bool GigESetPktSize(IntPtr h_Camera, UInt32 PktLen);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLTestStream")]
	public static extern bool TestStream(IntPtr h_Camera, UInt32 PktLen);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLStreamAlloc")]
	public static extern bool StreamAlloc(IntPtr h_Camera, byte[] IPaddr, bool Recover_Flag);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLStreamAlloc")]
	public static extern bool StreamAlloc(IntPtr h_Camera, IntPtr IPaddr, bool Recover_Flag);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLStreamRelease")]
	public static extern bool StreamRelease(IntPtr h_Camera);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLStreamStart")]
	public static extern bool StreamStart(IntPtr h_Camera, UInt32 StartMode);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLStreamStop")]
	public static extern bool StreamStop(IntPtr h_Camera);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLStreamReq")]
	public static extern bool StreamReq(IntPtr h_Camera, IntPtr Buffer, UInt32 Length);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLStreamComplete")]
	public static extern bool StreamComplete(IntPtr h_Camera, IntPtr Buffer, UInt32 TimeOut, IntPtr StreamInfo, out IntPtr PktInfo, out UInt32 PktInfoLen);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLStreamComplete")]
	public static extern bool StreamComplete(IntPtr h_Camera, IntPtr Buffer, UInt32 TimeOut, IntPtr StreamInfo, IntPtr PktInfo, IntPtr PktInfoLen);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLAbortStreamReqAll")]
	public static extern bool AbortStreamReqAll(IntPtr h_Camera);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGigEGetRegister")]
	public static extern bool GigEGetRegister(IntPtr h_Camera, [In, Out]ZCL_GIGEREGISTER RegReq);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGigESetRegister")]
	public static extern bool GigESetRegister(IntPtr h_Camera, [In]ZCL_GIGEREGISTER RegReq);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGigEGetMemory")]
	public static extern bool GigEGetMemory(IntPtr h_Camera, [In]ZCL_REGISTER RegReq);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLGigESetMemory")]
	public static extern bool GigESetMemory(IntPtr h_Camera, [In]ZCL_REGISTER RegReq);
	//***********************************************/
	//	GigE Only API End							*/
	//***********************************************/


	//***********************************************/
	//	Color Convert								*/
	//***********************************************/
	[DllImport("ZCL.DLL", EntryPoint = "ZCLCreateConvHandle")]
	public static extern bool CreateConvHandle(out IntPtr hCtbl, ZCL_CONVERTMODE ConvertMode, ZCL_SHIFTID ShiftID, [In]ZCL_COLORVALUE ColorValue);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLCreateConvHandle")]
	public static extern bool CreateConvHandle(out IntPtr hCtbl, ZCL_CONVERTMODE ConvertMode, ZCL_SHIFTID ShiftID, IntPtr ColorValue);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLCloseConvHandle")]
	public static extern void CloseConvHandle(IntPtr hCtbl);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLCloseAllConvHandle")]
	public static extern void CloseAllConvHandle();

	[DllImport("ZCL.DLL", EntryPoint = "ZCLColorConvExec")]
	public static extern bool ColorConvExec(IntPtr hCtbl, UInt32 Width, UInt32 Height, [In]ZCL_COLORMODE Mode, IntPtr InBuf, IntPtr OutBuf);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLColorConvSetBMPINFO")]
	public static extern bool ColorConvSetBMPINFO(IntPtr hCtbl, UInt32 Width, UInt32 Height, [Out]ZCL_BITMAPINFO BmpInfo);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLCreateMonoBMPINFO")]
	public static extern bool CreateMonoBMPINFO(UInt32 Width, UInt32 Height, out IntPtr Bmp, out UInt32 Length);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLDeleteMonoBMPINFO")]
	public static extern void DeleteMonoBMPINFO(IntPtr Bmp);

	[DllImport("ZCL.DLL", EntryPoint = "ZCLDeleteAllMonoBMPINFO")]
	public static extern void DeleteAllMonoBMPINFO();
}