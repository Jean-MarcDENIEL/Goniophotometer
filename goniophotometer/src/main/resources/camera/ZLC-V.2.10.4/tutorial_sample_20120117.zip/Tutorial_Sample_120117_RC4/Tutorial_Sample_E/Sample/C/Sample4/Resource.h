//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Sample4.rc
//
#define IDR_MAINFRAME                   128
#define IDD_CTLWND                      129
#define IDC_AutoBright                  1002
#define IDC_SlBright                    1003
#define IDC_AutoAe                      1004
#define IDC_SlAe                        1005
#define IDC_AutoSharp                   1006
#define IDC_SlSharp                     1007
#define IDC_AutoWhite                   1008
#define IDC_SlWhiteU                    1009
#define IDC_AutoHue                     1010
#define IDC_SlHue                       1011
#define IDC_AutoSaturation              1012
#define IDC_SlSaturation                1013
#define IDC_SlWhiteV                    1015
#define IDC_AutoGamma                   1016
#define IDC_SlGamma                     1017
#define IDC_AutoShutter                 1018
#define IDC_SlShutter                   1019
#define IDC_AutoOptical                 1020
#define IDC_SlOptical                   1021
#define IDC_AutoTilt                    1022
#define IDC_SlTilt                      1023
#define IDC_AutoPan                     1024
#define IDC_SlPan                       1025
#define IDC_AutoFocus                   1026
#define IDC_SlFocus                     1027
#define IDC_AutoZoom                    1028
#define IDC_SlZoom                      1029
#define IDC_StBright                    1033
#define IDC_AutoIris                    1034
#define IDC_SlIris                      1035
#define IDC_AutoGain                    1036
#define IDC_SlGain                      1037
#define IDC_StAe                        1038
#define IDC_StSharp                     1039
#define IDC_StWhite                     1040
#define IDC_StHue                       1041
#define IDC_StSaturation                1042
#define IDC_StGamma                     1043
#define IDC_StShutter                   1044
#define IDC_StGain                      1045
#define IDC_StIris                      1046
#define IDC_StZoom                      1047
#define IDC_StFocus                     1048
#define IDC_StPan                       1049
#define IDC_StTilt                      1050
#define IDC_StOptical                   1051
#define ID_CONTROL                      32771
#define ID_BIT0                         32772
#define ID_BIT1                         32773
#define ID_BIT2                         32774
#define ID_BIT3                         32775
#define ID_BIT4                         32776
#define ID_BIT5                         32777
#define ID_BIT6                         32778
#define ID_BIT7                         32779
#define ID_BIT8                         32780

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         1052
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
