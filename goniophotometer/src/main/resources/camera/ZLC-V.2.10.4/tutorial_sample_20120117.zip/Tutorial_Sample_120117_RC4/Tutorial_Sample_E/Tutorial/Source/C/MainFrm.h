// MainFrm.h : interface of the CMainFrame class
//


#pragma once

#include "ChildView.h"

class CMainFrame : public CFrameWnd
{
	
public:
	CMainFrame();
protected: 
	DECLARE_DYNAMIC(CMainFrame)

// Attributes
public:
#ifdef ZCL_TUTORIAL_VIEW
	HCAMERA			hCamera;
	HCTBL			hTbl;
	ZCL_COLORMODE	ColorMode;
#endif
#ifdef ZCL_TUTORIAL_END
	HANDLE			m_EndEvent;
	HANDLE			m_RcvTermEvent;
#endif

// Operations
public:

// Overrides
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL LoadFrame(UINT nIDResource, DWORD dwDefaultStyle = WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE, CWnd* pParentWnd = NULL, CCreateContext* pContext = NULL);

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

#ifdef ZCL_TUTORIAL_VIEW
	void StartProc();
	CChildView	m_wndView;
#endif

#ifdef ZCL_TUTORIAL_BMP
	PUCHAR		pBuffer;
#endif

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;

// Generated message map functions
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnFileClose();
	afx_msg void OnClose();
	DECLARE_MESSAGE_MAP()

#ifdef ZCL_TUTORIAL_BMP
public:
	afx_msg void OnEditBmpsave();
#endif
};


