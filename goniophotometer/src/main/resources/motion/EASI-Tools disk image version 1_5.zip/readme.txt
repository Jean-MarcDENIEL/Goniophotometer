README File for EASI-Tools Version 1.5

(C) Copyright 1999 - 2001. Parker Hannifin Corporation. 
All rights reserved.

This file includes updated information for use with EASI-Tools 
version 1.5. Please review this documentation carefully. It 
contains important new information not found anywhere else.

	Contents

	Part	Description
	1	Installation
	2	Getting Started
   	3	Technical Support
	4 	Revision history


Part 1:  Installation

This program requires the Microsoft Windows(tm) operating system. To 
install run the program "SETUP" on the floppy disk and follow 
the instructions. The installation program will create a 
directory containing the following files: -

	EASI.exe	- The executable
	EASI.hlp	- Help file
	ReadMe.Txt	- This file
	Licence.Txt	- Software licencing information
	
Also in a sub-directory called EXAMPLES...
	
	Example1.prg	- Simple reciprocating move
	Example2.prg	- Mulitiple moves and subroutines
	Example3.prg	- Tests the inputs and outputs
	Example4.prg	- PLC interfacing example (Label selection)
	Example5.prg	- Closed-loop control (using an encoder)
	Example6.prg	- "Indexing on the fly" (registration)
	Example7.prg	- How to recover from fault conditions

No additional files will be installed. However, EASI-Tools will 
create an EASI.ini file in your Windows sub-directory once you have 
run the executable.


Part 2:  Getting Started

EASI-Tools 1.5 supports the Parker EMD range of stepper drives 
with the Electromechanical Automation Software Instructions (EASI)
language indexer. 

Run the program from the Windows start bar or by selecting the 
EASI-Tools program icon from the program group.




Part 3:  Technical Support 

For technical support, please call the Parker Hannifin 
Electromechanical customer service department. You can also 
send us an email at tech.help@parker-emd.com.

Please be prepared to state your product type and serial number 
when calling, faxing or emailing for assistance.

		Parker Hannifin plc
		Electromechanical Division - Poole
		21 Balena Close
		Creekmoor Industrial Estate
		Poole, Dorset
		England
		Bh17 7DX 

		Telephone : 	00 44 (0)1202 699000
		Fax       :	00 44 (0)1202 695750
		email     :	sales@parker-emd.com
				tech.help@parker-emd.com
		web site  :     http://www.parker-emd.com


Part 4:  Revision History

1.5	Release 04/04/01

	Added new User Fault flags for XL products.

1.4	Release 12/03/01

	Updated Configuration tool option. Added support for XL
	products.

	Can upgrade units with version 2.0+ firmware.

1.3	Release 19/07/00

	Configuration tool option - Now stops indexer program if 
	uploading parameters. Checks for missing serial numbers.

	Firmware upgrade tool more reliable.

1.2	Release 17/02/00

	Fixes Configuration tool option - if user uploads and then
	just downloads configuration the changed ARM report back 
	screwed up the EX setting and turns comms echo-back and 
	speak mode. Determines if firmware is release 1.1 or later.

	Added IT (settle time) system variable and FAULT bit to ARM 
	command in configuration menu option.

	Added flags for In-position and In-motion to Status 
	reporting.

	Terminal now controls back-space not indexer.

	Fixes problem with Status reporting that user could not 
	enter axis address from keyboard.

	Help file - software reference updated to reflect firmware 
	changes & documentation improvements.

	Contains axis firmware upgrade facility.
 
	Download routine now appends a carriage return at the end
	of the successful completion of the routine - thus ensuring 
	a file with a command on the last line e.g. END, SV etc... 
	will execute this command even though programmer missed off 
	the last carriage return. 

	Added version of EASI-Tools to printout of configuration.

1.1	Release dated 1/11/99

	Added additional user notification when ASCII bell char 
	received to ensure PCs with sound cards / speakers will 
	here something.

	Added Status flags for LSEL command status. This will 
	prevent "contact Parker Hannifin" message appearing and 
	give more info on LSEL status during operation.

1.0	Initial release dated 28/9/99

 
